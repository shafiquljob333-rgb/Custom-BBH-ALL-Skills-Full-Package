---
name: masterjs-analyzer
description: Browser-independent, CLI-first JavaScript security analysis skill. Discovers JS, source maps, endpoints, parameters, secrets, client-side authorization, DOM XSS flows, prototype-pollution patterns, postMessage handlers, WebSockets, bundler/runtime artifacts, and legacy client behavior using curl and local analysis. Designed to convert client code into server-side test hypotheses; never treats client-only evidence as a confirmed vulnerability.
version: 1.0.0
---

# Master JS Analyzer

## Mission

Treat JavaScript as an attack-surface intelligence source, not as the vulnerability itself.

Primary output:

```text
JS artifact
 -> routes
 -> parameters
 -> auth assumptions
 -> trust boundaries
 -> state transitions
 -> security-sensitive sinks
 -> concrete HTTP hypotheses
 -> server-side verification
```

Client-side evidence becomes a finding only when the server-side behavior creates a real security consequence.

## Input / Output Contract

### Input

- authorized target URL(s);
- downloaded JS or source maps;
- optional API documentation/OpenAPI/GraphQL schema;
- optional authenticated request material that is safe to use on test accounts.

### Output

For every useful lead record:

```yaml
artifact:
route:
method:
parameters:
auth_assumption:
server_test:
expected_secure_behavior:
observed_behavior:
impact_candidate:
evidence:
status: lead|validated|discarded
```

## Phase 0 - Scope and Asset Gate

Confirm every JS URL belongs to an authorized in-scope asset.

Do not pivot from an in-scope domain to an unapproved third-party host merely because a script references it.

## Phase 1 - JS Discovery

### HTML script discovery

```bash
curl -sS --compressed 'https://TARGET/' \
  -H 'User-Agent: Mozilla/5.0' \
  | grep -oE '<script[^>]+src=["\x27][^"\x27]+' \
  | sed -E 's/.*src=["\x27]//' \
  | sort -u
```

### Standard locations

Check framework-specific paths conservatively and only on the authorized asset:

```text
/static/js/
/assets/
/_next/static/
/_nuxt/
/js/
/build/
/dist/
```

Do not brute-force enormous chunk ranges. Start from references in HTML, JS runtime manifests, preload tags, and source maps.

### Historical JS discovery

Use authorized/public archival data only for discovery. Treat old URLs as leads, not as permission to test unrelated infrastructure.

Useful tools when available:

```bash
gau TARGET | grep -E '\.js([?#]|$)' | sort -u
gospider -s 'https://TARGET' --js -d 3
katana -u 'https://TARGET' -jc -d 3
```

## Phase 2 - Download and Normalize

```bash
mkdir -p js/{raw,pretty,maps,sourcemap}

curl -sS --compressed 'https://TARGET/app.js' -o js/raw/app.js
file js/raw/app.js
wc -c js/raw/app.js
head -c 200 js/raw/app.js
```

Record:

- URL;
- response status;
- Content-Type;
- Content-Length;
- ETag/Last-Modified where present;
- hash of downloaded artifact.

A hash lets the agent distinguish a new build from the same artifact seen earlier.

## Phase 3 - Source Maps

Detect:

```bash
curl -sS 'https://TARGET/app.js' | tail -n 5 | grep -i 'sourceMappingURL'
curl -sS -o /dev/null -w '%{http_code} %{content_type} %{size_download}\n' 'https://TARGET/app.js.map'
```

If accessible and in scope:

```bash
curl -sS 'https://TARGET/app.js.map' -o js/maps/app.js.map
python3 -m json.tool js/maps/app.js.map | head -40
```

Use local extraction tools such as `sourcemapper`/`unwebpack_sourcemap` when available.

### Source-map triage

High-value signals:

- unminified authorization logic;
- internal-only route names;
- feature flags;
- server endpoint definitions;
- hidden GraphQL operations;
- test/debug paths;
- environment variable references;
- comments containing TODO/FIXME/HACK/DEBUG;
- source code that reveals server-side trust assumptions.

Do not report the mere existence of a source map unless the exposed source itself creates a meaningful security consequence under the program's policy.

## Phase 4 - Endpoint and Parameter Extraction

Use `jsluice`, LinkFinder, grep, parser scripts, or equivalent local analysis.

Useful patterns:

```bash
grep -rEo 'https?://[^"\x27 )]+' js/raw js/sourcemap | sort -u
grep -rEo '/(api|graphql|oauth|auth|admin|internal|v[0-9]+)[A-Za-z0-9_./?=&{}:-]*' js/raw js/sourcemap | sort -u

grep -rEin 'fetch\(|axios\.|\.get\(|\.post\(|\.put\(|\.patch\(|\.delete\(|XMLHttpRequest|WebSocket' js/raw js/sourcemap | head -200
```

Extract parameter names from:

- query strings;
- URL templates;
- JSON bodies;
- GraphQL variables;
- multipart metadata;
- headers;
- path segments.

Group routes by business object:

```text
/users/{id}
/orders/{id}
/invoices/{id}
/files/{id}
/organizations/{id}
/projects/{id}
```

## Phase 5 - Client-Side Authorization Analysis

Search for:

```text
role
permission
isAdmin
isOwner
can*
featureFlag
verified
subscription
entitlement
organizationId
tenantId
```

A client check is only a hypothesis.

For example:

```js
if (user.role === 'admin') showDeleteButton()
```

does not prove a vulnerability.

Convert it into:

```text
Which endpoint performs the delete?
Does that endpoint enforce the same role server-side?
Can the test account invoke it directly?
```

## Phase 6 - DOM XSS Data-Flow Analysis

### Sources

```text
location.search
location.hash
location.href
location.pathname
document.referrer
postMessage data
localStorage/sessionStorage values
URLSearchParams
```

### Sinks

```text
innerHTML
outerHTML
document.write
eval
new Function
setTimeout(string)
setInterval(string)
location.assign/location.replace
src/href assignments
```

Use source-to-sink reasoning, not keyword matching.

A sink is a lead only until attacker-controlled input is demonstrated to reach it in an executable context.

Where a browser is unavailable, first prove the data-flow statically and then use a minimal, browser-independent server-side or reflective observation where possible. Do not claim execution without execution evidence.

## Phase 7 - postMessage

Search:

```bash
grep -rEin 'addEventListener\(["\x27]message|onmessage|postMessage\(' js/ | head -100
```

For each handler, model:

```text
source window
origin validation
message structure validation
sink
privileged action
```

High-confidence cases require evidence that an untrusted origin can influence a security-relevant action or sensitive data flow.

String checks such as `includes('target.com')` are suspicious, not automatically vulnerable.

## Phase 8 - Prototype Pollution

Search for:

```text
__proto__
constructor.prototype
Object.assign
merge
extend
clone
set(path, value)
recursive object assignment
```

Classify separately:

- client-side pollution only;
- server-side object pollution;
- pollution that changes a security decision;
- pollution that reaches a dangerous gadget.

Only the final security effect determines reportability.

## Phase 9 - Secrets and Credentials

Use high-precision scanners first:

```bash
trufflehog filesystem js/sourcemap --only-verified
gitleaks detect --source js/sourcemap -v
jsluice secrets js/raw/app.js
```

Then inspect manually.

Classify candidate strings:

```text
public identifier
public client key
publishable key
non-secret configuration
credential
session token
private signing key
database credential
third-party secret
```

A value is a finding only when:

1. it is actually secret or privileged;
2. it is accessible to an unauthorized party;
3. it is valid/current or otherwise useful;
4. its use is authorized only within the intended trust boundary;
5. impact is demonstrated safely.

Do not test destructive actions with discovered credentials.

## Phase 10 - Framework / Bundler Intelligence

Recognize common artifacts:

```text
React / CRA -> /static/js/*.chunk.js
Next.js -> /_next/static/
Angular -> /main.*.js /runtime.*.js
Vue -> /js/app.*.js
Nuxt -> /_nuxt/
Vite -> /assets/*.js
```

Look for:

- route registries;
- API base URLs;
- environment variable names;
- GraphQL operation names;
- feature flag names;
- legacy API versions;
- accidentally bundled server-only imports.

## Phase 11 - WebSocket Surface

Search:

```bash
grep -rEin 'new WebSocket|ws://|wss://|socket\.io|\.emit\(|\.send\(' js/ | head -100
```

Map message types and authorization assumptions.

Do not claim message-level authorization bypass until a test identity can perform a prohibited message successfully.

## Phase 12 - Legacy / Alternate Surface Comparison

For every important route discovered in JS, search for:

```text
v1/v2/v3
legacy
mobile
internal
admin
graphql
rest
batch
export
import
share
notification
```

Compare the same operation across surfaces.

The key question:

> Does one implementation enforce a security invariant while a sibling implementation does not?

## Phase 13 - JS Candidate Scoring

Prioritize:

1. route + sensitive object + missing backend authorization evidence;
2. token/secret with demonstrable privileged use;
3. URL-driven dangerous sink with executable consequence;
4. privileged message handler lacking trusted-origin enforcement;
5. hidden endpoint with materially weaker server controls;
6. source-map discovery that reveals exploitable server assumptions.

Deprioritize:

- source maps with no additional impact;
- public identifiers;
- dead code;
- client-only role checks where the server is secure;
- vulnerable library versions without reachable/exploitable behavior.

## Phase 14 - Required HTTP Conversion

Every promising JS lead must produce an HTTP hypothesis:

```text
JS route
 -> HTTP method
 -> required headers/cookies
 -> request body/query
 -> expected authorized context
 -> unauthorized test context
 -> response comparison
 -> impact proof
```

The next skill should normally be `02-curl-http-operator`.

## Final Gate

Do not report JS findings based only on source code. Require:

```text
source evidence
+
HTTP/server evidence
+
concrete impact
+
scope
+
novelty
```

## Evidence Template

```yaml
js_url:
artifact_hash:
route:
method:
source_location:
source_behavior:
security_assumption:
http_request:
http_response:
authorization_context:
impact:
chain:
design_intent:
duplicate_status:
final_status:
```
