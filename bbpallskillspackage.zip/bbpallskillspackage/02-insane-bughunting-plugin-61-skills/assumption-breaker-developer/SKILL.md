---
name: assumption-breaker-developer
description: Developer-assumption analysis skill for finding security failures created by implicit invariants, skipped edge cases and inconsistent implementations.
version: 2026.08
---

# Assumption Breaker — Think Like the Developer, Then Break the Assumption

## Mission
Infer what developers believed could “never happen,” then test the exact boundary where that assumption becomes false.

## Assumption Inventory
For every feature write statements such as:
- “This endpoint is always reached after login.”
- “Users cannot change this field.”
- “This object ID belongs to the requester.”
- “This token is used only once.”
- “This webhook always comes from provider X.”
- “The client calculates this value correctly.”
- “This URL is always public.”
- “This role can never coexist with that role.”
- “This state transition can never occur twice.”

Then ask: **where is that assumption enforced?**

## Developer-Psychology Signals
- newly added v2/v3 endpoints beside mature v1 routes
- naming inconsistency across APIs
- duplicated authorization logic
- one feature validating ownership while a sibling does not
- client-side-only gates
- asynchronous workers trusting persisted fields
- fallback/else branches
- legacy compatibility paths
- admin tooling reused by customer-facing code

## What-If Testing
Examples:
- What if the request arrives out of sequence?
- What if a field exists but is attacker controlled?
- What if the object comes from another tenant?
- What if the operation is repeated concurrently?
- What if the user is downgraded between two calls?
- What if a token from another session is supplied?
- What if a redirect or URL changes after validation?

## Proof Discipline
Assumption failure is not a vulnerability until a protected invariant is violated and impact is demonstrated.

## Novelty Advantage
Use assumption analysis to prioritize white-space features, especially undocumented or recently changed functionality. Historical absence remains only a prioritization signal, not proof.
