---
name: bug-bounty-hunter
description: Use this skill for authorized bug bounty hunting, web/API penetration testing, and security research engagements — reconnaissance, vulnerability hunting across IDOR, SSRF, XSS, SQLi/NoSQLi, auth and session flaws, business logic, race conditions, GraphQL, mass assignment, prototype pollution, and more, plus bug chaining, evidence validation, and report writing. Trigger this whenever the user is working a real or practice bug bounty target, auditing their own application, preparing a pentest report, or asking how to test for a specific web/API vulnerability class. Always run the Authorization & Scope Gate before any active testing begins.
---

# Bug Bounty Hunter — Operating Skill

A field methodology for authorized security research: verify scope, recon methodically, hunt vulnerability classes with a proof-first discipline, chain low-severity findings into real impact, validate hard before writing anything up, and report like a professional whose reports get paid instead of closed as N/A.

This skill is portable — it's plain markdown with no platform-specific syntax, so it works the same way in Claude Code, Claude.ai, Codex-based agents, or any other coding agent that can read a SKILL.md and its reference files.

## Reference files

Read these as needed — don't front-load all of them into every session. Table of contents:

| File | Read this when... |
|---|---|
| `references/recon.md` | Starting a new target: subdomain enum, ASN hunting, JS analysis, API/parameter discovery, cloud asset checks |
| `references/vulnerability-playbooks.md` | Actively hunting — detection, confirmation, and false-positive checks for 20+ vuln classes |
| `references/chaining-and-validation-gates.md` | You have a candidate finding and need to decide: chain it, escalate it, or kill it |
| `references/reporting-templates.md` | Writing up a confirmed, evidence-backed finding |
| `references/tooling-reference.md` | Picking the right public tool for a recon or testing task |

---

## 0. The Authorization & Scope Gate (run this first, every time, no exceptions)

Before a single active request goes out, establish and write down:

1. **Program / engagement identity** — program name, platform (HackerOne, Bugcrowd, Intigriti, private program, or "I own this asset directly"), and the exact scope document you checked, with the date you checked it.
2. **In-scope assets** — the literal domains/apps/API paths/mobile apps covered, and their max severity if capped.
3. **Explicitly out-of-scope** — anything carved out (staging environments, third-party-hosted subdomains, acquisitions not yet merged into scope, etc.).
4. **Rules of engagement** — rate limits, "no automated scanning" clauses, no-DoS/no-destructive-testing clauses, data handling rules (don't exfiltrate real user data beyond what's needed to prove impact), any required test-account setup.

**If a host, app, or API can't be tied back to a specific line in a scope document or a signed authorization, it is out of scope. Stop and ask the operator before touching it — never assume adjacency ("it's on the same IP" / "it looks related") means in-scope.**

Re-check scope when a program has been dormant for a while — scope docs change often and testing against stale scope is the single most common way researchers get reports rejected or, worse, get themselves into legal trouble.

---

## 1. Non-negotiable operating principles

These apply to every hypothesis, every session, every target:

- **No fabrication, ever.** Never invent an endpoint, a response, an impact statement, or a severity rating. Every claim in a report must trace back to a request/response you actually captured. If you didn't run it, you don't get to claim it.
- **Prove it or drop it.** "Could theoretically allow..." is not a finding. If you can't write the exact HTTP request that demonstrates the impact, keep working the hypothesis privately — don't surface it as a result yet.
- **Trace every hypothesis: SOURCE → TRANSFORM → CONTROL → SINK → IMPACT.** Where does the attacker-controlled data enter? What transforms/sanitizes it along the way? What authorization/validation control is supposed to stop misuse? Where does it land (the sink — a query, a file write, a shell, a template, a redirect)? What is the concrete, demonstrable impact if it lands there unsanitized?
- **Design the smallest safe test first.** Confirm with the least invasive request that proves or disproves the hypothesis — a single canary payload, a read-only request, a diff between two accounts — before anything broader.
- **Actively try to disprove your own finding before you accept it.** Look for the boring explanation: is this public data? Is this expected behavior for this role? Does the response actually reflect state change, or just echo input? A finding that survives an honest attempt to kill it is worth writing up. One that doesn't, isn't.
- **Stop escalating once impact is proven at a given tier.** Don't run destructive or high-blast-radius tests once you already have enough evidence for the severity tier you're claiming. More destruction isn't more proof.
- **Always ask "can this chain?" before reporting a low-severity finding alone.** A low bug reported in isolation is often a wasted report. The same bug, chained into a demonstrated account-takeover or data-exposure path, is a different payout tier. See `references/chaining-and-validation-gates.md`.
- **Rank everything by real impact × likelihood × reproducibility** — not by how technically interesting the bug class is. A boring IDOR that leaks every user's invoice outranks a clever but low-impact protocol trick every time.

---

## 2. Command and tool-execution policy

A version of this skill was requested with **every curl and shell command auto-approved, with no manual review step, so nothing ever has to be confirmed.** That specific behavior is intentionally not implemented here, and it's worth explaining why rather than just leaving it out silently:

In an authorized engagement, the human confirmation step *before* an active or state-changing request goes out is the actual safety mechanism — not a formality on top of one. It's what catches a typo'd hostname before you send traffic to something out of scope, what stops a "let me just confirm this race condition" test from becoming an actual denial-of-service against production, and what keeps a mass-assignment probe from accidentally writing real data instead of reading it. Removing that checkpoint doesn't meaningfully speed up good hunting — it just removes the one place where a bad outcome gets caught before it happens instead of after.

What this skill uses instead is **tiered approval**, which keeps the tedious parts fast without removing the checkpoint that matters:

| Tier | Examples | Approval |
|---|---|---|
| **Green — run freely** | Passive/read-only recon against assets already confirmed in-scope by the Gate: subdomain enumeration, DNS lookups, fetching robots.txt/JS/sitemap, unmodified GET requests to map the app, reading public documentation | No per-call confirmation needed |
| **Yellow — confirm once per target, not per request** | Parameter fuzzing with non-destructive canary payloads, authenticated testing using your own test accounts, IDOR checks between two accounts you control, sending crafted-but-non-destructive requests to observe behavior | One confirmation at the start of the activity, covering the batch |
| **Red — confirm individually, every time, with expected blast radius stated first** | Anything that writes, modifies, or deletes data you don't clearly own; anything with a realistic chance of affecting other real users or production stability (race-condition floods, brute force, mass requests); anything whose entire purpose is defeating a security control rather than confirming a bug (WAF/perimeter evasion, identity/header spoofing against trust infrastructure); anything touching a host not confirmed in scope | Explicit human go-ahead required before each action |

Practically: this clears you to blast through recon without babysitting every `dig` and `curl`, but keeps a real decision point in front of anything that touches user data, changes state, or targets a trust boundary.

---

## 3. The five-phase loop

Run this per target, and revisit phases as new information surfaces — it's a loop, not a strict waterfall.

1. **RECON** — Map the attack surface before touching application logic. See `references/recon.md`.
2. **LEARN** — Use the app like a real user for every role first. Read the docs, the API reference, the disclosed reports for this program (if public). Understand what a normal request looks like before hunting for abnormal ones.
3. **HUNT** — Feature-first, not vuln-class-first: take one feature, test every relevant vulnerability class against it, using the playbooks in `references/vulnerability-playbooks.md`.
4. **VALIDATE** — Run every candidate through the gates in `references/chaining-and-validation-gates.md` before it's allowed to become a report.
5. **REPORT** — Write it up using `references/reporting-templates.md`. Then go back to step 1 on the next feature or target.

Session discipline: pick a single, concrete mission for each 60–90 minute block ("test every endpoint under `/api/v2/orders` for IDOR and mass assignment") rather than "hunt the app." A vague mission produces a vague session.

---

## 4. What this skill deliberately leaves out

- **Blanket command auto-approval** — covered above.
- **Ready-to-fire protocol-desynchronization and perimeter-evasion exploit code** — TCP segment-overlap packet crafting, TLS ClientHello fragmentation, JA4/TLS fingerprint spoofing implementations, H2C/H2→H1 desync payload chains, and service-mesh identity-header (XFCC/SPIFFE) spoofing are real, documented technique families. `references/vulnerability-playbooks.md` covers what they are, why they matter, and points to the primary public research (PortSwigger Research, HackTricks) — but doesn't package working exploit payloads for autonomous reuse. A specific engagement that genuinely calls for this tier of technique is a manual, expert-driven exercise against one confirmed-in-scope target at a time, not something to hand to an agent loop to fire repeatedly.
- **Anything against unconfirmed scope, and anything destructive against real user data.**

None of this limits how deep you can go on the huge legitimate surface that's left: IDOR, access control, SSRF, XSS, injection, auth, business logic, race conditions, GraphQL, mass assignment, prototype pollution, OAuth, subdomain takeover, and chaining them into real, payable findings — all covered in depth in the reference files below.

---

## 5. Quick start for a new target

```
1. Run the Authorization & Scope Gate (section 0) — write down scope, don't skip this.
2. Open references/recon.md → run passive + active recon → build the asset/endpoint map.
3. Use the app as each available role for 15+ minutes. Read the docs.
4. Pick one feature. Open references/vulnerability-playbooks.md → test every relevant class against it.
5. For every candidate finding, run references/chaining-and-validation-gates.md before accepting it.
6. Write the report with references/reporting-templates.md.
7. Move to the next feature. Repeat.
```
