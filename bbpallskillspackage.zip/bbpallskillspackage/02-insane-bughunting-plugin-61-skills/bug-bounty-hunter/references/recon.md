# Recon & Discovery Reference

Recon maps the attack surface. It is not the hunt itself — it's how you find where to hunt. A common failure mode among newer hunters is spending 80% of available time on recon automation and never getting to manual testing; the fix is a time-boxed recon pass followed by a much larger manual-testing pass. Recon that doesn't lead to testing within the same session is recon you didn't need yet.

All commands below are **Green tier** (read-only/passive) unless noted otherwise — see the Command Policy in the main SKILL.md.

## 1. Passive recon (don't touch the target directly)

Goal: build the asset inventory without generating traffic the target would notice.

- Enumerate the org's domains and any acquired companies/subsidiaries — acquisitions are frequently missing from a company's own asset inventory and are a high-value blind spot.
- Certificate transparency logs (`crt.sh`, `censys.io`) for subdomains issued certs.
- Passive subdomain sources: `subfinder -d target.com -silent`, `assetfinder --subs-only target.com`, `amass enum -passive -d target.com`.
- Google/Bing dorking for exposed material:
  - `site:target.com filetype:js`
  - `site:target.com inurl:api`
  - `site:target.com ext:json | ext:xml | ext:yaml`
  - `site:target.com "internal use only"`
- GitHub/GitLab dorking (public repos only, respect ToS): search the org name plus `password`, `secret`, `api_key`, `Authorization:`.
- `site:target.com "responsible disclosure"`, `/.well-known/security.txt` — finds programs and scope docs directly.

## 2. ASN hunting

An Autonomous System Number reveals the IP ranges a company actually owns, which surfaces infrastructure that subdomain enumeration alone misses — services hosted directly on IP without a friendly hostname. Look up the org's ASN, pull the full IPv4 *and* IPv6 ranges (IPv6 is very commonly skipped and just as commonly forgotten by the target's own team), and treat that range as additional scope to check against the program's asset list before testing.

## 3. Active recon (Green tier — read-only probing of confirmed in-scope hosts)

- Resolve and filter: `cat subdomains.txt | dnsx -silent | httpx -silent -status-code -title -tech-detect`.
- Filter out CDN/WAF IPs (Cloudflare, Akamai) when you want to know what's actually directly hosted vs. fronted.
- Full port scan on live hosts, not just top-1000: `naabu -iL alive.txt -p - -o open-ports.txt`, then `nmap -sV -sC` on anything interesting.
- Visual triage: screenshot every live host (`aquatone`, `eyewitness`) — login panels, default server pages, and stack traces jump out fast this way.
- Re-run this pipeline on a schedule (daily/weekly) and diff against the last run — new assets and new endpoints are disproportionately likely to have fresh, unreviewed bugs.

## 4. DNS record analysis

Check A/CNAME/TXT/MX records for dangling references — a CNAME pointing at a service (GitHub Pages, Heroku, an S3 bucket, Azure, Netlify, Fastly) that's no longer provisioned on the target's side is a subdomain takeover candidate. See the Subdomain Takeover entry in `vulnerability-playbooks.md`.

## 5. Historical URL discovery

Old, removed, or forgotten endpoints often still work server-side even after being removed from the current UI.

- `gau target.com`, `waybackurls target.com` — pull URLs from the Wayback Machine and other archive sources.
- Diff historical endpoints against what's currently linked from the live app — anything present historically but absent from current navigation is worth a direct request.

## 6. JavaScript analysis

JS bundles are consistently one of the highest-value recon sources: hidden endpoints, internal API paths, feature flags, and (occasionally) hardcoded secrets all live here.

What to extract:
- **Endpoints** — run something like `linkfinder` against every JS file, including lazily-loaded chunks (easy to miss, worth deliberately checking).
- **Secrets** — grep for patterns like `AKIA`, `api_key`, `secret`, `Bearer `, `Authorization`. Verify anything found actually works before treating it as a finding — dead/rotated keys are common false positives.
- **Source maps** — a `.js.map` file exposes readable source, function names, and comments; check for one alongside every bundle.
- Monitor JS diffs over time on actively-developed targets — new code shipped this week has had the least security review.

## 7. API and hidden-parameter discovery

- Check for API documentation directly: `site:target.com swagger`, `site:target.com api/docs`, `/swagger-ui.html`, `/api-docs`.
- If `/api/v2/...` exists, always also try `/api/v1/...` and any other version — older versions are frequently left running with weaker checks.
- Hidden parameter discovery: `arjun`, Burp's Param Miner extension. High-value parameter name signals: `debug`, `admin`, `test`, `redirect`, `url`, `callback`, `role`, `isAdmin`.
- Mobile API surface: decompile the APK/IPA (where permitted by scope) — mobile clients frequently call an older or less-hardened API version than the web client.

## 8. Technology fingerprinting

| Signal | Likely stack |
|---|---|
| `XSRF-TOKEN` + `*_session` cookie | Laravel |
| `PHPSESSID` cookie | PHP |
| `X-Powered-By: Express` | Node.js/Express |
| `/wp-json`, `/wp-content` | WordPress |
| GraphQL-style error bodies (`"errors":[{"message":...`) | GraphQL backend |
| `X-Powered-By: Next.js` | Next.js |

Once a stack is identified, check its known debug/admin surface directly: `/actuator/env` and `/actuator/heapdump` (Spring), `/horizon`, `/telescope`, `/.env` (Laravel), `/wp-json/wp/v2/users`, `/xmlrpc.php` (WordPress), `/.env`, `/graphql` introspection (Node.js).

## 9. Cloud asset checks (read-only, Green tier)

- S3/GCS/Azure Blob public listing: `aws s3 ls s3://target-bucket-name --no-sign-request`, or try common bucket name patterns (`target-backup`, `target-assets`, `target-staging`).
- Firebase open rules: `curl -s "https://TARGET-APP.firebaseio.com/.json"` — a non-empty response means open read.
- These are read-only checks. Anything beyond confirming exposure (writing test data, extracting more than the minimum proof) moves into Yellow/Red tier — get explicit confirmation first.

## 10. Quick-win checklist

- [ ] Subdomain takeover candidates (dangling CNAMEs)
- [ ] Exposed `.git` (`/.git/config`) or `.env`
- [ ] JS secrets / source maps
- [ ] Open redirects (`?redirect=`, `?next=`, `?url=`)
- [ ] CORS misconfiguration (reflected `Origin` + `Access-Control-Allow-Credentials: true`)
- [ ] Public cloud buckets
- [ ] GraphQL introspection enabled
- [ ] Framework debug/actuator endpoints

Recon output feeds directly into `vulnerability-playbooks.md` — every endpoint, parameter, and role you find here becomes a test target there.
