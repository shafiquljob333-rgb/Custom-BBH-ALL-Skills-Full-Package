# Reporting, Severity & Triage

A great bug reported badly gets marked informational or closed as N/A. A clear, evidence-first report gets paid faster and builds the reputation that gets you into private programs.

## Report template

```
## Title
[Vuln class] in [exact endpoint/feature] allows [attacker role] to [concrete impact]

## Summary
2–3 sentences: what it is, where it is, what an attacker can actually do.

## Steps to Reproduce
1. Log in as Account A (test1@example.com)
2. [exact request/action]
3. [exact request/action]
4. Log in as Account B (test2@example.com)
5. [exact request/action]
6. Observe: [exactly what happened, in plain terms]

## Proof of Concept
[Screenshot / video / raw HTTP request+response / minimal script]

## Impact
An attacker can [specific action] resulting in [specific harm].
Quantify where possible: "affects all N users," "exposes [data type] for any account."

## Severity
CVSS 3.1: X.X ([label]) — Attack Vector: Network | Complexity: Low | Privileges: None | User Interaction: None

## Remediation (optional but appreciated)
One or two sentences of concrete fix direction — e.g., "verify server-side that the requesting user owns the referenced order_id before returning it."
```

## Title formula

`[Vuln Class] in [exact endpoint/feature] allows [attacker role] to [impact] [scope]`

**Good:**
- `IDOR in /api/v2/invoices/{id} allows authenticated user to read any customer's invoice data`
- `Missing auth on POST /api/admin/users allows unauthenticated attacker to create admin accounts`
- `Stored XSS in profile bio field executes in admin panel — allows privilege escalation`

**Bad (too vague to triage quickly):**
- `Security issue found`
- `Broken access control`
- `XSS in user input`

## Human-tone writing rules

- Lead each section with the impact, not a restatement of the vulnerability's textbook definition.
- Write like you're explaining it to a competent developer who's short on time, not like a textbook.
- Use "I" and active voice: "I found that…" not "A vulnerability was discovered…"
- One concrete, exact example beats three abstract sentences.
- State worst-case impact as a reasoned inference ("this would allow…"), not as a claim you didn't actually verify.
- Never exaggerate severity — credibility is the asset that gets your next five reports triaged faster.
- Keep it under ~600 words where possible; triagers skim long reports and miss the point.

## Severity / CVSS quick reference

| Severity | Definition | Example |
|---|---|---|
| Informational | No direct exploitable risk | Missing security header, no working PoC |
| Low | Limited impact, hard to exploit or low value | Verbose error message, non-sensitive info disclosure |
| Medium | Exploitable under specific conditions, moderate impact | CSRF on a non-critical action, self-XSS with weak delivery |
| High | Direct risk to user data or accounts | Stored XSS, sensitive IDOR, SSRF with internal access |
| Critical | System-wide or mass-user risk | RCE, mass account takeover, full database access |

**Typical CVSS anchors** (situational — always justify from the actual impact, not just the class):

| Bug class | Typical CVSS | Severity |
|---|---|---|
| IDOR (read PII) | ~6.5 | Medium |
| IDOR (write/delete) | ~7.5 | High |
| Auth bypass → admin | ~9.8 | Critical |
| Stored XSS | 5.4–8.8 | Medium–High |
| SQLi (data exfil) | ~8.6 | High |
| SSRF (cloud metadata reached) | ~9.1 | Critical |
| Race condition (double-spend) | ~7.5 | High |
| JWT `alg:none` | ~9.1 | Critical |

Severity tracks **impact**, not technical cleverness. A conceptually simple IDOR that exposes every user's payment details can outrank a technically elaborate bug with no real-world reach.

## Triage mindset — read your own report as the reviewer would

| Question the triager asks | What to check before submitting |
|---|---|
| Exploitability | Is this actually easy to trigger, or buried under preconditions? |
| Impact | What's the real-world worst case, stated honestly? |
| Reproducibility | Could the triager follow my steps and get the same result, first try? |
| Risk | How many users/how much data is actually exposed? |
| Clarity | Does this report answer questions before they're asked? |

The fewer back-and-forth clarification rounds a report needs, the faster it gets resolved and paid.

## Duplicate reduction

- Popular, highly visible endpoints get tested by everyone — expect duplicates there for common bug classes.
- New program scope announcements draw a wave of hunters immediately — testing early matters.
- High-severity findings get fixed fast, which shrinks the duplicate window — prioritizing impact also reduces collision risk.
- Going deep on one program (understanding its specific business logic) beats going wide across many — application-specific insight is what other hunters skimming the surface miss.
- If challenging a "duplicate" rejection, strengthen your case with a genuinely different exploitation path or deeper impact than the original report, not just a re-statement.

## Severity pushback language (when a program tries to downgrade a valid finding)

| Program says | Reasonable response |
|---|---|
| "Requires authentication" | "Only a free, self-service account — no special role or invite needed" |
| "Limited impact" | State the actual affected scope: N users / specific PII type / $ amount |
| "Already known" | Ask for the report number; note you searched and found none |
| "By design" | Ask for the documentation stating this is intended behavior |
| "Low CVSS" | CVSS captures technical severity, not business impact — restate the concrete business impact |

Use this to advocate for a fair severity assessment, not to argue past a well-reasoned rejection — if the program shows a genuine reason the finding doesn't apply, that's the correct outcome.
