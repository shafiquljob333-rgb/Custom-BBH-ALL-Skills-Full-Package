# Tooling Reference

All tools below are established, publicly available open-source or commercial security tools — nothing here is custom exploit tooling. Pick the tool for the job at hand; automation surfaces anomalies for a human to investigate, it doesn't replace the manual testing in `vulnerability-playbooks.md`.

## Recon

| Tool | Use |
|---|---|
| `subfinder` | Passive subdomain enumeration |
| `amass` | Passive + active subdomain enumeration |
| `assetfinder` | Subdomain enumeration |
| `httpx` | Probe live hosts, grab titles/status/tech |
| `dnsx` | Bulk DNS resolution |
| `naabu` | Fast port scanning |
| `nmap` | Detailed service/version scanning |
| `aquatone` / `eyewitness` | Screenshot flyover of live hosts |
| `gau` / `waybackurls` | Historical URL discovery |
| `linkfinder` | Extract endpoints from JS |
| `arjun` | Hidden parameter discovery |
| `crt.sh`, `censys.io`, `shodan` | Passive certificate/asset intelligence |

## Fuzzing & scanning

| Tool | Use |
|---|---|
| `ffuf` / `gobuster` / `feroxbuster` | Directory and content brute-forcing |
| `nuclei` | Template-based known-vulnerability scanning (verify every hit manually) |
| `nikto` | Web server misconfiguration scanning |
| `dalfox` | XSS scanning/fuzzing |
| `sqlmap` | SQL injection automation (use only after a manual candidate injection point is confirmed) |
| `katana` | Crawling |
| `subzy` | Subdomain takeover detection |

## Manual testing

| Tool | Use |
|---|---|
| Burp Suite (Proxy, Repeater, Intruder, Comparer, Decoder) | Core manual testing workflow |
| Burp — Autorize | Automated authorization-bug detection between two sessions |
| Burp — Param Miner | Hidden parameter and unkeyed-header discovery |
| Burp — HTTP Request Smuggler | Smuggling detection (see Red-tier note in playbooks) |
| Burp — Turbo Intruder | Race-condition and single-packet-attack testing |
| Burp — InQL | GraphQL schema exploration |
| Burp — 403 Bypasser | Basic access-control bypass probing |
| OWASP ZAP | Free alternative to Burp for proxy/scanning |

## Secrets & static analysis

| Tool | Use |
|---|---|
| `trufflehog` / `gitleaks` | Secret scanning across filesystems/repos |
| `semgrep` | Static analysis (`p/security-audit`, `p/owasp-top-ten`, language-specific rulesets) |

## Out-of-band detection

| Tool | Use |
|---|---|
| Burp Collaborator | Out-of-band detection for blind SSRF/SQLi/XXE |
| `interactsh` | Open-source Collaborator alternative |
| XSS Hunter | Blind XSS callback with screenshots |

## Wordlists

- **SecLists** — the standard comprehensive wordlist collection (`github.com/danielmiessler/SecLists`)
- **PayloadsAllTheThings** — payload reference across every vulnerability class

## Learning resources

| Resource | Why |
|---|---|
| PortSwigger Web Security Academy | Free, legal, hands-on labs for every vulnerability class — the best single starting point, including for request smuggling, cache poisoning, and other advanced classes covered only conceptually in this skill |
| HackTricks | Deep technique reference, actively maintained |
| Hacker101 (HackerOne) | CTF-style guided learning |
| OWASP Testing Guide | Structured methodology reference |
| Public program disclosed reports (HackerOne Hacktivity, Bugcrowd Crowdstream) | Read real paid reports to calibrate what "good" looks like and what a given program values |

## Safe practice targets (use these to build skill before hunting live)

| Platform | What it's for |
|---|---|
| PortSwigger Web Security Academy | Free labs covering essentially every class in this skill |
| OWASP Juice Shop | Self-hosted intentionally vulnerable app |
| DVWA | Classic basics-practice app |
| HackTheBox / TryHackMe | Broader offensive-security practice |

Only test against these labs and against assets explicitly covered by a program's scope or your own written authorization — never anything in between.
