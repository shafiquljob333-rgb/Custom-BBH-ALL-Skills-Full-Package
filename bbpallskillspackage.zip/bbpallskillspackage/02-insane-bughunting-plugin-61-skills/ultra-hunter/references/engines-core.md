# Engines — Core (identity, authorization, business logic)

## §1 Startup procedure (every new target)

DO NOT launch payloads first. Produce a target profile before testing:

```
TARGET PROFILE: program, scope, engagement type, restrictions, main domains,
APIs, mobile, cloud, third-party dependencies
BUSINESS MODEL: product, users, revenue, crown jewels, high-risk workflows
IDENTITY MODEL: anonymous → user → verified → paid → member → manager → owner
→ admin → service account (every tier that exists)
SECURITY INVARIANTS: the most important "must never happen" statements
ATTACK-SURFACE MAP: web, APIs, GraphQL, mobile, cloud, auth, admin,
integrations, files, webhooks, async jobs
PRIORITY QUEUE: top 10 surfaces ranked by impact × likelihood × novelty ×
information gain ÷ duplicate risk ÷ complexity
```

### Business-model intelligence (hunting blind is the #1 waste)

Determine: what the company sells, who pays, who uses it (B2B/B2C/marketplace/
SaaS/fintech/crypto/e-commerce/dev platform/AI/logistics), where money moves,
what creates revenue, what creates operational risk.

**Crown jewels** — identify: credentials, sessions, API keys, tokens, payment
methods, balances, credits, orders, invoices, KYC, private documents, source
code, repositories, CI/CD secrets, cloud resources, customer databases,
privileged configurations, webhooks, integrations, IdPs, admin functions. Ask:
*"If an attacker could obtain ONE unauthorized capability, which would cause the
most damage?"* Prioritize that.

**Pain-point priority** — hunt where abuse hurts most: money movement, account
recovery, identity verification, payments, refunds, discounts, coupons,
subscription changes, org administration, invitations, sharing, exports/imports,
uploads, integrations, API credentials, webhooks, OAuth/SSO, password reset,
email/phone change, MFA, device management, billing, role management, ownership
transfer, withdrawals, async jobs.

## §2 Security-invariant engine (the core mental model)

Do NOT begin with vulnerability names. First define what must ALWAYS be true:

- User A must never read User B's private resource.
- Tenant A must never modify Tenant B.
- Viewer must never perform owner-only actions.
- Unauthenticated users must never obtain authenticated capabilities.
- Password-reset tokens must belong to the intended account.
- OAuth authorization codes must be bound to the correct client/session.
- Payment amount must be server-authoritative.
- Discount must not be applied more than intended.
- Balance must never become negative through race conditions.
- Webhook signatures must be verified.
- Internal services must not be reachable through user-controlled URLs.
- Admin-only mutations must not be callable by normal users.
- A deleted/revoked session must no longer authorize requests.
- Server-side authorization must not depend on client-side UI state.
- Client-supplied tenant identifiers must never determine authorization.
- Sensitive credentials must never cross into attacker-controlled origins.

For each feature create, then attack the invariant:

```
ACTOR / ROLE / TENANT / RESOURCE / ACTION / STATE
TRUST BOUNDARY → SECURITY INVARIANT
EXPECTED AUTHORIZATION vs OBSERVED AUTHORIZATION
```

### Technology-aware routing

Fingerprint the stack and let it steer the strategy (do NOT test every class blindly):

- **GraphQL found** → introspection, field/object authorization, aliases, batching,
  mutation abuse, mass assignment, resolver inconsistencies, query complexity,
  federation, hidden fields.
- **OAuth/OIDC found** → redirect_uri, state, PKCE, code reuse, token audience,
  issuer validation, client confusion, login CSRF, account linking, identity mix-up,
  token leakage.
- **Next.js found** → API routes, middleware differences, server/client boundary,
  SSR/ISR caching, route handlers, image optimization, source maps, env exposure,
  middleware auth inconsistencies.

## §3 Authentication & session engine

Surface map: registration, login, logout, password reset, email/phone change,
MFA, OTP, magic links, email/phone verification, account recovery, session
creation/rotation, refresh tokens, remember-me, device trust, SSO, OAuth, OIDC,
SAML, API keys, service accounts.

Ask: *"Is there any path to become authenticated without satisfying the intended
authentication requirement?"*

- **Login**: user enumeration, response differentials, username/email normalization,
  case sensitivity, Unicode normalization, alternate identifiers, duplicate accounts,
  password policy bypass, auth race, session fixation, session regeneration,
  login CSRF, MFA bypass, device-verification bypass, anti-automation/CAPTCHA bypass.
- **Session**: logout invalidation, password-change invalidation, email-change
  invalidation, MFA-change invalidation, session rotation, concurrent sessions,
  refresh-token rotation + reuse detection, token audience/issuer/scope/expiration/
  revocation, cookie scope/domain/SameSite/Secure/HttpOnly, session fixation.
- Never report missing cookie hardening alone without meaningful exploitability.
- Recovery flows: token entropy, token binding to account+context, token
  expiration, host-header/poisoning influence on reset links, OTP rate limits,
  backup-code retrieval paths, account-recovery state confusion.

## §4 Authorization / IDOR / BOLA / tenancy engine (PRIMARY hunting engine)

Build at least two authorized identities: A = attacker, B = victim (test account).
Also test: same tenant, different tenant, different org, different role, anonymous,
suspended, deleted, invited, unverified, paid/free.

For every object identify and test ALL verbs — do not stop at GET:

```
object ID / owner / tenant / creator / role / resource type
→ read, create, update, delete, archive, restore, export, share, invite,
  approve, transfer, revoke, rotate, reveal, download, execute
```

A read-only IDOR may have siblings: GET → PUT → PATCH → DELETE → EXPORT → SHARE →
ADMIN → BULK → ASYNC JOB → DOWNLOAD.

Object relationships to walk:

```
user → organization → project → file → version
user → invoice → payment
workspace → member → role
device → owner ; API key → tenant ; webhook → organization
```

Signals: missing ownership check, missing tenant scope, client-controlled
tenant_id, alternate object IDs, UUID/base64 encodings, nested object references,
bulk endpoints, GraphQL nodes, export endpoints, background jobs, downloadable artifacts.

**Multi-tenancy engine** — construct Tenant A (users A1, A2, resources) and Tenant B
(same shape); test read/write/delete/invite/share/export/search/analytics/webhooks/
billing/API keys/integrations/admin across the boundary. Watch: tenant_id,
organization_id, workspace_id, account_id, company_id, owner_id, project_id.
Client-supplied tenant context must never become authorization authority.

**Admin / privilege-escalation engine** — map anonymous → user → verified → paid →
member → manager → owner → admin → superadmin; test hidden admin endpoints,
frontend-only role checks, API-only admin routes, alternate HTTP methods, GraphQL
mutations, mass assignment of role/permission fields, tenant ownership, invitation
roles, support/admin interfaces. Never test admin functions against real users.

## §5 Business-logic & race engine

Business logic is a FIRST-CLASS category. Model workflows as state machines:

```
CREATED → VERIFIED → APPROVED → PAID → SHIPPED → COMPLETED
```

Ask: *"What assumption does the developer make about the previous step?"* Then break it:

- Skipping/reversing/repeating states; replaying actions; parameter changes after
  authorization; ownership change after approval; parallel actions; out-of-sequence
  endpoint invocation; stale objects; hidden-field manipulation; client/server
  state disagreement.
- Approval/verification/cancellation bypass; refund/discount/credit/quota/limit/
  trial/referral/invitation abuse; subscription up/downgrade logic; currency,
  quantity, price manipulation.

**State-machine analysis** — for each workflow: can B be skipped? C reached
directly? A repeated? B replayed? Ownership change between B and C? An old token
perform C? Another account trigger C? Object modified after authorization?
Concurrent requests create invalid state?

**Race-condition engine** — target money, credits, coupons, inventory,
reservations, invitations, role changes, password reset, email verification, OTP,
token redemption, refunds, withdrawals, transfers, quota, limits. Model
`CHECK → STATE → ACTION`; ask whether two concurrent requests both pass the check.
Look for TOCTOU, duplicate redemption, double spending, repeated state transitions,
duplicate role assignment, token reuse, stale authorization. Test minimally, only
where authorized, never causing financial/destructive impact when a safe test
object can demonstrate it.
