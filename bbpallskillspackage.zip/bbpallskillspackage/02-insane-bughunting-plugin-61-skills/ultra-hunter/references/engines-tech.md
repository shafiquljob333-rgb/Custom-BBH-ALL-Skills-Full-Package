# Engines — Technology surfaces

## §6 API / GraphQL engine

For every API inspect: authentication (missing/inconsistent auth, legacy endpoint
bypass, alternate routes, method confusion, API-version inconsistency, mobile/API
mismatch) · authorization (object-level, function-level, field-level, tenant-level,
role-level) · input (type confusion, mass assignment, hidden fields, unexpected
arrays, duplicate parameters, parameter pollution, JSON structure confusion, nested
object manipulation, prototype pollution candidates, parser differentials) ·
output (excessive data, secrets, internal identifiers, PII, tokens, debugging info,
stack traces, authorization metadata) · state (replay, idempotency, race, stale
token, stale authorization, workflow bypass).

**API differentials** — compare web vs mobile vs legacy vs new vs internal vs
GraphQL vs REST for the same resource. Inconsistency between surfaces is a major
signal (one surface often misses the authorization the other enforces).

**GraphQL specifics** — introspection, hidden types/fields, deprecated fields,
mutations, resolver/field/object authorization, tenant isolation, aliases, batching,
fragments, nested relationships, node/global IDs, mutation replay, mass assignment,
query complexity/depth, persisted queries, introspection via alternate routes/methods.
CRITICAL: introspection alone is usually NOT a vulnerability — find the sensitive
mutation that lacks authorization. `introspection → sensitive mutation discovered →
no authorization → unauthorized state change → concrete impact` is the finding.

## §7 SSRF / URL / OAuth / webhook engine

**Server-side URL consumers** — URL preview, webhooks, imports, image fetch, PDF
generation, screenshots, avatar fetch, link unfurling, integrations, callbacks,
health checks, proxy endpoints, feed readers, XML, GraphQL URL arguments, cloud
integrations.

Determine `USER INPUT → SERVER-SIDE REQUEST → DESTINATION CONTROL → INTERNAL
REACHABILITY → RESPONSE/SIDE EFFECT`. Distinguish DNS resolution from TCP
reachability from HTTP request from response reflection from internal data
retrieval from metadata/credential access. Do not call DNS-only behavior "SSRF".
Investigate localhost/loopback, RFC1918, IPv6, DNS rebinding, alternate IP
representations, redirect handling, parser discrepancies, hostname validation,
protocol confusion, cloud metadata (only where explicitly authorized). Use safe
proof; never broad internal scanning; stop when the boundary violation is proven.

**Redirect discipline** — do not auto-report open redirect. Test whether it
chains: OAuth code theft, token leakage, password-reset poisoning, SSO token
leakage, referer leakage, credential disclosure.

**OAuth/OIDC chains** — redirect_uri validation (exact host/path matching,
wildcards), state, PKCE, nonce, issuer, audience, client binding, code reuse,
code substitution, account linking, login CSRF, fragment/query leakage,
cross-client confusion. Full chain skeleton:
`ATTACKER → VICTIM ACTION → AUTH CODE/TOKEN → ATTACKER CONTROL → EXCHANGE →
SESSION → ACCOUNT CAPABILITY` — every stage must be demonstrated before claiming
top severity.

**Webhook/integration engine** — map every integration (Slack, Discord, GitHub/
GitLab, Google, Microsoft, Stripe, CRM, email, storage, CI/CD); test signature
verification, replay, tenant binding, source validation, callback manipulation,
SSRF, account linking, OAuth scopes, token leakage, event substitution,
authorization after integration removal.

## §8 Injection / XSS / files / JWT / secrets engine

**Injection** — contextually test SQLi, NoSQLi, LDAP, XPath, SSTI, OS command,
expression/template injection, ORM injection, header injection, CRLF, CSV,
deserialization. Never spray payloads blindly; first map
`INPUT → PARSER → INTERPRETER → SINK`, then prove control.

**XSS/HTML/DOM** — reflected, stored, DOM, mutation XSS, SVG, Markdown, rich text,
templates, emails, PDFs, notifications, admin panels, support tickets, chat,
comments, filenames, import/export, postMessage, iframe communication. Trace
`SOURCE → TRANSFORMATION → SANITIZATION → CONTEXT → SINK`; contexts: HTML,
attribute, JavaScript, CSS, URL, DOM, template, Markdown. Focus on privileged
users, admin panels, stored content, cross-user impact. Do not report harmless
reflection without executable impact.

**Files/uploads** — upload, download, preview, conversion, image processing,
archive extraction, filename handling, MIME/extension validation, path
normalization, object storage, signed URLs, import/export. Look for unrestricted
file access, cross-tenant files, path traversal, arbitrary overwrite, unsafe
types, stored XSS, SSRF through parsers, archive traversal, temp-file exposure.

**JWT/tokens** — algorithm, signature verification, issuer, audience, subject,
expiry, nonce, key selection/rotation, JWK/JWKS, kid, token type, scope, target
service. Weaknesses: algorithm confusion, signature bypass, wrong issuer/audience,
cross-service token acceptance, token substitution, replay, excessive lifetime,
missing revocation, privilege claims trusted from client. Never claim JWT
compromise until the forged/replayed token produces an unauthorized capability.

**Secrets** — search client-side/public artifacts for API keys, cloud keys, OAuth
secrets, service credentials, signing keys, private tokens, DB credentials.
`SECRET FOUND ≠ VULNERABILITY` — validate `SECRET → AUTHENTICATION → SERVICE →
PRIVILEGES → RESOURCE → REAL ACCESS` with the smallest safe proof. Never expose
real secrets in reports.

## §9 Browser / cache / cloud / mobile engine

**CORS/CSRF** — CORS: do not report `ACAO: attacker` alone; test credentials mode,
sensitive authenticated responses, actual cross-origin read, preflight behavior,
origin normalization, null origin, wildcard subdomains, trusted-but-takeoverable
origins. CSRF: state-changing operations (email/password change, API key
creation, payments, withdrawals, role changes, invites, account linking, security
settings). SameSite is not automatically sufficient — consider top-level navigation
semantics and sibling-origin relationships.

**Cache/proxy/HTTP** — cache poisoning, cache deception, host-header issues,
forwarded-header trust, path/parameter normalization, request smuggling, HTTP/2
inconsistencies, CDN/origin differences, cache-key mismatch, authorization caching,
private-response caching. Always distinguish interesting parser behavior from
attacker-controlled security impact.

**Cloud/infrastructure** (only where in scope) — S3/GCS/Azure Blob, Firebase,
CDN, cloud functions, serverless, container registries, CI/CD, GitHub/GitLab,
package registries, public dashboards, K8s-facing interfaces, exposed management
panels. Test read/write/list/delete, privilege boundaries, tenant isolation,
credential reuse. Public configuration ≠ secret.

**Mobile** — APK/IPA analysis, API endpoints, certificates, secrets, deep links,
universal links, WebViews, exported components, intents, local storage,
authentication/token handling, biometric bypass, root/jailbreak checks,
mobile-only endpoints, backend trust of mobile claims. The mobile client is
untrusted: any decision enforced only client-side must be retested at the server
boundary.

## §10 Hidden-surface / sibling / trust-boundary engine

**Sibling mapping** — for every finding or interesting endpoint, immediately ask
*"what else exists nearby?"* Search same controller, prefix, API version,
resource, GraphQL namespace, JS module, backend service, permission middleware,
database object, feature flag. Example — found `GET /api/user/export`:
investigate `POST /api/user/export`, `/api/user/export/status`, `DELETE`,
`/api/user/download`, `/api/user/history`, `/admin/api/user/export`,
`/v2/api/user/export`, mobile + GraphQL equivalents. A bug in one route is a
SIGNAL, not necessarily the final finding.

**Hidden/legacy surface** — old API versions, deprecated endpoints, staging/dev/
beta/preview/internal/legacy/migration/debug/test/admin/backup paths, old frontend
bundles, forgotten subdomains/integrations. A reachable dev host is NOT
automatically a bug: determine scope, ownership, intended exposure, boundary,
actual impact.

**Trust-boundary map** — Browser→API, User→Tenant, Tenant→Tenant, Frontend→
Backend, API→Internal Service, App→Cloud, App→Third Party, Webhook→App,
IdP→App, Upload→Parser, User URL→Server Network. For every boundary ask *"what
prevents crossing it?"* then attempt to falsify that control.

**Security-control bypass engine** — when you find a control, model CONTROL →
INTENDED PURPOSE → INPUT → VALIDATION → TRUSTED VALUE → SERVER ENFORCEMENT →
FAILURE MODE. Then test missing/empty/null/duplicate values, type confusion,
alternate encodings/endpoints/methods/API versions/clients, replay, stale tokens,
cross-context tokens, different tenant/role, race, state manipulation. Goal:
determine whether the control is actually enforced at the boundary.

**Developer-psychology shortcuts** — authorization on one route but not siblings;
UI validation without server validation; auth middleware missing on legacy routes;
copied endpoints with old permissions; trust in client-provided fields; internal
endpoints accidentally exposed; staging code in production; optional auth; async
jobs bypassing original authorization; bulk endpoints missing per-object checks;
exports bypassing UI controls; background workers trusting user metadata.

## §11 Business-type playbooks

- **E-commerce**: price/quantity manipulation, coupons, refunds, gift cards,
  wallet, order ownership, shipping, inventory, payment state, checkout race,
  discount stacking.
- **Fintech**: account isolation, transfers, withdrawals, balance, KYC,
  beneficiaries, transaction authorization, limits, races, payment state.
- **Marketplace**: buyer/seller isolation, order ownership, seller actions,
  payouts, reviews, inventory, refunds, messaging, identity verification.
- **SaaS**: tenant isolation, role escalation, sharing, exports, API keys,
  integrations, SSO, admin controls, invitations.
- **Crypto**: wallet ownership, withdrawals, signing, API credentials, transaction
  state, webhook integrity, races.
- **AI products**: prompt/data isolation, cross-user memory, system-prompt
  leakage, tool authorization, plugin permissions, agent actions, file access,
  SSRF, connector authorization, tenant isolation, model/API key exposure.
- **Developer platforms**: repo isolation, CI/CD, runners, secrets, webhooks,
  OAuth, package publishing, org roles, deployment permissions.

**Hunting priority matrix** (adjust per target): Authentication/Authorization/
Money/Tenancy/Recovery/OAuth/Business-logic/Admin = P0. API/Files/Integrations/
Webhooks/Legacy APIs = P1. Cosmetic UI = P4.
