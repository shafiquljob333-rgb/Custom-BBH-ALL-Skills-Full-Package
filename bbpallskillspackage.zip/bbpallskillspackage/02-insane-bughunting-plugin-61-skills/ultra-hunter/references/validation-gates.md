# Validation, chaining, duplication, severity, reporting

## §1 Falsification & evidence discipline

For every suspected vulnerability, do NOT ask *"how can I prove this is
vulnerable?"* — ask *"what evidence would prove my hypothesis WRONG?"* and attempt
to disprove it: intended behavior, documentation, authorization, alternate
controls, server-side checks, rate limits, tenant enforcement, token binding,
expiration, state requirements, compensating controls. Only promote a finding when
alternative explanations are eliminated or clearly documented.

**Evidence classification** — tag every observation; never upgrade tags without
new evidence:

```
[OBSERVED]    directly observed behavior
[VERIFIED]    repeated independently and confirmed
[DOCUMENTED]  supported by official docs/source code
[INFERRED]    logical conclusion from observed facts
[HYPOTHESIS]  possible behavior not yet proven
[UNKNOWN]     insufficient evidence
```

Never write "attacker can compromise the entire infrastructure" when the evidence
only proves "attacker can initiate TCP connections to an internal destination."

**Server-side proof rule** — prefer server-side authorization/state transitions/
resource access/capabilities over UI visibility, hidden buttons, client-side
validation, HTTP 200 alone, unusual errors, endpoint existence, exposed schema.
Ask: *"What unauthorized capability does the server actually grant?"*

## §2 Differential testing & negative controls

Controlled comparisons — User A vs B, Owner vs non-owner, Member vs anonymous,
Admin vs user, Authenticated vs unauthenticated, Valid vs invalid vs foreign-tenant
vs deleted objects, legitimate vs random vs expired vs wrong-context tokens,
reachable vs nonexistent vs closed ports. Observe status, body, headers, timing,
redirects, cookies, state changes, downstream effects.

A difference is a SIGNAL, not automatically a vulnerability — then determine
whether the difference violates a security invariant. Timing difference alone is
never proof; use controls and repeated interleaving.

Every important test gets a negative control. Controls prevent false conclusions.

**Automation strategy** — automation is FOR discovery, normalization, dedup,
comparison, repetitive low-risk checks, response clustering, endpoint/parameter
extraction, fingerprinting, historical correlation, anomaly detection. It is NOT
for uncontrolled scanning, brute force, payload spraying, DoS, endpoint bombing,
real-user targeting. `AUTOMATION → DISCOVERY → REASONING → TARGETED TEST →
SERVER-SIDE VERIFICATION`. Information gain per request, not request count.

## §3 False-positive kill engine

Aggressively kill weak hypotheses. Downgrade/kill if: only theoretical · no real
capability · no boundary crossing · intended/documented behavior · data is
intentionally public · endpoint dead · feature unreachable · too many unsupported
preconditions · another server-side control blocks the attack · only a status
code differs · only a UI restriction bypassed but the server correctly authorizes ·
secret is public by design · open redirect has no chain · introspection exposes
nothing exploitable · SSRF is DNS-only · rate-limit behavior has no security
consequence.

Core question: *"What does the attacker walk away with?"* If the answer is
"nothing meaningful" — KILL.

**Five-minute/one-hour discipline** — if a host yields only 401/403/404/static
pages/dead infrastructure with no signal, MOVE ON. If deep investigation of one
hypothesis produces no new evidence, CHANGE ANGLE: endpoint→sibling, web→API,
API→mobile, user→tenant, read→write, sync→async, frontend→backend,
authentication→authorization, primitive→chain. Never confuse persistence with
progress.

**Information-gain prioritization** — rank every possible next action by:

```
Expected Security Value × P(meaningful finding) × Novelty × Impact
× Information Gain ÷ Request Cost ÷ Risk ÷ Duplicate Probability
```

Prefer actions that answer multiple questions at once (an authorized A/B object
swap simultaneously tests IDOR, tenant isolation, ownership, role enforcement,
response leakage).

## §4 Chaining: A→B→C protocol & cluster protocol

Every confirmed primitive triggers a controlled sibling hunt. Classic chains:
IDOR→write→privilege/state manipulation · SSRF→internal reachability→internal
service interaction · XSS→session exposure→account impact · open redirect→OAuth
redirect→token/code theft · GraphQL introspection→sensitive mutation→authorization
bypass · secret exposure→service access→privilege escalation · enumeration→
anti-automation bypass→authentication abuse · CORS→credentialed response→data
theft · host-header→password-reset poisoning→account compromise · rate-limit
weakness→OTP/password attack→ATO.

**RULE: never report "A could theoretically chain into B."** Instead: (1) confirm
A, (2) identify B, (3) safely validate B, (4) confirm C if necessary, (5) report
only the demonstrated chain. Classify every chain stage: DEMONSTRATED / STRONGLY
SUPPORTED / PLAUSIBLE / SPECULATIVE. One strong chain beats five theoretical
findings. Do not artificially chain unrelated bugs — a chain requires: A's
capability satisfies B's prerequisite, same trust boundary, reproducible,
material impact increase.

**Finding cluster protocol** — when a real bug is confirmed, DO NOT immediately
report. First: confirm it → identify root cause → map sibling endpoints → search
for the same trust assumption → test safe siblings → look for stronger capability
→ cross-tenant impact → write/delete/admin capability → chain opportunities →
quantify affected resources safely → analyze duplicates → decide report/chain/
split/defer/kill. Do not create multiple reports for symptoms of one root cause
unless program rules clearly support separate value.

**Impact amplification (safely)** — can the capability reach read→write, one
account→many, one tenant→all, user→admin, metadata→credentials, SSRF→internal
privileged service, token leak→authenticated session, business logic→financial
impact? Do NOT escalate merely because the company is large, the endpoint is
sensitive, or a theoretical chain exists. Stop once sufficient impact is
established.

## §5 Duplicate / novelty / regression analysis

When historical reports are available (see `h1-report-db` / `duplicate-detector`
skills), treat them as a knowledge base. For each relevant historical finding
extract: asset, endpoint, parameter, object, role, tenant, vulnerability class,
root cause, attack primitive, workflow, state, impact, remediation, bounty,
status, evidence quality.

Do NOT compare titles only. Compare: ROOT CAUSE · SECURITY BOUNDARY · RESOURCE ·
AUTHORIZATION MODEL · EXPLOITATION METHOD · WORKFLOW · STATE · IMPACT ·
REMEDIATION. Classify: DUPLICATE · REGRESSION · SYSTEMIC VARIANT · DISTINCT ROOT
CAUSE · DISTINCT IMPACT · MATERIALLY NEW ATTACK PATH.

"Different parameter" does not automatically mean new. "Different endpoint" does
not automatically mean new. Same root cause + same boundary + same impact →
likely duplicate/systemic variant.

**Regression hunting** — for a historical vulnerability, do not just reproduce:
was it actually fixed? Did the fix cover siblings? Was only one route patched?
Did the API version change? Did a new frontend bypass the fix? Mobile API retain
it? GraphQL retain it? Internal service retain it? Did remediation create a new
bypass? Outcomes: FIXED / REGRESSION / PARTIAL FIX / SYSTEMIC VARIANT / NEW ROOT
CAUSE.

## §6 Evidence-gathering & severity discipline

**Pre-severity gate** — before calling anything High/Critical, answer: authorized?
in scope? unintended? which invariant violated? what exact unauthorized capability?
server-side violation demonstrated? full chain demonstrated? concrete impact?
reproducible? severity consistent with impact? remaining security gate? could the
program classify it informational? known duplicate/systemic issue? materially
novel? impact safely demonstrable? If multiple answers are UNKNOWN — do not claim
High/Critical; use: research lead / low-confidence candidate / deferred /
primitive only / needs validation / kill.

**Severity engine** — base on attacker privilege, attack complexity, user
interaction, security boundary, C/I/A, scale, business impact, exploitability,
prerequisites. "SSRF" is not automatically High. "IDOR" is not automatically High.
"XSS" is not automatically High. "JWT issue" is not automatically Critical.
Critical = broad ATO, tenant-wide compromise, admin compromise, substantial
financial theft, meaningful RCE, systemic credential compromise. Never inflate
severity to maximize bounty — severity follows demonstrated capability.

**Finding-note template** (maintain for every candidate):

```
Finding ID / Target / Feature / Endpoint / Actor / Role / Tenant / Resource /
Action / State / Security Invariant / Observed vs Expected / Root Cause /
Unauthorized Capability / Boundary Crossed / Concrete + Business Impact /
Evidence / Negative Controls / Reproduction + Reproducibility / Preconditions /
Chain Opportunities + Evidence / Compensating Controls / Duplicate Analysis /
Confidence / Severity / Why It Matters / Unknowns /
Decision: [KEEP | INVESTIGATE | CHAIN | KILL | REPORT]
```

## §7 Report gates & triager simulation

**Finding readiness gate** — report-ready only when ALL pass: authorized · in
scope · reproducible · unintended · invariant identified · server-side violation
demonstrated · unauthorized capability demonstrated · concrete impact ·
preconditions understood · alternative explanations eliminated · existing controls
tested · duplicate risk analyzed · novelty evaluated · severity justified ·
evidence preserved · safe reproduction possible · concise · no overclaim · no
unnecessary sensitive data.

**Triager simulation** — before submitting, become the strictest triager: Can I
reproduce this? Definitely in scope? Actually unintended? Boundary clear? What
does the attacker gain? Impact demonstrated or theoretical? Is another control
still blocking? Could this be intended? duplicate? Is the resource actually
sensitive? Severity justified? Chain complete? PoC understandable in under 2
minutes? Anything overclaimed? Simpler explanation? Safer reproduction? Enough
evidence without unnecessary data? **If the triager can reasonably reject it: DO
NOT SUBMIT YET — investigate the rejection reason.**

**Final security gate**: AUTHORIZED → IN SCOPE → UNINTENDED → INVARIANT VIOLATED →
SERVER-SIDE → UNAUTHORIZED CAPABILITY → CONCRETE IMPACT → REPRODUCIBLE → NOVEL →
LOW DUPLICATE RISK → SAFE → PROFESSIONALLY DOCUMENTED. Any critical gate fails →
KILL / DEFER / INVESTIGATE / REFRAME. Never submit weak findings because they are
interesting.

## §8 Report structure & writing

Sections: **Title** (`[Root cause] allows [attacker] to [unauthorized capability]`)
· **Severity** (evidence-based) · **Asset** (exact domain/API/app) · **Summary**
(attacker → vulnerability → capability → impact, one paragraph) · **Preconditions**
(exactly what the attacker needs) · **Steps to Reproduce** (copy-paste-ready,
zero-context replayable) · **Expected vs Actual** (clearly separated) · **Security
Impact** (`capability → affected resource → security consequence → business
consequence`) · **Root Cause** (the implementation/design failure) · **Evidence**
(minimal but convincing; redact real secrets, unrelated PII, session tokens) ·
**Scope** (why the asset is authorized) · **Novelty/Duplicate Analysis**
(distinct / regression / systemic variant / duplicate / unknown) · **Remediation**
(fix the root cause, not the symptom) · **Testing Scope** (accounts used,
environments, request counts, data accessed, actions performed).

Impact section separates: demonstrated / strongly supported / theoretical — never
mix them. A triager should be able to answer from the report alone: what is broken,
why security-sensitive, who can exploit, what authorization is missing, what
resource is affected, can I reproduce, why the business cares.

Avoid: dramatic language, unsupported claims, "could potentially", "might lead to
Critical", payload dumps, irrelevant recon, huge logs, speculative diagrams.
Prefer: *"An unauthenticated user can perform X against Y because Z authorization
check is absent. Reproduced with two controlled accounts, resulting in A."*

Do NOT write 1,500 words when 500 precise words prove the issue.
