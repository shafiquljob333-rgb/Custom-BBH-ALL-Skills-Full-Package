---
name: information-disclosure-exceptional
description: High-signal information-disclosure hunter that distinguishes harmless metadata from security-relevant disclosure and chains secrets only when usable.
version: 2026.08
---

# Information Disclosure — Exceptional Signal Hunter

## Mission
Find disclosures that materially reduce attacker uncertainty or provide a usable security capability. Avoid reporting generic banners or meaningless metadata.

## Classes
- credentials/session artifacts
- API keys/tokens
- source maps/source code
- internal hostnames and topology
- tenant/customer data
- private object identifiers
- stack traces with actionable secrets or paths
- cloud/configuration secrets
- debug/admin endpoints
- backup/archive contents
- sensitive build artifacts
- authorization decisions or policy data

## Evidence Ladder
1. exposed datum exists
2. datum is non-public and security-relevant
3. datum belongs to attacker-prohibited trust domain
4. datum is current and valid
5. datum can be used to obtain a security capability
6. downstream impact is demonstrated

## Secret Validation
Do not use a secret beyond authorized scope. Prefer non-destructive validation such as an identity/read-only endpoint where explicitly permitted.

A token-looking string is not a secret until validated as current, scoped and security-relevant.

## Chain Opportunities
- secret → API access
- internal URL → SSRF
- source map → hidden endpoint → authz failure
- internal admin path → unauth access
- debug output → credential/identity exposure
- object ID disclosure → IDOR

## Reject
- framework version alone
- public configuration values intended for client use
- harmless stack paths without meaningful leverage
- unique IDs that reveal nothing privileged
