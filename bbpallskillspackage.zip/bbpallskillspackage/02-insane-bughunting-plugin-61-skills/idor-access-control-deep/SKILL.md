---
name: idor-access-control-deep
description: Object-level, function-level and tenant-level authorization hunter using differential testing across identities, roles, representations and state.
version: 2026.08
---

# IDOR / Access Control — Deep Hunter

## Mission
Prove that the server grants a principal access or capability outside the principal's effective authorization set.

## Differential Matrix
At minimum compare where authorized:
```text
A → A-owned object
A → B-owned object
B → B-owned object
unauthenticated → A-owned object
low role → high-role object/action
Tenant A → Tenant B object
```

## Object Coverage
- users
- organizations
- teams
- invoices/orders/payments
- documents/files
- API keys/tokens
- chat/history
- exports
- jobs/tasks
- invitations
- shares
- subscription/entitlement objects

## Access-Control Classes
- BOLA/IDOR
- function-level authorization failure
- tenant isolation failure
- field-level authorization failure
- mass assignment
- privilege persistence after downgrade/removal
- soft-delete authorization gaps
- alternate endpoint/legacy API authorization
- GraphQL resolver authorization
- WebSocket subscription authorization
- asynchronous job authorization

## Representation Differential
Test equivalent object references across:
- numeric IDs
- UUIDs
- global IDs
- path segments
- query parameters
- JSON fields
- GraphQL node IDs
- export/download tokens

## Strong Proof
A valid result shows:
1. requester identity
2. target object's true owner/tenant/role
3. request that crosses the boundary
4. response or state change confirming unauthorized access
5. business impact

## Chain Review
Every read-IDOR should trigger a search for a corresponding privileged state change on the same object family: reset, refund, role change, membership, token issuance, export, delete.

## Kill Rules
Predictable IDs are not inherently vulnerable. A 200 containing public data is not automatically IDOR. The server must fail an authorization invariant.
