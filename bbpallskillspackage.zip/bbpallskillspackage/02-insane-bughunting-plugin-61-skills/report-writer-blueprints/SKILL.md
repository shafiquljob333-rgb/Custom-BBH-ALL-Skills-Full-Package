---
name: "report-writer-blueprints"
description: "Evidence-based report-writing blueprints built from the top-paying disclosed HackerOne reports, the highest-bounty Google VRP and Meta writeups, and Shreyas Chavhan's 5,000-report reading notes — how winning reports title findings, structure impact, prove exploitation, and avoid the triager-rejection patterns that plague LLM-drafted reports. Use when writing or reviewing a bug bounty report, when a draft needs a severity/impact upgrade, or when converting lab notes into a submission. Trigger on \"help me write this report\", \"review my report draft\", \"make this report stronger\", \"what should the title be\"."
---

# Report Writer Blueprints — Write Like The Reports That Got Paid

The difference between a paid report and an N/A is usually the writing, not the bug. This skill
distills the structure of the top-paying disclosed reports (see `references/h1_top_payouts.md` in
the `report-intelligence` skill) plus the rejection patterns from 5,000 report readings.

**Authorized targets only.**

## The winning title formula (from top-payout corpus)

`[Bug class] in [exact endpoint/feature] allows [attacker role] to [concrete impact]`

Real examples from the top-payout list: "RCE when removing metadata with ExifTool", "Account
takeover via leaked session cookie", "Ability to bypass partner email confirmation to take over
any store given an employee email". Notice: no buzzwords, no "critical!!!" — the impact IS the
title. A triager can triage the report from the title alone.

## Section skeleton (order matters)

1. **Title** — formula above.
2. **Summary** — 2–3 sentences: what, where, what an attacker actually gains. If the summary
   needs more than 3 sentences, the finding is probably two findings or needs sharper impact.
3. **Steps to Reproduce** — numbered, from a *zero-context* starting point (two accounts where
   auth matters, exact URLs, exact requests). The triager must be able to replay without asking
   you anything. Include the response evidence inline at each step, not all at the end.
4. **Impact** — the attacker's capability in business terms, tied to the program's own scope
   categories. Proven, not hypothetical: "attacker can X (demonstrated in step 6)" not "could
   lead to X".
5. **Supporting material** — screenshots with named files, short video PoC for multi-step chains,
   the raw request/response pair, and the exact payloads used.
6. **(Optional) Suggested fix** — one paragraph max, only if you actually know the correct fix.

## Impact phrasing — upgrade table

| Weak (rejected) | Strong (paid) |
|---|---|
| "Could allow an attacker to possibly..." | "Allows an attacker to read any user's invoice (step 5) |
| "Sensitive information may be leaked" | "Leaks the full name, address and masked card number of every customer in range 1–99999" |
| "An attacker with conditions X, Y and Z could..." | "Any authenticated user can... (no special conditions; tested with a standard account)" |
| "This is a serious security issue" | The impact sentence itself — never assert severity, demonstrate it |

## Severity & bounty calibration

Never guess. Look up the class in `report-intelligence`'s `h1_vuln_type_stats.md`: median is the
typical payout for the class, max is the best instance. State nothing numeric in the report — let
the triager price it — but use the data to decide whether your write-up effort is worth it and
whether to hunt for a stronger chain first.

## Pre-submission gates (in order)

1. Run the `duplicate-detector` skill. Its verdict must be UNIQUE or CHAINABLE with delta stated.
2. Run the `triage` skill's self-validation (READY / NEEDS FIXES / DO NOT SUBMIT).
3. Zero-context replay test: could a stranger run your Steps 1–N from a clean browser? If not,
   rewrite the steps.
4. AI-slop scan: no invented CVEs, no fabricated endpoints, no generic OWASP paragraphs, no
   theoretical impact. Every claim traces to a captured request/response you actually made.

## Post-submission

Triager questions = respond within a day with exactly what's asked, plus minimal context. If
N/A'd or dup'd, extract the root cause of the rejection into your session log — feed it back
into `bounty-hunting-lessons` and `duplicate-detector` next time.
