---
name: "platform-intel"
description: "Platform-specific attack-surface intelligence for the Google VRP (Google web/cloud/AI assets, 274 dated & bounty-tagged writeups) and Meta/Facebook bug bounty programs (Facebook, Instagram, WhatsApp, Threads, Messenger, Oculus/VR, 400 writeups). Extracts the recurring money-making themes per platform — Google: client-side RCE via URL/symlink parsing, service-account chains, enumeration leaks, OAuth takeover, AI/Gemini surfaces; Meta: ATO chains (FXAuth/datr), GraphQL IDOR, privacy-boundary leaks, 2FA bypass. Use when the authorized target is a Google or Meta property, or when deciding platform-specific hunting lanes. Trigger on \"google vrp\", \"facebook bounty\", \"instagram\", \"whatsapp\", \"hunting google\", \"meta bug bounty\"."
---

# Platform Intelligence — Google VRP & Meta/Facebook

Two of the highest-paying public programs have stable, learnable attack surfaces. This skill maps
the themes that keep winning, with dated & bounty-tagged writeup databases as evidence.

**Authorized targets only.** Both platforms have strict scope rules — verify current scope
documents before testing; VRP scope and Meta's program rules change.

## Google VRP — recurring themes across the writeup DB

Read `references/google_vrp_writeups.md` (274 writeups, newest first) and `references/facebook_writeups.md` for Meta.
Google-recurring money patterns:

- **Client-side RCE via URL/symlink/path parsing** in Google desktop apps (e.g. Web Designer
  CSS-injection RCE series) — desktop attack surface is under-hunted vs. web.
- **Cloud/IAM privilege chains:** service-account impersonation chains, Vertex AI / Apigee / Looker
  command injection and RCE, bucket traversal in client libraries — GCP product surface pays in the
  $3k–$20k+ range.
- **Enumeration & data leaks:** leaking any user's email/phone via YouTube or Assistant surfaces
  paid $5k–$20k repeatedly — enumeration with clean privacy-boundary proof wins.
- **OAuth/client takeover:** 1-click OAuth client takeovers via redirect/consent flaws.
- **AI surfaces (newest, growing):** Gemini/NotebookLM prompt-confusion, data exfiltration via AI
  features, agentic-browser/extension hijacks — the freshest lane in the DB (2025–2026).
- **Bounty signature:** Google pays exact unusual amounts ($3,133.7, $13,337) for style + severity.

VRP lesson from the data: novelty and cross-product chaining beat single-endpoint injection; most
big payouts were multi-step chains (XSS → OAuth → account data, parsing confusion → takeover).

## Meta/Facebook — recurring themes across the writeup DB

- **Account-takeover chains:** the program's signature payouts — FXAuth token abuse ($30k), datr
  cookie theft + trusted-device recovery ($24k), self-XSS chained into payments flow ATO ($62.5k),
  Messenger RCE ($111k). Chain small bugs into ATO; single low findings rarely pay.
- **Privacy-boundary leaks:** locked WhatsApp chats readable, private/archived Instagram posts
  exposed, blocked-user content leaks on Threads, page-admin disclosure — Meta pays reliably for
  *demonstrated privacy-boundary crossing* even at $1k–$14k.
- **GraphQL IDOR:** business-account data sources, campaign-planner share links — test GraphQL
  object IDs cross-account aggressively.
- **2FA/auth bypass:** backup-code retrieval bypass ($10k), 2FA bypass chains ($25k), email
  confirmation bypass — auth-state machine edges, not just login endpoints.
- **Business/creator tooling:** Ads/Creative Hub/Business Manager permission gaps — high-function
  surfaces with weaker testing attention.

## Workflow on a platform target

1. Read the platform's writeup DB *filtered to the last 12 months* first (newest section) — recent
   = most representative of current triager behavior.
2. Map the target asset to a recurring theme above; write the theme's chain skeleton *before*
   touching the target (e.g. "find self-XSS surface → look for token-in-URL auth flow → chain").
3. Before reporting, grep the DB for your exact pattern — Meta especially rewards *novel* chains;
   if your chain matches a disclosed one, find the differentiator (different token, different
   surface, stronger impact) or drop it.
4. Mind program rules: Meta disallows some automated testing; Google VRP has special scope
   (android, hardware, cloud) tiers with separate rule sets — read them per engagement.

## Evidence files

- `references/google_vrp_writeups.md` — 274 writeups: date, bounty, title, link, author.
- `references/facebook_writeups.md` — 400 writeups in the same format.
Grep by product, bug class, or year. Open the writeup itself when technique details matter.
