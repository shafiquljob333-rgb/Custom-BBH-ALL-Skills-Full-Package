---
name: race-condition-impact-hunter
description: Deep race/TOCTOU/idempotency hunter focused on maximum security impact with minimal safe concurrency and invariant-based validation.
version: 2026.08
---

# Race Condition / TOCTOU — Maximum Impact Hunter

## Mission
Find race conditions where concurrency breaks a security or business invariant: money, authorization, identity, quota, verification, inventory, entitlement, or one-time state.

## Candidate Signals
- check → async wait → mutation
- read → external service → write
- verify token → consume token
- authorize → async lookup → action
- inventory check → payment → decrement
- coupon check → order → mark used
- create object → initialize security state later
- cache/session state updated asynchronously

## High-Value Targets
1. payment/withdrawal/refund/transfer
2. account creation + verification
3. MFA/OTP/password-reset consumption
4. privilege/membership transitions
5. quota/credits/gift cards
6. subscription/trial entitlement
7. file/share permission changes
8. one-time links or invites

## Race Classes
- limit-overrun
- check-and-use TOCTOU
- creation/construction window
- cancellation/refund race
- token-reuse race
- permission revocation race
- idempotency failure
- distributed consistency race
- queue/retry duplication
- cache-versus-database state race

## Validation
A race is proven only when all three are shown:
- N synchronized requests
- observed successes greater than intended
- resulting invariant violation

Record:
- concurrency N
- synchronization method
- number of rounds
- baseline result
- race result
- exact state after race

Use the smallest concurrency that reliably reproduces the issue. Do not stress production.

## Maximum-Impact Chain Review
After proving a race, ask:
- Can it create/transfer/withdraw value?
- Can it grant an entitlement more than once?
- Can it preserve access after revocation?
- Can it consume a one-time authentication factor repeatedly?
- Can it create two identities/resources where only one was intended?
- Can it combine with IDOR or privilege escalation?

## Safe Request Model
Use a test account, disposable object and bounded rounds. Example structure:
```text
REQUEST A: state-changing action
REQUEST B: identical action or competing transition
GATE: synchronized send
POST-CONDITION: compare durable state
```

## False Positives
Do not report duplicate 200 responses if the backend correctly deduplicates them. HTTP 2xx alone is not proof. Confirm persistent side effects.

## Report Rule
Report the invariant violation, not merely “race condition exists.” State exactly what should happen once, what happened multiple times, and what security/business boundary was crossed.
