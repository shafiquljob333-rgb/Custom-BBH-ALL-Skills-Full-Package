# Recurring title patterns in disclosed HackerOne reports

Bigram frequency in report titles per vulnerability class - a fast prior for what payloads/sinks/locations actually produce paid bugs.

## information_disclosure (856 reports)

`information disclosure` (108), `sensitive information` (21), `at https` (20), `can be` (19), `private program` (18), `dod website` (16), `path disclosure` (15), `full path` (13), `disclosure vulnerability` (13), `server version` (13), `version disclosure` (13), `user information` (11)

## improper_access_control_generic (535 reports)

`access control` (35), `can be` (24), `improper access` (21), `s3 bucket` (13), `account takeover` (11), `users can` (10), `subdomain takeover` (9), `at https` (9), `unauthorized access` (8), `user can` (8), `information disclosure` (8), `reset password` (7)

## violation_of_secure_design_principles (442 reports)

`content spoofing` (32), `text injection` (18), `error page` (15), `no rate` (14), `nextcloud com` (13), `password reset` (11), `rate limiting` (11), `rate limit` (10), `subdomain takeover` (9), `email spoofing` (9), `host header` (8), `can be` (8)

## cross_site_scripting_xss_reflected (429 reports)

`reflected xss` (229), `xss https` (70), `site scripting` (51), `cross site` (50), `https www` (29), `xss at` (26), `xss reflected` (23), `at https` (23), `xss www` (18), `reflected cross` (18), `scripting xss` (15), `https parameter` (13)

## improper_authentication_generic (402 reports)

`account takeover` (23), `authentication bypass` (23), `password reset` (18), `rate limit` (17), `no rate` (14), `subdomain takeover` (10), `improper authentication` (9), `default credentials` (8), `no valid` (8), `valid spf` (8), `dod website` (8), `leads account` (7)

## cross_site_scripting_xss_stored (394 reports)

`stored xss` (237), `cross site` (37), `site scripting` (37), `stored cross` (23), `xss https` (14), `blind stored` (14), `xss at` (13), `at https` (11), `persistent xss` (10), `scripting https` (10), `xss stored` (9), `blind xss` (8)

## cross_site_scripting_xss_generic (392 reports)

`reflected xss` (61), `stored xss` (50), `cross site` (45), `site scripting` (41), `dod website` (35), `xss vulnerability` (27), `html injection` (20), `self xss` (20), `vulnerability dod` (20), `scripting xss` (16), `xss dod` (14), `xss at` (13)

## uncontrolled_resource_consumption (383 reports)

`denial service` (65), `null pointer` (24), `pointer dereference` (21), `prototype pollution` (17), `pollution attack` (14), `xmlrpc php` (12), `cache poisoning` (11), `service vulnerability` (9), `regular expression` (9), `expression denial` (9), `mrb vm` (9), `vm exec` (9)

## cross_site_request_forgery_csrf (283 reports)

`csrf token` (20), `cross site` (20), `account takeover` (17), `request forgery` (16), `site request` (14), `csrf protection` (12), `csrf vulnerability` (10), `rockstargames com` (8), `https www` (8), `csrf https` (8), `csrf account` (7), `csrf add` (6)

## business_logic_errors (276 reports)

`no rate` (16), `rate limit` (12), `can be` (10), `race condition` (8), `rate limiting` (8), `too eager` (5), `account takeover` (5), `business logic` (5), `user can` (4), `huge mass` (4), `mass mailings` (4), `attacker can` (4)

## privilege_escalation (266 reports)

`privilege escalation` (56), `subdomain takeover` (51), `takeover at` (19), `local privilege` (16), `can be` (9), `starbucks com` (9), `true image` (8), `code execution` (7), `acronis true` (7), `user can` (6), `acronis com` (6), `dll search` (5)

## memory_corruption_generic (250 reports)

`integer overflow` (27), `use after` (25), `after free` (25), `flash player` (22), `memory corruption` (22), `adobe flash` (20), `buffer overflow` (17), `out bounds` (17), `heap corruption` (16), `heap overflow` (16), `caused heap` (11), `corruption vulnerability` (11)

## insecure_direct_object_reference_idor (222 reports)

`account takeover` (10), `other users` (9), `direct object` (9), `idor vulnerability` (8), `idor delete` (8), `insecure direct` (8), `object reference` (8), `idor leads` (7), `can be` (7), `idor at` (5), `other user` (5), `without user` (5)

## code_injection (216 reports)

`code execution` (46), `remote code` (36), `code injection` (19), `dod website` (11), `arbitrary code` (9), `execution rce` (9), `html injection` (8), `server side` (7), `type confusion` (6), `rce dod` (6), `side template` (5), `template injection` (5)

## open_redirect (192 reports)

`open redirect` (121), `open redirection` (16), `redirect https` (12), `redirect at` (8), `https www` (8), `at https` (7), `header injection` (7), `host header` (6), `redirect vulnerability` (5), `protection bypass` (5), `uber com` (4), `login page` (4)

## server_side_request_forgery_ssrf (191 reports)

`blind ssrf` (32), `server side` (23), `side request` (22), `request forgery` (22), `forgery ssrf` (10), `ssrf vulnerability` (9), `ssrf at` (8), `full read` (5), `read ssrf` (5), `is vulnerable` (5), `ssrf https` (4), `internal ports` (4)

## sql_injection (156 reports)

`sql injection` (113), `injection https` (17), `injection vulnerability` (17), `dod website` (17), `vulnerability dod` (16), `blind sql` (15), `viestinta lahitapiola` (10), `lahitapiola fi` (10), `injection webapp` (8), `injection at` (7), `https www` (6), `time based` (5)

## path_traversal (125 reports)

`path traversal` (64), `arbitrary file` (26), `file read` (12), `directory traversal` (9), `file deletion` (9), `unauthenticated arbitrary` (7), `at https` (7), `permission model` (6), `traversal at` (6), `traversal vulnerability` (6), `is vulnerable` (6), `read only` (6)

## command_injection_generic (122 reports)

`command injection` (25), `csv injection` (10), `code execution` (9), `remote code` (8), `command execution` (8), `privilege escalation` (6), `injection vulnerability` (5), `injection at` (4), `export feature` (4), `concatenates unsanitized` (4), `unsanitized input` (4), `input into` (4)

## cross_site_scripting_xss_dom (111 reports)

`dom based` (35), `based xss` (31), `dom xss` (25), `xss https` (7), `cross site` (6), `site scripting` (6), `shopify api` (6), `https www` (6), `www rockstargames` (6), `rockstargames com` (6), `xss www` (5), `xss shopify` (4)

## cryptographic_issues_generic (91 reports)

`is vulnerable` (8), `poodle attack` (4), `com is` (4), `missing certificate` (4), `certificate authority` (4), `authority authorization` (4), `authorization rule` (4), `reads openssl` (3), `openssl cnf` (3), `cnf from` (3), `from home` (3), `home iojs` (3)

## ui_redressing_clickjacking (90 reports)

`clickjacking vulnerability` (8), `clickjacking at` (6), `clickjacking https` (6), `frame options` (4), `ui redressing` (4), `is vulnerable` (4), `login page` (4), `nextcloud com` (4), `vulnerable clickjacking` (4), `click jacking` (3), `wordpress org` (3), `clickjacking frame` (2)

## improper_restriction_of_authentication_attempts (84 reports)

`brute force` (18), `rate limit` (17), `no rate` (8), `login page` (7), `force protection` (6), `account takeover` (6), `rate limiting` (6), `bruteforce protection` (4), `missing brute` (4), `missing rate` (4), `force attack` (4), `current password` (4)

## misconfiguration (71 reports)

`subdomain takeover` (23), `takeover one` (17), `one subdomain` (15), `subdomain under` (15), `under mozaws` (13), `mozaws net` (13), `account takeover` (3), `wrong url` (3), `main page` (3), `sifchain finance` (3), `under mozgcp` (3), `mozgcp net` (3)

## privacy_violation (69 reports)

`information disclosure` (4), `user can` (4), `privacy violation` (3), `cam mic` (3), `credit card` (3), `sensitive information` (2), `is still` (2), `blocked user` (2), `tor browser` (2), `third party` (2), `disclosure due` (2), `due insecure` (2)

## cleartext_storage_of_sensitive_information (64 reports)

`api key` (10), `sensitive information` (6), `exposed github` (5), `github repository` (4), `token leaked` (3), `clear text` (3), `plain text` (3), `brave browser` (3), `key disclosure` (3), `secret key` (3), `key leaked` (3), `information disclosure` (3)

## http_request_smuggling (52 reports)

`request smuggling` (40), `http request` (36), `smuggling due` (12), `transfer encoding` (6), `due incorrect` (5), `incorrect parsing` (5), `smuggling https` (4), `header fields` (4), `cache poisoning` (3), `cve http` (3), `parsing multi` (3), `multi line` (3)

## improper_input_validation (45 reports)

`input validation` (5), `apache http` (4), `http server` (4), `improper input` (4), `apache airflow` (3), `denial service` (3), `twitter's cropping` (3), `cropping algorithm` (3), `during liquidation` (2), `liquidation exploiting` (2), `exploiting lack` (2), `lack validation` (2)

## classic_buffer_overflow (42 reports)

`buffer overflow` (20), `code execution` (3), `stack buffer` (3), `may cause` (3), `can lead` (2), `lead remote` (2), `remote code` (2), `cs go` (2), `cause shellcode` (2), `shellcode injection` (2), `malformed bsp` (2), `access violation` (2)

## os_command_injection (42 reports)

`command injection` (12), `remote code` (7), `os command` (7), `code execution` (5), `csv injection` (4), `command execution` (3), `remote command` (3), `leads rce` (3), `starbucks com` (2), `com cn` (2), `code injection` (2), `injection log4j` (2)

## buffer_over_read (42 reports)

`tcpdump before` (12), `before has` (12), `buffer over` (12), `over read` (12), `parser tcpdump` (11), `has buffer` (11), `read print` (10), `out bounds` (8), `buffer overread` (5), `buffer overflow` (5), `bounds read` (4), `oob read` (4)

## deserialization_of_untrusted_data (40 reports)

`code execution` (14), `remote code` (13), `execution rce` (6), `rce dod` (4), `dod website` (4), `deserialization vulnerability` (3), `phar deserialization` (3), `insecure deserialization` (3), `can lead` (2), `command execution` (2), `unsafe deserialization` (2), `sql injection` (2)

## insecure_storage_of_sensitive_information (39 reports)

`sensitive information` (5), `insecure storage` (3), `pii leak` (3), `storage sensitive` (2), `mtn co` (2), `co ug` (2), `leaking sensitive` (2), `username password` (2), `pulsessl vpn` (2), `github repository` (2), `user id` (2), `disclosure credentials` (2)

## use_after_free (38 reports)

`after free` (29), `use after` (28), `heap use` (8), `free read` (4), `cve heap` (3), `mod http2` (3), `ipv6 pktoptions` (2), `free unserialize` (2), `read size` (2), `free vulnerability` (2), `cve uaf` (2), `uaf ssh` (2)

## heap_overflow (38 reports)

`buffer overflow` (19), `heap buffer` (17), `heap overflow` (8), `overflow read` (7), `read size` (5), `read outside` (3), `outside buffer` (3), `size perl` (3), `cve heap` (2), `oob write` (2), `out bounds` (2), `overflow vulnerability` (2)

## crlf_injection (36 reports)

`crlf injection` (20), `injection nodejs` (3), `nodejs undici` (3), `injection http` (3), `undici host` (2), `http stage` (2), `mackeeper com` (2), `injection https` (2), `injection at` (2), `mariadb org` (2), `header injection` (2), `content type` (2)

## resource_injection (34 reports)

`management console` (5), `console editor` (5), `editor privilege` (5), `privilege escalation` (5), `escalation root` (5), `root ssh` (5), `ssh access` (5), `access github` (5), `github enterprise` (5), `enterprise server` (5), `server rce` (4), `html injection` (4)

## cleartext_transmission_of_sensitive_information (32 reports)

`hsts bypass` (5), `cve hsts` (4), `bypass idn` (4), `login form` (2), `form non` (2), `non https` (2), `https page` (2), `cleartext transmission` (2), `missing ssl` (2), `authorization header` (2), `rocket chat` (2), `cve another` (2)

## improper_authorization (31 reports)

`improper authorization` (3), `account takeover` (3), `permission can` (3), `user can` (2), `staff member` (2), `member settings` (2), `settings permission` (2), `hacker can` (2), `removed staff` (2), `staff members` (2), `members who` (2), `who had` (2)

## phishing (30 reports)

`content spoofing` (4), `text injection` (2), `missing spf` (2), `subdomain takeover` (2), `account hijack` (2), `broken link` (2), `address bar` (2), `bar spoofing` (2), `url link` (1), `link spoofing` (1), `brave shield` (1), `shield ios` (1)
