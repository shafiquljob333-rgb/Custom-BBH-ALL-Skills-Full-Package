---
name: "h1-report-db"
description: "Queryable knowledge base of 8,932 unique disclosed HackerOne reports (titles, bounties, vulnerability types, URLs) distilled from 30,000+ categorized rows across 163 vulnerability types, plus Shreyas Chavhan's field notes from reading 5,000 reports, organized into 44 bug-class categories with specific report links and takeaways. Use when hunting a specific bug class to see what exact patterns got paid (titles, sinks, features), when judging duplicate risk for a candidate finding, or when studying disclosed reports for a class before testing a target. Trigger on \"what XSS/IDOR/SSRF bugs got paid\", \"show me disclosed reports for\", \"is this a duplicate\", \"how much did X pay\"."
---

# H1 Report Database — Hunt What Gets Paid

This is the grounding layer: before testing any hypothesis, look up what the same class of bug
actually earned on real programs. Query-first hunting beats guessing.

**Authorized targets only.**

## Files in this skill (grep them; do not read whole files into context)

- `references/h1_reports_index.tsv` — 8,932 unique reports: `report_id, bounty, title, vuln_types, url`,
  sorted by bounty. **Primary query surface.**
- `references/h1_vuln_type_stats.md` — per-class report counts, median and max bounty.
- `references/h1_notes_by_category.md` — 44 categories of human-distilled notes (specific reports
  worth remembering + the takeaway lesson), from reading 5,000 HackerOne reports.
- `references/h1_title_patterns.md` — recurring title bigrams per class = proven sub-patterns.

## Query patterns

```bash
# Everything disclosed in your bug class (vuln_types is the 4th column)
grep -i "idor" references/h1_reports_index.tsv | head -30

# Your target's feature area + class, to gauge duplicate risk
grep -i "password reset" references/h1_reports_index.tsv | grep -i "authentication"

# What the top of a class looks like (file is bounty-sorted)
head -50 references/h1_reports_index.tsv

# A specific pattern you suspect
grep -i "s3 bucket" references/h1_reports_index.tsv
```

## Workflow

1. **Lane pick:** class frequency + median bounty from `h1_vuln_type_stats.md`.
2. **Hypothesis generation:** read the top-20 titles for the class in the index; note recurring
   sinks/features (these are the community-proven hotspots). Then check
   `h1_title_patterns.md` bigrams for the concrete sub-patterns.
3. **Duplicate risk:** before writing up, grep titles for your class + your target's feature area;
   then read the matching section of `h1_notes_by_category.md` (the reports the author flagged as
   memorable in that class are the most-repeated patterns in the wild).
4. **Title/impact phrasing:** steal the one-line impact structure from the top-bounty titles in
   your class (columns 3 and 2).

## Interpretation rules

- Bounty medians are per-class across all programs; a specific program's table may cap lower.
- A pattern appearing dozens of times in the DB means it's a *proven detection technique* — but on
  mature programs it also means *duplicate risk is high*. Favor it on newer scopes; chain it on
  mature ones.
- Absence from the DB is not proof of novelty — it means no disclosed report matched; private
  reports can't be seen.
- Always open the linked report itself (5th column) when it will change your decision. The index
  is a map; the report is the territory.

## Data provenance

Compiled from the community-maintained `codebygk/hackerone-bug-bounty-reports` dataset (disclosed
reports only, links to HackerOne preserved), de-duplicated across category files. Report content
belongs to its authors/HackerOne; this skill indexes and links it.
