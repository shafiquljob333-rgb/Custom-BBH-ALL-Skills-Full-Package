---
name: http-request-smuggling-all-types
description: Deep HTTP request-smuggling analyzer covering HTTP/1.1 parsing differentials, CL/TE and TE/TE families, HTTP/2 downgrade boundaries, cache/front-end desync and safe timing/benign-marker validation.
version: 2026.08
---

# HTTP Request Smuggling — All Types

## Mission
Find parser differentials between front-end and back-end components that allow one party to interpret request boundaries differently from another.

## Architecture First
Identify:
- CDN / WAF
- reverse proxy
- load balancer
- service mesh
- HTTP/2-to-HTTP/1.1 downgrade
- origin application server
- connection reuse behavior
- cache layer

Build:
```text
CLIENT → EDGE/WAF → PROXY/LB → ORIGIN
```

## Classes
- CL.TE
- TE.CL
- TE.TE / obfuscation differentials
- HTTP/2 downgrade desync
- H2 request splitting / ambiguous framing
- connection-state poisoning
- pause-based desync
- response-queue desynchronization
- cache poisoning through desync
- authentication/route confusion caused by desync

## Safe Research Method
Use harmless marker requests and a dedicated test endpoint. First prove parser disagreement, then only explore the security consequence that is explicitly authorized.

Measure:
- connection reuse
- response ordering
- timing anomalies
- backend/front-end correlation IDs
- whether a marker appears in a subsequent independent response

## Strong Validation
A genuine smuggling issue requires evidence that two HTTP components disagree about message boundaries or that a crafted request affects a subsequent request on a reused connection.

Do not call random latency or 400/408 responses “smuggling.”

## Impact Targets
- cache poisoning
- credential or session confusion
- access-control bypass
- routing to internal/admin endpoints
- cross-user response delivery
- persistent queue corruption

## Safety
Never use production-wide connection floods. Use one or a very small number of controlled connections and stop after deterministic proof.

## Reporting
Document the two parsers, the framing difference, the exact raw request(s), the affected connection model and the smallest reproducible impact chain.
