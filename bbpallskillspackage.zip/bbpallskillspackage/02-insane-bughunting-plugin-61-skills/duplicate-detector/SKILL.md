---
name: "duplicate-detector"
description: "Novelty and duplicate-risk gate for bug bounty findings — runs BEFORE writing any report, using four evidence sources: grep of 8,932 disclosed HackerOne reports (h1_reports_index.tsv), Shreyas Chavhan's 44-category notes of memorable report patterns, the target program's own disclosed/hacktivity pages, and root-cause comparison rules. Returns a verdict (UNIQUE / CHAINABLE / LIKELY DUPLICATE / KNOWN DUPLICATE) with evidence. Use when a candidate finding exists and you must decide whether to report it, chain it, or drop it. Trigger on \"is this a duplicate\", \"has this been reported before\", \"should I report this\", \"novelty check\"."
---

# Duplicate Detector — The Gate Before Writing

The most expensive bug bounty mistake is a technically-valid duplicate: $0, triager goodwill spent,
and a week of effort wasted. This skill is a mandatory pass before any report.

**Authorized targets only.**

## The gate (run in order; stop at first hard signal)

### 1. Class scan — `h1-report-db` skill first

Grep `references/` of `h1-report-db` (loaded via that skill) for your bug class AND feature keywords:

```bash
grep -i "<bug class>" references/h1_reports_index.tsv | grep -i "<feature keyword>"
```

Read every matching title. You are looking for **root-cause twins**: same trust boundary, same
sink, same auth state — not same payload text.

### 2. Memorable-pattern check

Open the matching category in `h1-report-db`'s notes file. The reports listed there are the ones a
full-time hunter flagged as *the patterns to remember* from 5,000 reports — i.e. the most heavily
repeated patterns in the wild. If your finding matches one listed there, assume it's been reported
on many programs; it's only novel if your target's specific implementation differs materially.

### 3. Program-local check (highest-weight evidence)

The target program's own disclosed reports override everything above:
- H1: the program's hacktivity/disclosed filter, searched by your class.
- Bugcrowd/YesWeHack/private: their disclosure pages if public, plus the program brief's
  explicitly out-of-scope list.
A same-program, same-root-cause disclosed report = near-certain duplicate. Report counts in the
hundreds on a program = saturated class; hunt elsewhere (the `bounty-hunting-lessons` skill).

### 4. Root-cause comparison rules

Two findings are duplicates when they share ALL of: the same trust boundary being violated, the
same vulnerable component (endpoint/flow/parser), and the same attacker primitive. NOT duplicates
when: different component, different auth state reached, or meaningfully different impact tier
(e.g. same XSS, but yours reaches an admin-only surface).

## Verdicts

- **KNOWN DUPLICATE** — step 3 found a same-program root-cause twin, or the class is explicitly
  out-of-scope. Drop, or chain into a distinct impact tier.
- **LIKELY DUPLICATE** — steps 1–2 show the exact pattern repeatedly, program is mature. Chain
  (use `bug-chaining-engine`) to raise impact above the disclosed instances, or find a different
  sink.
- **CHAINABLE** — pattern exists in the wild but your instance adds a step/impact the corpus
  lacks. Report the *chain*, with the link to the closest disclosed report and your delta stated
  explicitly in the report ("Unlike report X which reached Y, this reaches Z").
- **UNIQUE** — no corpus match AND program-local check clean. Still write the delta analysis in
  the report — triagers check duplicates themselves, and showing you did positions you as the
  first, more credible reporter.

## Feed the verdict back

Record every verdict + evidence in the session log. After the program responds, compare: your
duplicate-rate IS the metric this skill exists to drive to zero. High dup-rate on a program →
switch lanes to its under-reported classes (see `report-intelligence` lane selection).
