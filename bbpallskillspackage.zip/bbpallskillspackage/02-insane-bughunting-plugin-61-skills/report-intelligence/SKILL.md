---
name: "report-intelligence"
description: "Master report-intelligence skill for authorized bug bounty hunting — grounds every hunting decision in what has ACTUALLY been paid across 8,900+ disclosed HackerOne reports (163 vulnerability types with frequency and bounty statistics), 10,000 curated report URLs, 274 Google VRP writeups, and 400 Meta/Facebook writeups. Trigger at the start of any hunting session or when choosing what to hunt, when estimating what a bug class pays, when checking if a finding is likely a duplicate, or when studying how winning reports were written. Routes to h1-report-db, platform-intel (Google/Meta), duplicate-detector, and report-writer-blueprints."
---

# Report Intelligence — Hunt From Evidence, Not Guesses

Every hunting decision below is grounded in a distilled database of what triagers actually paid for:
`references/h1_vuln_type_stats.md` (163 vulnerability types with report counts and bounty medians/max),
`references/h1_title_patterns.md` (recurring title bigrams per class = what keeps working), and
`references/h1_top_payouts.md` (top-paying disclosed reports). The full per-report index — 8,932
unique reports with id, bounty, title, vuln types, URL — lives in the **`h1-report-db`** skill's
`references/h1_reports_index.tsv`; query it through that skill.

**Authorized targets only.** Run the Authorization & Scope Gate from `bug-bounty-hunter` before any active testing.

## When you load this skill

- Start of a session: pick hunting lanes by *paid-out frequency × bounty median*, not by hype.
- Mid-session candidate: before writing anything up, check the class's disclosed corpus for near-identical reports (duplicate risk).
- Before estimating severity/bounty: use the median/max columns, never invented numbers.
- Before writing the report: mine winning titles in the index for how impact was phrased.

## 1. Lane selection by evidence (session start)

Open `references/h1_vuln_type_stats.md` and sort lanes by what the data says. The top classes by
disclosed volume are information disclosure, improper access control, reflected/stored XSS, improper
authentication, CSRF, business logic, privilege escalation, IDOR, and code injection — with median
bounties of roughly $300–$1,000 and maxes reaching $15k–$30k+. Read the table for the exact numbers;
do not quote numbers from memory when the file is loadable.

Then cross-check with `references/h1_title_patterns.md`: for the class you pick, the top bigrams are
the *specific* sub-patterns that got paid most often (e.g. XSS classes: reflected parameter sinks;
access control: S3 buckets, subdomain takeovers, reset-password flows). Those bigrams are your
concrete first hypotheses on a new target — not generic class names.

## 2. Before you report: duplicate & novelty check (every candidate)

A technically valid bug that duplicates an existing report earns $0 and wastes triager time.

1. Grep `references/h1_reports_index.tsv` for your bug class (4th column) AND for keywords from your
   finding's title (3rd column). Read the titles of everything in the same class for your target's
   program if present (5th column URLs are per-report; the program column lives in the source DB).
2. Open `references/h1_notes_by_category.md` — Shreyas Chavhan's notes from reading 5,000 reports —
   at your bug class's section: it lists the specific reports considered *worth remembering* in that
   class, i.e. the patterns most likely already heavily reported.
3. Check the target program's public disclosed/hacktivity page for your class + feature area.
4. If a near-identical root cause exists in any of the three, either (a) chain your finding into a
   distinct impact tier, or (b) drop it and hunt elsewhere. Root-cause sameness beats surface
   difference: same sink, same trust boundary, different payload = usually a duplicate.

## 3. Bounty & severity calibration (before submitting)

Never invent a bounty estimate. For the class: median = typical, max = what the best instance in
that class earned. If your finding is below the median pattern for the class (weaker impact, more
preconditions), expect below-median. If it chains two classes (see `bug-chaining-engine`), the
payout usually follows the *higher* tier, not the sum.

## 4. Platform-specific lanes

- Google ecosystem (incl. any Google assets, YouTube, GCP, AI/Gemini surfaces): read the
  **`platform-intel`** skill (274 writeups). Recurring themes there: client-side RCE via
  URL/symlink parsing in desktop apps, service-account impersonation chains, email/phone
  enumeration, OAuth client takeover, AI-surface prompt/confusion bugs.
- Meta/Facebook/Instagram/WhatsApp/Threads: read the **`platform-intel`** skill (400 writeups).
  Recurring themes: ATO chains (FXAuth/datr/self-XSS-to-ATO), GraphQL IDOR, privacy-boundary
  leaks (locked chats, archived posts, blocked-user leaks), 2FA bypass via backup-code
  retrieval, business-tool privilege bugs.

## 5. Report writing from winning examples

`references/h1_top_payouts.md` = the biggest cheques. Study how those titles state impact in one
line: "[Bug class] in [exact feature] allows [attacker] to [concrete impact]". Then write with the
`write` skill and run the `triage` skill's self-validation before submitting.

## 6. Deep-study loop (become better every session)

10,000 curated report URLs live in `h1-report-db`'s `references/h1_10k_report_urls.txt`. When a
session yields nothing: pick the 10 highest-signal reports for your next lane (via the index TSV),
read them on HackerOne, and extract one new reusable pattern each. This is the compounding asset —
one hour of reading disclosed reports beats one hour of untargeted scanning.

## Sources & license notes

- HackerOne report database: github.com/codebygk/hackerone-bug-bounty-reports (community-maintained
  compilation of disclosed reports — data belongs to HackerOne/authors, links kept intact).
- Notes: Shreyas Chavhan's shared Notion "H1 Report Notes" (publicly shared by the author) +
  github.com/shreyaschavhan/10000-h1-disclosed-reports.
- Google VRP: github.com/xdavidhu/awesome-google-vrp-writeups. Meta:
  github.com/jaiswalakshansh/Facebook-BugBounty-Writeups.

All links preserved so the agent can verify claims at the source. Statistics are computed, not
asserted: counts from category files, bounties from disclosed amounts only.
