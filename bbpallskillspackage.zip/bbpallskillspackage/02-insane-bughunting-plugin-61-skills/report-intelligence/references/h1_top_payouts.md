# Top-paying disclosed HackerOne reports

What triagers paid the most for. Study the *class of bug + where it sat*, not just the technique.

| Bounty | Report title |
|---|---|
| $50,000 | [Github access token exposure](https://hackerone.com/reports/1087489) |
| $33,510 | [RCE via the DecompressedArchiveSizeValidator and Project BulkImports (behind feature flag)](https://hackerone.com/reports/1609965) |
| $33,510 | [Remote Command Execution via Github import](https://hackerone.com/reports/1679624) |
| $30,000 | [RCE via npm misconfig -- installing internal libraries from the public registry](https://hackerone.com/reports/925585) |
| $29,000 | [Arbitrary file read  via the bulk imports UploadsPipeline](https://hackerone.com/reports/1439593) |
| $25,000 | [Exposed Kubernetes API - RCE/Exposed Creds](https://hackerone.com/reports/455645) |
| $25,000 | [Server Side Request Forgery (SSRF) via Analytics Reports](https://hackerone.com/reports/2262382) |
| $25,000 | [SAML Signature verification bypass allows logging into any user (with specific conditions)](https://hackerone.com/reports/2579939) |
| $22,300 | [RepositoryPipeline allows importing of local git repos](https://hackerone.com/reports/1685822) |
| $20,160 | [Potential pre-auth RCE on Twitter VPN](https://hackerone.com/reports/591295) |
| $20,000 | [Bypass for #488147 enables stored XSS on https://paypal.com/signin again](https://hackerone.com/reports/510152) |
| $20,000 | [Account takeover via leaked session cookie](https://hackerone.com/reports/745324) |
| $20,000 | [Arbitrary file read via the UploadsRewriter when moving and issue](https://hackerone.com/reports/827052) |
| $20,000 | [Getting all the CD keys of any game](https://hackerone.com/reports/391217) |
| $20,000 | [RCE when removing metadata with ExifTool](https://hackerone.com/reports/1154542) |
| $20,000 | [RCE via unsafe inline Kramdown options when rendering certain Wiki pages](https://hackerone.com/reports/1125425) |
| $20,000 | [Private objects exposed through project import](https://hackerone.com/reports/767770) |
| $20,000 | [Steal private objects of other projects via project import](https://hackerone.com/reports/743953) |
| $20,000 | [bd-j exploit chain](https://hackerone.com/reports/1379975) |
| $20,000 | [Github Apps can use Scoped-User-To-Server Tokens to Obtain Full Access to User's Projects in Project V2 GraphQL api](https://hackerone.com/reports/1711938) |
| $18,900 | [Stored XSS on https://paypal.com/signin via cache poisoning](https://hackerone.com/reports/488147) |
| $18,000 | [Oracle Webcenter Sites administrative and hi-privilege access available directly from the internet (/cs/Satellite)](https://hackerone.com/reports/170532) |
| $18,000 | [Struct type confusion RCE](https://hackerone.com/reports/181879) |
| $16,000 | [Email Confirmation Bypass in myshop.myshopify.com that Leads to Full Privilege Escalation to Any Shop Owner by Taking Advantage of the Shopify SSO](https://hackerone.com/reports/791775) |
| $16,000 | [Arbitrary file read during project import](https://hackerone.com/reports/1132378) |
| $16,000 | [Stored XSS in markdown via the DesignReferenceFilter](https://hackerone.com/reports/1212067) |
| $15,300 | [Token leak in security challenge flow allows retrieving victim's PayPal email and plain text password](https://hackerone.com/reports/739737) |
| $15,250 | [Ability to bypass partner email confirmation to take over any store given an employee email](https://hackerone.com/reports/300305) |
| $15,000 | [Websites Can Run Arbitrary Code on Machines Running the 'PlayStation Now' Application](https://hackerone.com/reports/873614) |
| $15,000 | [Delete anyone's content spotlight remotely.](https://hackerone.com/reports/1819832) |
| $15,000 | [Open prod Jenkins instance](https://hackerone.com/reports/231460) |
| $15,000 | [Leaked JFrog Artifactory  username and password exposed on GitHub - https://snapchat.jfrog.io](https://hackerone.com/reports/911606) |
| $15,000 | [Incorrect authorization to the intelbot service leading to ticket information](https://hackerone.com/reports/1328546) |
| $13,950 | [Stored XSS in Notes (with CSP bypass for gitlab.com)](https://hackerone.com/reports/1481207) |
| $13,950 | [XSS in ZenTao integration affecting self hosted instances without strict CSP](https://hackerone.com/reports/1542510) |
| $13,950 | [New /add_contacts /remove_contacts quick commands susseptible to XSS from Customer Contact firstname/lastname fields](https://hackerone.com/reports/1578400) |
| $13,950 | [Stored XSS via Kroki diagram](https://hackerone.com/reports/1731349) |
| $13,000 | [Mass Accounts Takeover Without any user Interaction  at https://app.taxjar.com/](https://hackerone.com/reports/1685970) |
| $12,500 | [Spring Actuator endpoints publicly available and broken authentication](https://hackerone.com/reports/838635) |
| $12,500 | [An attacker can archive and unarchive any structured scope object on HackerOne](https://hackerone.com/reports/1501611) |
| $12,500 | [Remote vulnerabilities in spp](https://hackerone.com/reports/2177925) |
| $12,500 | [View Titles of Private Reports with pending email invitation](https://hackerone.com/reports/2312029) |
| $12,000 | [Git flag injection - local file overwrite to remote code execution](https://hackerone.com/reports/658013) |
| $12,000 | [Local files could be overwritten in GitLab, leading to remote command execution](https://hackerone.com/reports/587854) |
| $12,000 | [Project Template functionality can be used to copy private project data, such as repository, confidential issues, snippets, and merge requests](https://hackerone.com/reports/689314) |
| $12,000 | [Bypass of GitLab CI runner slash fix in YAML validation](https://hackerone.com/reports/409395) |
| $12,000 | [JSON serialization of any Project model results in all Runner tokens being exposed through Quick Actions](https://hackerone.com/reports/509924) |
| $12,000 | [Path traversal in Nuget Package Registry](https://hackerone.com/reports/822262) |
| $12,000 | [Path traversal, to RCE](https://hackerone.com/reports/733072) |
| $12,000 | [Account Takeover via Authentication Bypass in TikTok Account Recovery](https://hackerone.com/reports/2443228) |
| $11,500 | [Arbitrary Code Execution via npm misconfiguration – installing internal libraries from the public registry](https://hackerone.com/reports/1043385) |
| $11,000 | [Exfiltrate and mutate repository and project data through injected templated service](https://hackerone.com/reports/446585) |
| $10,500 | [IDOR to add secondary users in www.paypal.com/businessmanage/users/api/v1/users](https://hackerone.com/reports/415081) |
| $10,500 | [Ability to DOS any organization's SSO and open up the door to account takeovers](https://hackerone.com/reports/976603) |
| $10,000 | [Use-After-Free In IPV6_2292PKTOPTIONS leading To Arbitrary Kernel R/W Primitives](https://hackerone.com/reports/826026) |
| $10,000 | [Access to multiple production Grafana dashboards](https://hackerone.com/reports/663628) |
| $10,000 | [gitlab-workhorse bypass in Gitlab::Middleware::Multipart allowing files in `allowed_paths` to be read](https://hackerone.com/reports/850447) |
| $10,000 | [Partial disclosure of report activity through new "Export as .zip" feature](https://hackerone.com/reports/182358) |
| $10,000 | [Crash: Initialize Decimal with itself triggers an assertion](https://hackerone.com/reports/185775) |
| $10,000 | [Segfault and/or potential unwanted (byte)code execution with "break" and "&#124;&#124;=" inside a loop](https://hackerone.com/reports/183356) |
