---
name: "skill-decision-maker"
description: "Deterministic routing engine for the High-Severity Hunter skill suite — decides which hunting skill(s) to activate, in what order, when to stop, when to switch skills, and when to enter validation, based on observed attack surface, trust boundaries, input primitives, auth state, and evidence state. Trigger when choosing the next hunting skill on an authorized target or when the agent asks what to do next."
---

# Skill Decision Maker — High-Severity Hunter Skill Router

**Version:** 2026.08
**Purpose:** Deterministically decide which hunting skill(s) to activate, in what order, when to stop, when to switch skills, and when to enter validation.

---

## 0. Prime Directive

Do not choose a skill because a vulnerability name appears in a request.

Choose a skill because the **observed attack surface, trust boundary, input primitive, authentication state, workflow, and evidence state** make that skill the highest-information next action.

The router optimizes for:

```text
relevant coverage
+ information gain
+ impact potential
+ evidence quality
- duplicate risk
- false-positive risk
- unnecessary traffic
- scope risk
```

The router is a decision engine, not a scanner launcher.

---

## 1. Non-Negotiable Gates Before Any Skill

### Gate A — Authorization

Confirm:

- program / engagement
- asset in scope
- exact hostname / API / feature
- testing restrictions
- account/test-data restrictions
- rate/concurrency restrictions
- third-party boundaries
- prohibited techniques

If the branch is not demonstrably authorized: **STOP**.

### Gate B — Engagement Mode

Classify as:

- bug bounty / VDP
- authorized pentest
- red team
- CTF/lab
- internal audit

Finding standards depend on the mode.

### Gate C — Current Authentication Position

Classify:

```text
PRE-AUTH
AUTH-LOW
AUTH-PEER
AUTH-PRIVILEGED
MULTI-ACCOUNT / MULTI-TENANT
UNKNOWN
```

Never silently assume a credential exists.

### Gate D — Evidence State

Every lead must have one state:

```text
LEAD
OBSERVATION
HYPOTHESIS
CANDIDATE
CONFIRMED
CHAIN-CANDIDATE
VALIDATED
DUPLICATE
INFORMATIVE/N/A
FALSE POSITIVE
OUT OF SCOPE
```

Only `VALIDATED` can become a report.

---

# 2. Primary Decision Tree

```text
START
  |
  +--> Authorization confirmed?
  |       NO -> STOP
  |       YES
  |
  +--> New target / new scope / weak asset map?
  |       YES -> 00 + 14
  |       NO
  |
  +--> Browser unavailable / curl-first environment?
  |       YES -> 02 as execution layer
  |
  +--> JS present / SPA / API discovery needed?
  |       YES -> 01
  |
  +--> No credentials?
  |       YES -> 04
  |
  +--> Valid credentials?
  |       YES -> 05
  |
  +--> Financial / lifecycle / verification / multi-step workflow?
  |       YES -> 03
  |
  +--> Specific technical primitive detected?
          |
          +--> URL fetch / webhook / import / preview -> 07
          +--> Blind output / callback-capable sink -> 08
          +--> Concurrent state transition -> 09
          +--> Login/recovery/session/OAuth/MFA -> 10
          +--> Interpreter/template/deserialization/file execution -> 11
          +--> Proxy/backend parsing differential -> 12
          +--> WAF blocks candidate but origin behavior suspected -> 13
          +--> Cache headers / CDN / cacheable sensitive response -> 17
          +--> Object / tenant / role / function access -> 19
          +--> Sensitive response / secret / internal metadata -> 20
          +--> Multiple confirmed primitives -> 16
  |
  +--> High/Critical impact plausible?
  |       YES -> 15 as severity/priority filter
  |
  +--> Developer assumption / unexplained contradiction?
  |       YES -> 18 + 21
  |
  +--> Stuck / uncertain / multiple possible paths?
  |       YES -> 21
  |
  +--> Candidate exists?
          YES -> 22 -> 06
```

---

# 3. Skill Selection Matrix

| Skill | Activate when | Primary question | Typical next skill |
|---|---|---|---|
| 00 Orchestrator | session start / target switch / lost | What should we hunt next? | 14 / 01 / 03 / 04 / 05 |
| 01 MasterJS | JS, SPA, bundles, source maps, hidden routes | What does the client reveal? | 19 / 10 / 07 / 20 |
| 02 Curl Operator | raw HTTP execution is required | What exactly did the server receive/return? | Any specialist |
| 03 Business Logic | money, workflow, verification, lifecycle | Which invariant/state transition is broken? | 09 / 10 / 16 / 19 |
| 04 Unauthenticated | no valid session | What is reachable before authentication? | 10 / 07 / 11 / 19 / 20 |
| 05 Authenticated | logged-in context exists | Which trust boundary can this account cross? | 19 / 03 / 10 / 16 |
| 06 Validation/Triage | candidate exists | Is it real, impactful, novel and reportable? | 23 / report |
| 07 SSRF | server fetches attacker-influenced URL | Did the server actually connect, and what can it reach? | 20 / 11 / 16 |
| 08 Blind/OOB SQLi-XSS | result is not directly visible | Can OOB/side-channel evidence prove server execution? | 02 / 06 / 16 |
| 09 Race | security check + mutation have a time window | Can concurrency violate an invariant? | 03 / 10 / 16 |
| 10 ATO | login/recovery/session/linking/MFA surface | Can attacker become/control another principal? | 09 / 16 / 06 |
| 11 RCE | input reaches interpreter/execution boundary | Can controlled input become code/command execution? | 07 / 16 / 06 |
| 12 Request Smuggling | intermediaries parse requests differently | Can parser desync produce real victim-impact? | 17 / 19 / 16 |
| 13 WAF Bypass | WAF blocks a candidate path | Can a safe transformation reach the intended origin behavior? | Relevant vuln skill / 06 |
| 14 Recon Master | attack surface incomplete | What assets/endpoints/params/IPs/files exist? | 01 / 04 / 05 |
| 15 Critical Finder | possible high-impact candidate | Is there a credible high/critical impact path? | 16 / 06 |
| 16 Chaining | two or more real primitives | Does composition materially increase impact? | 06 |
| 17 Cache | CDN/cache behavior observed | Can one request affect another user? | 10 / 20 / 16 |
| 18 Assumption Breaker | unexplained “this should never happen” behavior | Which developer invariant is missing? | 03 / 19 / 09 / 21 |
| 19 IDOR/AuthZ | identifiers, roles, tenants, functions | Does authorization follow the resource/capability? | 03 / 10 / 16 |
| 20 Info Disclosure | sensitive-looking data/metadata | Is disclosure real, unauthorized and actionable? | 07 / 10 / 11 / 06 |
| 21 Elite Thinker | ambiguous or stalled investigation | What hypothesis gives maximum information gain? | Any specialist |
| 22 Routing/Gates | cross-skill transition or gate check | Is this branch ready for deeper testing/reporting? | 06 |
| 23 Decision Maker | skill-selection ambiguity | Which skill sequence is optimal? | Any |

---

# 4. Input-Primitive Routing

## URL / Host / Destination input

Activate:

```text
07 SSRF
13 WAF bypass if filtered
17 Cache if response is cacheable
20 Info Disclosure if internal responses leak
```

## Object IDs / UUIDs / resource references

Activate:

```text
19 IDOR/AuthZ
05 Authenticated context
04 Unauthenticated context if route may be public
16 Chaining after read/write primitive is proven
```

## Price / amount / coupon / quantity / entitlement

Activate:

```text
03 Business Logic
09 Race if repeatability/concurrency matters
05 Authenticated if account state matters
16 Chaining for financial escalation
```

## Login / reset / MFA / verification / session / OAuth

Activate:

```text
10 ATO
03 Business Logic for workflow/gate sequencing
09 Race for token or state timing
19 AuthZ for cross-account effects
16 Chaining when multiple primitives compose
```

## File upload / import / export / parser

Activate:

```text
14 Recon
01 JS if client exposes processing paths
07 SSRF for URL-fetch/import paths
11 RCE for interpreter/parser/execution boundaries
20 Info Disclosure for local/internal file exposure
```

## API / GraphQL / JSON body

Activate:

```text
02 Curl
19 AuthZ
04 or 05 depending on auth state
08 SQLi/XSS if injection sinks appear
03 Business Logic if state transition is complex
```

## HTML / JS / DOM / templates

Activate:

```text
01 MasterJS
08 Blind/OOB XSS if no visible execution
11 RCE if server-side template execution is plausible
```

## CDN / cache headers / static assets

Activate:

```text
17 Cache Deception/Poisoning
12 Request Smuggling if intermediary parsing differs
13 WAF bypass if edge blocks origin behavior
```

---

# 5. Authentication-Aware Routing

### PRE-AUTH
Prioritize:

```text
14 -> 04 -> 10 -> 07 -> 11 -> 19 -> 20 -> 16 -> 06
```

Exception: if financial/public workflow is obvious:

```text
14 -> 04 -> 03 -> 09 -> 10
```

### AUTH-LOW
Prioritize:

```text
05 -> 19 -> 03 -> 10 -> 09 -> 16 -> 06
```

### MULTI-TENANT
Prioritize:

```text
05 -> 19 -> 03 -> 10 -> 16 -> 06
```

### ADMIN / PRIVILEGED
Do not immediately chase more privilege. First test whether the privilege is actually scoped, durable, and intended.

Prioritize:

```text
05 -> 19 -> 03 -> 20 -> 16 -> 06
```

---

# 6. Information-Gain Routing

When several skills are plausible, choose the one that most cheaply distinguishes competing hypotheses.

Example:

```text
URL parameter
  |
  +-- Is server making a request? -> 07
  |
  +-- Is response cached cross-user? -> 17
  |
  +-- Does WAF block only syntax? -> 13
```

Do not run all three blindly.

Use a small discriminating test, observe, then route.

---

# 7. Chain-Aware Routing

After every confirmed primitive, ask:

```text
What capability did this unlock?
What other endpoint consumes that capability?
Can the same identity/object/token reach a more sensitive state?
```

Canonical routes:

```text
SSRF -> 20 -> 11 / 16
IDOR -> 19 -> 10 / 03 / 16
Info leak -> 20 -> 10 / 19 / 11
Race -> 09 -> 03 / 10 / 16
Cache poison -> 17 -> 10 / 08 / 16
WAF bypass -> relevant vuln skill -> 06
Request smuggling -> 12 -> 17 / 19 / 16
```

A chain may be reported only if every required step is independently reproducible.

---

# 8. False-Positive Routing

If a candidate fails validation:

```text
FALSE POSITIVE
   |
   +--> identify why
   |      - parser artifact
   |      - generic error
   |      - client-only behavior
   |      - expected product behavior
   |      - missing victim impact
   |      - missing authorization boundary
   |      - non-reproducible timing
   |      - duplicate/systemic known issue
   |
   +--> record disproof evidence
   |
   +--> create adjacent hypothesis only if evidence supports it
   |
   +--> route back to 21 / 18 / relevant specialist
```

Never repeatedly retry the same disproven hypothesis without new evidence.

---

# 9. Duplicate-Aware Routing

Before deepening a candidate, compare against available historical intelligence using:

```text
same vulnerability class?
same target/asset?
same endpoint/resource?
same root cause?
same authorization boundary?
same exploitation primitive?
same business function?
same impact?
same remediation?
```

Possible outcomes:

```text
same root cause + same impact -> likely duplicate
same systemic class + materially new mechanism/impact -> investigate additive value
same root cause + different endpoint only -> systemic/duplicate risk
new root cause or materially expanded impact -> continue
```

Historical absence is never proof of novelty.

---

# 10. High/Critical Escalation

Use 15 when any of these are plausible:

- account takeover
- remote code execution
- cross-tenant privileged access
- cloud credential exposure
- sensitive internal service access
- mass financial abuse
- mass PII/data exposure
- security-boundary break affecting many users
- cache poisoning with cross-user impact
- request smuggling with exploitable downstream consequence
- chained medium bugs producing a materially higher impact

Do not declare severity from potential alone. 15 prioritizes investigation; 06 validates severity.

---

# 11. Hard Stop Conditions

Stop the current branch when:

- out of scope
- no authorized target evidence
- repeated tests produce no new information
- only theoretical impact remains
- only client-side cosmetic behavior remains
- generic error response is the only evidence
- self-XSS with no meaningful chain
- no real authorization boundary is crossed
- race is theoretical without invariant violation
- blind claim lacks legitimate OOB/server-side evidence
- cache effect is visible only to attacker
- duplicate appears materially identical

Switch branches only when the new branch has a better evidence/impact hypothesis.

---

# 12. Final Routing Contract

The Decision Maker must output internally:

```text
ENGAGEMENT_MODE:
AUTH_STATE:
TARGET_ASSET:
PRIMARY_GOAL:
OBSERVED_PRIMITIVES:
SECURITY_BOUNDARY:
CURRENT_EVIDENCE_STATE:
TOP_HYPOTHESIS:
PRIMARY_SKILL:
SECONDARY_SKILLS:
EXECUTION_LAYER: 02-curl-http-operator
VALIDATION_GATE: 22 -> 06
CHAIN_CANDIDATE: yes/no
DUPLICATE_RISK: low/medium/high
FALSE_POSITIVE_RISK: low/medium/high
NEXT_ACTION:
STOP_CONDITION:
```

Never output “use every skill.” Select a sequence.

---

# 13. Default Master Sequence

For a completely new web target:

```text
00
 ↓
14
 ↓
01
 ↓
02
 ↓
04
 ↓
05
 ↓
03
 ↓
Relevant specialist
 ↓
15 if impact is potentially High/Critical
 ↓
16 if chaining opportunity exists
 ↓
22
 ↓
06
```

This sequence is deliberately non-linear. If a new asset, state, endpoint, role, or primitive is discovered, route back to the earliest skill that can explain it.

---

# 14. Core Philosophy

The best decision is not the most aggressive one.

It is the smallest authorized action that most efficiently answers:

> **“Is there a real security-boundary violation here, and can I prove meaningful impact?”**

A candidate that cannot survive this question does not advance.
