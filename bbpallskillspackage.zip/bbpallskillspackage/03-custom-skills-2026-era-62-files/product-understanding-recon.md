---
name: product-understanding-recon
version: 1.0.0
title: Product Understanding & Documentation-First Recon
category: Recon / Target Comprehension
scope: Authorized security testing only
---

# Product Understanding & Documentation-First Recon

## Mission

Build a high-fidelity model of an authorized program before deep vulnerability hunting. Do not begin with endpoint spraying. Begin with the organization, product, business model, documentation, infrastructure, identity model, data model, workflows, trust boundaries, and known attacker pain points.

The core output is an evidence-backed **Target Understanding Package** that answers:

> What does this product do, who depends on it, what does the company protect, what must always remain true, where are the high-value trust boundaries, and what parts of the implementation are most likely to diverge from intended design?

The methodology is grounded in the existing target-comprehension framework: build Business, Product, Identity, Authorization, Data, State, Integration, Infrastructure, and Historical-Bug models in parallel; preserve an explicit Intended Design vs Observed Implementation comparison. fileciteturn5file3L455-L504

---

## 0. Hard Engagement Gate

Before collecting anything beyond ordinary public information, establish:

- engagement type: BUG_BOUNTY / VDP / PENTEST / RED_TEAM / INTERNAL_AUDIT
- exact scope
- asset restrictions
- excluded assets/classes
- rate limits
- prohibited activities
- test-account availability
- production-data restrictions

Never silently expand scope because a related domain, IP, ASN, cloud account, third-party service, or certificate appears connected.

The source methodology explicitly requires the engagement mode and scope to be recorded before active testing. fileciteturn5file3L423-L451

---

# 1. Recon Objective: Understand the Business Before the Endpoint

Do not ask first:

> “What endpoints can I hit?”

Ask first:

> “What real-world process is this product implementing, and what would materially harm the business or its users if that process were violated?”

Create these parallel models:

```text
BUSINESS MODEL
PRODUCT MODEL
IDENTITY MODEL
AUTHORIZATION MODEL
DATA MODEL
STATE MODEL
INTEGRATION MODEL
INFRASTRUCTURE MODEL
HISTORICAL-BUG MODEL
```

These models are explicitly supported by the existing methodology. fileciteturn5file4L636-L685

---

# 2. Program Documentation Sweep

Read available documentation in this order:

1. Security / bug-bounty policy
2. Scope and asset descriptions
3. Product documentation
4. API documentation
5. OpenAPI specifications
6. GraphQL schemas/documentation
7. SDK and developer documentation
8. Authentication documentation
9. OAuth/OIDC/SAML documentation
10. Admin / organization / team documentation
11. Integration documentation
12. Help-desk / Help Center articles
13. Feature guides and FAQs
14. Status pages / incident pages
15. Release notes
16. Changelogs
17. Public source repositories where permitted
18. Public SDK examples / schemas
19. Frontend assets that are normally delivered to clients
20. Public search-indexed documentation

Do not assume documentation is complete. Documentation is evidence of intended design, not proof of implementation. Maintain two separate models:

```text
INTENDED_DESIGN
      vs
OBSERVED_IMPLEMENTATION
```

A discrepancy becomes a research hypothesis, not an automatic finding. fileciteturn5file0L42-L81

---

# 3. Program Intelligence Extraction

For every documentation source record:

```text
SOURCE
DATE / VERSION
PRODUCT AREA
ACTOR / ROLE
FEATURE
RESOURCE
SECURITY CONTROL
EXPECTED BEHAVIOR
IMPORTANT TERMS
RELATED ENDPOINTS
RELATED HOSTS
RELATED INTEGRATIONS
OPEN QUESTIONS
```

Extract vocabulary exactly as the program uses it:

- product names
- object names
- roles
- tiers
- permissions
- tenant concepts
- workflow states
- approval language
- billing terms
- recovery terms
- integration names
- API resource names

This vocabulary becomes the seed dictionary for subsequent recon and attack-surface mapping.

---

# 4. Business Model Map

Build a complete model:

```text
Business Model
 ├── Customers
 ├── Users
 ├── Tenants / Organizations
 ├── Roles
 ├── Revenue Flows
 ├── Assets
 ├── Sensitive Actions
 ├── Trust Assumptions
 ├── Verification Controls
 ├── Payments / Credits
 ├── Identity / Account Recovery
 ├── Integrations
 ├── Data Flows
 ├── Administrative Functions
 └── External Dependencies
```

The research goal is to be able to answer:

> If this control fails, what real capability does the attacker gain, against whom, and why did the product intend to prevent it?

This business-model structure comes directly from the supplied methodology. fileciteturn5file0L11-L38

---

# 5. Customer / User / Role Model

Identify:

### Customers
- individuals
- teams
- enterprises
- partners
- developers
- administrators

### Roles
- anonymous
- registered user
- verified user
- member
- manager
- owner
- billing administrator
- support
- developer
- organization administrator
- super-admin, if documented

### Trust changes
Track what each role can:

- create
- read
- update
- delete
- approve
- export
- invite
- bill
- recover
- impersonate
- configure
- integrate

Do not infer a role privilege from the UI label alone; validate later at the server boundary.

---

# 6. Product Capability Map

Enumerate the product from a user's perspective.

For every major feature ask:

```text
What does it do?
Who uses it?
What resource does it operate on?
What must be true before it runs?
What changes after it runs?
What external service is involved?
What data crosses the boundary?
What could go wrong if one assumption fails?
```

Typical feature families:

- onboarding
- authentication
- recovery
- profile/account
- organizations/teams
- invitations
- permissions
- billing/subscriptions
- payments/refunds
- content creation
- file upload
- import/export
- search/filtering
- sharing
- messaging
- integrations
- webhooks
- notifications
- API access
- automation
- background jobs
- reporting
- admin/moderation
- support/help desk

---

# 7. Business Pain-Point Map

For every major feature, ask:

```text
What could a real customer lose?
What could the company lose?
What could another tenant lose?
What could create fraud?
What could create unauthorized access?
What could cause trust failure?
What could create integrity loss?
```

Translate product functionality into security consequences. fileciteturn5file3L491-L504

Rank pain points:

```text
P0 = direct money / account / privileged access / critical data
P1 = significant customer/business impact
P2 = limited security impact
P3 = mostly hygiene/informational
```

This is prioritization, not severity assignment.

---

# 8. Revenue and Economic Model

Understand:

- what the product sells
- subscription structure
- free vs paid tiers
- credits/tokens/quotas
- refunds
- trial periods
- promotional credits
- referral systems
- affiliate flows
- commissions
- usage-based pricing
- entitlement activation
- cancellation
- renewal
- invoice generation

Record:

```text
MONEY_IN
MONEY_OUT
ENTITLEMENT_CREATED
ENTITLEMENT_REVOKED
CREDIT_CONSUMED
REFUNDED
CHARGEBACK
```

These flows should later route to Business Logic, Race, ATO, Authorization, and Chaining specialists.

---

# 9. Product State Model

For each important workflow map:

```text
STATE_BEFORE
PRECONDITIONS
ACTOR
INPUTS
SERVER_DECISION
STATE_AFTER
SIDE_EFFECTS
DOWNSTREAM_SERVICE
REVERSIBILITY
SECURITY_CONTROL
EXPECTED_INVARIANT
```

Example:

```text
FLOW: export dataset
Actor: authenticated member
Precondition: export permission
State: active
Action: POST /exports
Server decision: authorize + create job
State after: export_pending
Side effect: worker reads tenant data
Invariant: export only accesses authorized tenant data
```

The supplied methodology specifically emphasizes that the vulnerable component may be the worker, status endpoint, download link, callback, or second API rather than the request that begins the workflow. fileciteturn5file3L544-L585

---

# 10. Identity & Authentication Model

Map:

- registration
- email verification
- phone verification
- MFA
- password reset
- account recovery
- social login
- OAuth/OIDC
- SAML/SSO
- sessions
- refresh tokens
- API keys
- service accounts
- device trust
- organization invites
- account linking

For every identity transition:

```text
WHO
PROVES WHAT
WITH WHICH TOKEN
AT WHICH SERVER ENDPOINT
FOR WHICH ACCOUNT
FOR WHICH RESOURCE
FOR HOW LONG
```

This becomes the foundation for ATO/AuthZ testing.

---

# 11. Data Model

Map the major data classes:

- public
- internal
- private
- sensitive
- credentials
- financial
- tenant data
- analytics
- logs
- backups
- configuration
- support data
- exported data

For each resource identify:

```text
OBJECT NAME
OWNER
TENANT
IDENTIFIER
READERS
WRITERS
DELETERS
EXPORTERS
SHARERS
RETENTION
```

This becomes the basis for IDOR and information-disclosure routing.

---

# 12. Integration Model

Enumerate first-party and explicitly authorized third-party integrations:

- payments
- email
- SMS
- identity providers
- CRM
- analytics
- storage
- CI/CD
- webhooks
- import/export providers
- notification platforms
- AI/LLM providers
- cloud services
- support platforms

For each integration record:

```text
INBOUND?
OUTBOUND?
AUTH METHOD
WEBHOOK?
SIGNATURE?
DATA SENT
DATA RECEIVED
TRUSTED DOMAIN
RETRY BEHAVIOR
FAILURE BEHAVIOR
```

---

# 13. Infrastructure Model

Build an evidence-backed map of:

```text
ROOT DOMAINS
SUBDOMAINS
IPs / CIDRs
DNS
CDN / EDGE
LOAD BALANCERS
ORIGINS
API GATEWAYS
WEB SERVERS
APPLICATION SERVICES
OBJECT STORAGE
QUEUES
WORKERS
DATABASES
MONITORING
ADMIN / OPS
DEV / STAGING / TEST
THIRD-PARTY SERVICES
```

Use the existing Recon Master skill as the execution layer for deep enumeration; it explicitly covers subdomains, dead hosts, DNS/IP mapping, HTTP surface, endpoints, JS, sensitive files and parameters. fileciteturn5file8L1142-L1267

---

# 14. Technology Model

Determine where confidently possible:

- frontend framework
- backend framework
- runtime/language
- API style
- database family
- cloud provider
- CDN
- reverse proxy
- auth provider
- storage provider
- payment provider
- analytics
- queue/worker architecture
- monitoring
- source control / CI indicators

Maintain confidence:

```text
CONFIRMED
HIGH-CONFIDENCE
LIKELY
UNCONFIRMED
```

Never state an inference as fact.

---

# 15. Help Desk / Support Intelligence

Treat help-center content as product documentation.

Extract:

- hidden workflows
- feature prerequisites
- support-only paths
- recovery policies
- account ownership rules
- cancellation rules
- refund rules
- sharing rules
- file/export semantics
- role assumptions
- organization behavior
- product limits
- API hints
- endpoint naming

Help articles can reveal security invariants that are not visible in normal UI.

Never treat a help article as proof the implementation enforces the rule.

---

# 16. Release / Changelog Intelligence

Search for:

- newly launched features
- renamed endpoints
- migrated auth systems
- payment-provider changes
- access-control changes
- deprecated APIs
- legacy removal
- security fixes
- regression-prone areas

The highest-value white space often exists where product change has outpaced
security-control consistency.

---

# 17. Historical Bug Intelligence

If authorized and publicly available, collect historical reports and cluster them by:

- asset
- host
- endpoint
- parameter
- object type
- role
- vulnerability class
- root cause
- attack primitive
- workflow
- state transition
- impact
- remediation
- status

Do not merely collect titles.

Search for:

```text
same root cause?
same security boundary?
same resource?
same authorization mechanism?
same exploitation primitive?
same business function?
same trust assumption?
same remediation?
```

This is specifically required by the existing next-level methodology. fileciteturn5file0L85-L134

---

# 18. Intended vs Observed Matrix

Create:

| Area | Intended | Observed | Difference | Confidence | Research Lead |
|---|---|---|---|---|---|
| Auth | | | | | |
| Billing | | | | | |
| Tenant | | | | | |
| Export | | | | | |
| Recovery | | | | | |
| Admin | | | | | |

A difference is a lead.

Do not call it a vulnerability until the implementation actually crosses a security boundary.

---

# 19. Target Understanding Completion Gate

Product Understanding is NOT complete until the agent can explain:

- what the company does
- who uses it
- who pays
- what the crown jewels are
- the main user roles
- the major security boundaries
- the main business workflows
- high-value state transitions
- sensitive objects
- important integrations
- relevant infrastructure
- current product technologies
- documented security expectations
- historical bug patterns
- key pain points
- highest-risk assumptions
- major unknowns

If any of these remain unclear, mark:

```text
UNDERSTANDING_INCOMPLETE
```

Then continue documentation/recon instead of rushing into exploitation.

---

# 20. OUTPUT PACKAGE

Produce:

```text
TARGET PROFILE
PROGRAM / SCOPE
BUSINESS MODEL
PRODUCT CAPABILITY MAP
ROLE / IDENTITY MODEL
AUTHORIZATION MODEL
DATA MODEL
STATE MACHINE MAP
INTEGRATION MAP
INFRASTRUCTURE MAP
TECHNOLOGY STACK
HELP-DESK INTELLIGENCE
CHANGELOG / RELEASE INTELLIGENCE
HISTORICAL-BUG CLUSTERS
PAIN-POINT MAP
TRUST ASSUMPTIONS
INTENDED-vs-OBSERVED DELTAS
CROWN JEWELS
UNKNOWN AREAS
NEXT-PHASE ATTACK MAPPING INPUT
```

The last section is the handoff to the **Product-to-Attack-Vector Mapper** skill.

---

# 21. STOP RULE

Do not start deep exploitation merely because reconnaissance has produced many endpoints.

The goal of this skill is high-quality understanding.

When complete, pass the package to the next skill.

END OF PRODUCT UNDERSTANDING RECON
