---
name: product-to-attack-vector-mapper
version: 1.0.0
title: Product-Specific Attack Vector Mapper & White-Space Hunter
category: Recon / Threat Modeling / Attack-Surface Mapping
scope: Authorized security testing only
---

# Product-Specific Attack Vector Mapper & White-Space Hunter

## Mission

Take a completed **Target Understanding Package** and convert it into a prioritized, multi-dimensional attack map tailored to the specific product.

This is not a generic vulnerability checklist.

It asks:

> Given what this product actually does, what security invariants does it rely on, where are the trust boundaries, and what distinct attack paths could violate those invariants in ways a generic checklist would miss?

The mapper should produce a finite, evidence-backed **Attack Vector Graph + Priority Queue + White-Space Map**.

The source methodology requires the agent to start with organization/product comprehension and then map business, identity, authorization, data, state, integration and infrastructure models before deep hunting. fileciteturn5file3L455-L504

---

# 0. Preconditions

Do not activate until Product Understanding & Documentation-First Recon has produced:

- scope
- business model
- product model
- role model
- identity model
- authorization model
- data model
- state model
- integration model
- infrastructure model
- technology model
- documented intended behavior
- observed implementation notes
- historical-bug patterns
- pain points
- trust assumptions
- unknown areas

If these are missing:

```text
STOP
→ return to Product Understanding Recon
```

---

# 1. CORE OUTPUT

Produce:

```text
CROWN JEWEL MAP
       ↓
TRUST BOUNDARY MAP
       ↓
BUSINESS WORKFLOW MAP
       ↓
IDENTITY / AUTH MAP
       ↓
OBJECT / TENANT MAP
       ↓
INTEGRATION MAP
       ↓
INFRASTRUCTURE MAP
       ↓
ATTACK VECTOR MATRIX
       ↓
WHITE-SPACE MAP
       ↓
CHAIN OPPORTUNITIES
       ↓
PRIORITIZED ATTACK QUEUE
```

Every attack vector must have:

```text
VECTOR_ID
SURFACE
PRIMITIVE
TRUST_BOUNDARY
PRECONDITION
SECURITY_INVARIANT
LIKELY_FAILURE_MODE
EXPECTED_IMPACT
EVIDENCE NEEDED
SPECIALIST SKILL
CHAIN POTENTIAL
PRIORITY
CONFIDENCE
```

---

# 2. CROWN JEWEL MAPPING

Do not start with vulnerability names.

Identify what must not be compromised.

Examples:

```text
ACCOUNT OWNERSHIP
TENANT ISOLATION
PAYMENT / MONEY
CREDENTIALS
PRIVATE DATA
ADMIN CONTROL
EXPORTS
SECURITY SETTINGS
API KEYS
CLOUD CREDENTIALS
TRUSTED INTEGRATIONS
SOURCE CODE
DEPLOYMENT CONTROL
```

For each crown jewel ask:

```text
Who can access it?
Who can modify it?
Who can trigger state change?
What authenticates the actor?
What authorizes the action?
What other service can act on its behalf?
What indirect path reaches it?
```

---

# 3. TRUST-BOUNDARY GRAPH

Represent the product as:

```text
ANONYMOUS USER
     ↓
WEB / API EDGE
     ↓
AUTHENTICATION
     ↓
AUTHORIZATION
     ↓
BUSINESS LOGIC
     ↓
APPLICATION SERVICE
     ↓
DATABASE / STORAGE
     ↓
WORKER / QUEUE
     ↓
THIRD-PARTY INTEGRATION
```

Add branches for:

- mobile clients
- GraphQL
- WebSockets
- webhooks
- OAuth
- SSO
- export workers
- file processors
- CDN/cache
- admin plane
- background jobs
- notification services

Every edge is a possible trust-boundary transition.

---

# 4. BUSINESS-MODEL → ATTACK-VECTOR MAPPING

For each business function:

```text
BUSINESS FUNCTION
→ ASSET
→ ACTOR
→ VALUE
→ SECURITY INVARIANT
→ POSSIBLE VIOLATION
→ ATTACK VECTOR
```

Examples:

### Billing

```text
billing
→ payment amount / entitlement
→ customer
→ money / access
→ amount must be server-authoritative
→ client value manipulation / replay / race
→ Business Logic + Race
```

### Team management

```text
team
→ membership / role
→ member/admin
→ organizational control
→ actor can modify only authorized membership
→ IDOR / privilege escalation / mass assignment
→ IDOR + Authenticated + Business Logic
```

### Export

```text
export
→ dataset
→ authorized member
→ private data
→ export limited to authorized tenant
→ job/status/download mismatch
→ IDOR + background-worker authz + Info Disclosure
```

---

# 5. IDENTITY ATTACK MAP

Map transitions:

```text
REGISTER
VERIFY
LOGIN
MFA
RECOVERY
PASSWORD RESET
EMAIL CHANGE
PHONE CHANGE
SESSION
TOKEN REFRESH
OAUTH LINK
SSO
INVITE
ACCOUNT MERGE
ACCOUNT DELETE
```

For each ask:

```text
Can identity evidence belong to another account?
Can a verified state become stale?
Can a token be replayed?
Can one API enforce a gate while another omits it?
Can a low-privileged session reach a higher-privileged action?
Can account linking cross identities?
Can recovery be redirected?
```

Route to ATO, Authenticated, Business Logic, Race, IDOR, or Chaining.

---

# 6. AUTHORIZATION ATTACK MAP

Map:

```text
USER → OBJECT
USER → ACTION
ROLE → FUNCTION
TENANT → OBJECT
ROLE → FIELD
SESSION → CURRENT STATE
```

Generate explicit differential hypotheses:

```text
A → A
A → B
B → B
Unauth → A
Low role → privileged object
Tenant A → Tenant B
```

Use the separate IDOR/Access Control skill for deep execution.

---

# 7. OBJECT-CENTRIC MAP

For every important business object record:

```text
OBJECT
IDENTIFIER
CREATION
READ
UPDATE
DELETE
SHARE
EXPORT
DOWNLOAD
APPROVE
REFUND
TRANSFER
ARCHIVE
RESTORE
```

Then ask:

> Is authorization checked on every action, or only when the object is first created/retrieved?

This catches action-specific IDORs and “second endpoint” failures.

---

# 8. STATE-MACHINE ATTACK MAP

For every high-value workflow:

```text
STATE A
  ↓
ACTION
  ↓
STATE B
  ↓
ACTION
  ↓
STATE C
```

Now construct invalid transition hypotheses:

```text
A → C
B → A
B → C without prerequisite
C → C repeated
revoked → active
pending → fulfilled
unverified → privileged
canceled → active
expired → usable
```

This routes to Business Logic, Race, ATO, Authenticated, and Chaining.

The supplied methodology explicitly models state, side effects, downstream services and expected invariants because the vulnerable endpoint may occur later in the workflow. fileciteturn5file3L544-L585

---

# 9. INTEGRATION ATTACK MAP

For each integration:

```text
TRUST DIRECTION
AUTH METHOD
DATA SENT
DATA RECEIVED
CALLBACK
WEBHOOK
RETRY
FAILURE
REDIRECT
```

Map risks:

```text
external input
→ webhook
→ backend parser
→ internal state
```

or:

```text
user URL
→ external fetcher
→ internal service
```

Route to SSRF, Webhook Security, Business Logic, ATO, RCE, Cache, or Chaining.

---

# 10. INFRASTRUCTURE → APPLICATION MAPPING

Do not treat infrastructure and application surfaces separately.

Map:

```text
DOMAIN
→ IP
→ CDN
→ ORIGIN
→ SERVICE
→ API
→ AUTH
→ DATA
```

Ask:

- does direct-origin access differ from edge access?
- are alternate ports serving different applications?
- do legacy hosts share the same backend?
- does a forgotten service expose the same objects?
- is authentication consistent across interfaces?

Route infrastructure findings to the IP/CIDR Hunting skill where appropriate.

---

# 11. CLIENT ↔ SERVER TRUST MAP

Identify all security decisions made in:

```text
browser/client
mobile app
frontend state
JWT claims
local storage
hidden fields
UI controls
```

For each security decision ask:

> Does the server independently enforce this invariant?

Client-side-only enforcement is a lead.

The existing methodology explicitly emphasizes that client-side trust becomes a reportable security issue only when the server relies on the client decision. fileciteturn5file3L491-L504

---

# 12. HIDDEN AREA GENERATOR

Now generate attack surfaces a generic checklist is likely to miss.

## Category A — Sibling Interfaces

For every known feature look for:

- web UI
- REST
- GraphQL
- mobile API
- WebSocket
- background job API
- bulk endpoint
- export endpoint
- download endpoint
- admin endpoint
- legacy endpoint

Question:

> Is the same invariant enforced in every interface?

---

# 13. LEGACY / VERSION WHITE SPACE

Generate:

```text
/api/
/api/v1/
/api/v2/
/api/v3/
/legacy/
/internal/
/beta/
/preview/
/experimental/
```

Do not blindly scan all names.

Generate hypotheses from:

- documentation
- JS
- changelog
- historical URLs
- source references
- links

Prioritize versions that represent actual product evolution.

---

# 14. BACKGROUND / ASYNC WHITE SPACE

For every asynchronous feature identify:

```text
CREATE JOB
→ JOB ID
→ STATUS
→ RESULT
→ DOWNLOAD
→ RETRY
→ CALLBACK
```

Attack-vector candidates:

- status IDOR
- result IDOR
- stale authorization
- cross-tenant job access
- post-revocation job use
- worker privilege mismatch
- replay
- duplicate execution
- callback confusion

This is a high-value white-space area because the user-facing request is often not the security boundary.

---

# 15. FILE / IMPORT / EXPORT WHITE SPACE

If the product handles files:

Map:

```text
UPLOAD
VALIDATION
STORAGE
PROCESSING
PREVIEW
CONVERSION
EXPORT
DOWNLOAD
SHARE
DELETE
RESTORE
```

Potential specialist routes:

- SSRF
- RCE
- path traversal
- information disclosure
- IDOR
- business logic
- cache
- authorization

The route is based on actual observed behavior, not the feature name alone.

---

# 16. SEARCH / FILTER / SORT WHITE SPACE

For every search interface:

Map:

```text
q
filter
sort
order
fields
pagination
export
```

Potential routes:

- SQLi/NoSQLi
- authorization leakage
- information disclosure
- resource exhaustion where authorized
- tenant filtering failures

Do not equate unusual search output with a vulnerability until unauthorized capability is proven.

---

# 17. PAYMENT / ENTITLEMENT WHITE SPACE

For products involving money:

Map:

```text
PRICE
TAX
DISCOUNT
COUPON
CURRENCY
PAYMENT
CONFIRMATION
WEBHOOK
ENTITLEMENT
REFUND
CANCELLATION
RENEWAL
```

Potential vectors:

- price authority mismatch
- discount stacking
- coupon reuse
- payment confirmation race
- webhook replay
- entitlement before payment
- canceled payment remains active
- refund remains entitled
- account mismatch
- invoice/object IDOR

Route to Business Logic + Race + ATO + Validation.

---

# 18. SHARING / COLLABORATION WHITE SPACE

If users can share:

Map:

```text
INVITE
SHARE LINK
ACCESS TOKEN
PERMISSION
EXPIRATION
REVOCATION
RESEND
FORWARD
PUBLIC LINK
```

Hypotheses:

- token not bound to object
- token not bound to user
- stale permissions
- revoked link remains valid
- cross-tenant sharing
- object enumeration

Route to IDOR, ATO, Business Logic, Information Disclosure.

---

# 19. NOTIFICATION WHITE SPACE

Email/SMS/push notifications can become security boundaries.

Map:

```text
TRIGGER
RECIPIENT
IDENTITY SOURCE
CONTENT
LINK
TOKEN
RETRY
```

Ask:

- can an attacker influence recipient?
- does the message contain sensitive links/tokens?
- can a state-changing link be replayed?
- does notification delivery create an account-control path?

Route to ATO, CSRF, Information Disclosure, Business Logic.

---

# 20. SUPPORT / HELP-DESK WHITE SPACE

If support workflows exist:

Map:

```text
TICKET
IDENTITY VERIFICATION
ACCOUNT RECOVERY
IMPERSONATION
PRIVILEGE ESCALATION
EXPORT
ADMIN ACTION
```

Look for discrepancies between customer-facing policy and technical enforcement.

Do not social-engineer personnel unless explicitly authorized.

Use documentation and technical workflow analysis first.

---

# 21. API GRAPH / GRAPHQL WHITE SPACE

Map API operations by:

```text
QUERY
MUTATION
SUBSCRIPTION
OBJECT
FIELD
ROLE
TENANT
```

Ask:

- object-level auth?
- field-level auth?
- mutation auth?
- bulk operation auth?
- alternate resolver?
- node lookup bypass?
- introspection-derived attack surface?

Route to Authenticated, IDOR, Injection, Business Logic, Validation.

---

# 22. WEBHOOK / CALLBACK WHITE SPACE

For every callback:

```text
SOURCE
SIGNATURE
SECRET
TIMESTAMP
REPLAY CONTROL
OBJECT BINDING
STATE CHANGE
```

Hypotheses:

- unsigned webhook
- replay
- cross-account callback
- stale callback
- amount/status trust
- object mismatch

Route to Business Logic, Race, ATO, Information Disclosure.

---

# 23. CACHE / EDGE WHITE SPACE

Map:

```text
CACHE KEY
VARY
HOST
PATH
QUERY
AUTH STATE
RESPONSE
TTL
PURGE
```

Potential vectors:

- cache deception
- cache poisoning
- auth-state cache leakage
- tenant bleed
- normalization mismatch

Route to Cache skill.

---

# 24. PROTOCOL / PARSER WHITE SPACE

If multiple layers exist:

```text
CDN
WAF
proxy
HTTP gateway
application server
backend service
```

Look for parser disagreements.

Route to HTTP Request Smuggling and WAF Differential skills.

Do not claim parser ambiguity without demonstrating a real divergence.

---

# 25. SECRETS / DISCLOSURE WHITE SPACE

Map locations where secrets can unintentionally cross boundaries:

- JS bundles
- source maps
- logs
- exports
- error messages
- API responses
- notifications
- downloadable artifacts
- debug pages
- configuration endpoints

Route confirmed sensitive disclosures to Information Disclosure.

Validate secrets non-destructively.

---

# 26. PRODUCT-SPECIFIC ATTACK VECTOR MATRIX

Produce a table:

| Surface | Invariant | Hypothesis | Skill | Impact Potential | Evidence Needed | Priority |
|---|---|---|---|---|---|---|
| Billing | price authoritative server-side | price mutation | Business Logic | High | successful underpayment | P0 |
| Export | tenant isolation | result IDOR | IDOR | High | cross-tenant data | P0 |
| Recovery | token bound to user | token reuse | ATO | Critical | controlled ATO | P0 |

Do not fill with generic guesses. Every row must be tied to observed product behavior.

---

# 27. MULTI-AXIS ATTACK MAPPING

Every important feature should be examined through at least these lenses:

### Actor
- anonymous
- user
- low-privilege
- manager
- admin
- service account

### Object
- own
- another user
- another tenant
- deleted
- archived

### State
- before
- during
- after
- expired
- revoked
- canceled

### Interface
- web
- API
- mobile
- GraphQL
- WebSocket
- webhook
- background worker

### Network path
- edge
- origin
- alternate host
- direct IP
- internal integration

### Input representation
- query
- path
- JSON
- form
- multipart
- header
- cookie
- URL

### Time
- first request
- replay
- concurrent request
- stale session
- post-revocation

This matrix is designed to expose inconsistencies that a single-path checklist misses.

---

# 28. WHITE-SPACE SCORE

Assign each unexplored area:

```text
+3 new/rare interface
+3 privilege-sensitive
+3 financial / account / tenant impact
+2 recently changed
+2 legacy/alternate implementation
+2 complex workflow
+2 cross-service
+1 documentation ambiguity
+1 inconsistent naming/implementation
```

Again, this is prioritization, not severity.

Sort by:

```text
Expected Impact × Evidence Availability × White-Space Score
```

---

# 29. DEVELOPER-CONSISTENCY TEST

Compare sibling implementations.

Examples:

```text
REST checks tenant
GraphQL may differ

v2 checks ownership
v1 may differ

web checks verification
mobile API may differ

single-object endpoint checks role
bulk endpoint may differ

create endpoint validates state
update endpoint may not
```

Differences are high-value hypotheses.

Do not report inconsistency without proving a security effect.

---

# 30. “SAME FEATURE, DIFFERENT PATH” RULE

For every critical feature ask:

> What is the alternate way to accomplish exactly this outcome?

Examples:

```text
UI
API
mobile
bulk API
export
share link
background job
admin tool
legacy route
callback
```

The alternate path is often where the missing security check appears.

---

# 31. “WHAT IF I REMOVE ONE ASSUMPTION?”

For each security-sensitive feature ask:

```text
What if I remove authentication?
What if I keep authentication but change object ID?
What if I keep object ID but change tenant?
What if I skip the previous state?
What if I repeat the action?
What if I change role-related fields?
What if I use another interface?
What if the callback arrives late?
What if the user was revoked?
What if the request reaches origin directly?
What if the same action happens concurrently?
```

Each “what if” becomes a hypothesis only when grounded in actual product behavior.

---

# 32. ATTACK VECTOR PRIORITIZATION

Priority P0:

- account control
- admin privilege
- cross-tenant compromise
- major financial impact
- credentials
- RCE
- sensitive internal systems
- critical authorization bypass

Priority P1:

- significant data exposure
- privilege escalation
- meaningful SSRF
- cache compromise
- important business logic

Priority P2:

- limited authorization issues
- non-critical disclosure
- lower-impact integrity issues

Priority P3:

- informational/hygiene
- theoretical risks

The Critical Severity Finder remains the final impact prioritizer; do not infer Critical solely from the class.

---

# 33. SPECIALIST ROUTING

Route by evidence:

```text
URL FETCH            → SSRF
OBJECT REFERENCE     → IDOR / AuthZ
LOGIN / RECOVERY     → ATO
CONCURRENCY          → Race
EXECUTION SINK       → RCE
HTTP PROXY DIFF      → Smuggling
WAF DIFFERENTIAL     → WAF
CACHE DIFFERENTIAL   → Cache
BUSINESS STATE       → Business Logic
SENSITIVE DISCLOSURE → Information Disclosure
IP/CIDR SURFACE      → IP/CIDR Hunter
JS                  → MasterJS
BROWSERLESS         → Curl
LOW/MED CONFIRMED    → Chaining Engine
FINAL                → Validation / Triage
```

Do not invoke every skill on every feature.

Use the minimum set with the highest information gain.

---

# 34. ATTACK PATH GRAPH

Build explicit graphs:

```text
ENTRY
  ↓
TRUST BOUNDARY
  ↓
PRIMITIVE
  ↓
OBJECT / SERVICE
  ↓
SECURITY CONTROL
  ↓
VIOLATION
  ↓
CAPABILITY
  ↓
IMPACT
```

Possible entries:

- anonymous endpoint
- authenticated user
- leaked identifier
- URL fetch
- file upload
- webhook
- alternate interface
- direct origin
- legacy endpoint

---

# 35. CHAIN-FIRST THINKING, WITHOUT SPECULATION

Every confirmed Low/Medium issue gets one question:

> What capability does this unlock that was previously unavailable?

Then test the connector with safe, authorized evidence.

Do not write:

```text
Low A
could maybe
lead to
Critical B
```

Instead:

```text
A proven
→ B tested
→ B proven
→ C tested
→ C proven
→ impact established
```

Only the proven chain influences final severity.

---

# 36. DUPLICATE / SYSTEMIC AWARENESS

Before spending significant time on a vector, compare with historical findings if legitimately available.

Cluster by:

- vulnerability type
- target
- endpoint
- root cause
- exploitation method
- business function
- remediation

The existing research material explicitly emphasizes that historical findings should be treated as a program-specific knowledge base, not merely title lists. fileciteturn5file0L85-L134

---

# 37. FALSE-POSITIVE GATE

Reject a candidate when:

- documentation explains the behavior as intentional and implementation confirms it
- capability remains within the authorized trust boundary
- data is already public
- no meaningful impact exists
- the difference is cosmetic
- client-only behavior is correctly enforced server-side
- the chain is only hypothetical
- the candidate is already known and unchanged

Record the rejection reason.

---

# 38. FINAL ATTACK QUEUE FORMAT

Produce:

```text
RANK 1
Feature:
Attack Vector:
Trust Boundary:
Hypothesis:
Why This Product Makes It Interesting:
Evidence Needed:
Specialist:
Chain Potential:
Stop Condition:

RANK 2
...
```

The queue should contain high-value, product-specific hypotheses, not generic vulnerability names.

---

# 39. HANDOFF TO HUNTING

Only after the attack map is complete:

```text
Product Understanding
      ↓
Attack Vector Map
      ↓
Skill Decision Maker
      ↓
Specialist
      ↓
Curl / JS execution layer
      ↓
Chaining
      ↓
Validation
```

Never bypass scope and authorization gates.

---

# 40. COMPLETION CRITERIA

The mapping phase is complete only when:

- crown jewels are identified
- trust boundaries are mapped
- major business flows are mapped
- identity transitions are mapped
- object/tenant relationships are mapped
- integrations are mapped
- infrastructure is mapped
- alternate interfaces are mapped
- state-transition abuse cases exist
- legacy/version white space is checked
- async/background-job white space is checked
- import/export/share paths are mapped
- payment/entitlement paths are mapped when present
- support/recovery paths are mapped
- cache/edge boundaries are considered
- API/GraphQL/WS boundaries are considered when present
- IP/origin surfaces are mapped where authorized
- historical/duplicate signals are incorporated
- each attack vector has evidence requirements
- the attack queue is prioritized by product-specific impact

---

# 41. FINAL DIRECTIVE

Think like a product attacker, not a checklist runner.

Do not ask:

> “Which vulnerability should I test?”

Ask:

> “Which security invariant is most valuable on this product, where is that invariant enforced, and which alternate path is most likely to violate it?”

Do not start with payloads.
Start with product behavior.

Do not start with endpoints.
Start with assets, actors, state and trust.

Do not stop at anomalies.
Convert anomalies into security-boundary hypotheses.

Do not stop at Low/Medium findings.
Investigate validated chain potential.

Do not invent chains.
Prove them.

The ideal result is:

```text
PRODUCT UNDERSTANDING
→ PRODUCT-SPECIFIC ATTACK MAP
→ HIDDEN WHITE SPACE
→ HIGH-VALUE HYPOTHESIS
→ SPECIALIST EXECUTION
→ SERVER-SIDE PROOF
→ IMPACT
→ CHAIN
→ VALIDATION
→ NOVEL REPORT
```

END OF PRODUCT-SPECIFIC ATTACK VECTOR MAPPER
