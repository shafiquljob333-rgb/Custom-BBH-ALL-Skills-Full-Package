# BBP All Skills Package — Bug Bounty Hunting Skills Backup

Created: 2026-09-11
Purpose: complete backup of every bug-bounty-hunting skill on this machine.
Restore: copy any skill folder's <name>/SKILL.md tree back into a plugin skills/ dir or ~/.zcode/skills/<name>/.

## Contents
### 01-claude-bughunter-plugin-86-skills — 108 files
Claude-BugHunter plugin v2.1.0 (live cache) — 86 skills incl. the 2 newest (bb-novelty-research-engine, bug-bounty-architecture-novelty-hunting) and 3 repaired skills (bug-bounty, bb-local-toolkit, osint-methodology). Full skill dirs with references/scripts.

### 02-insane-bughunting-plugin-61-skills — 80 files
Insane Bug Hunting plugin v1.0.0 (live cache) — 61 skills, full dirs incl. references (bug-bounty-hunter, js-analyzer, ultra-hunter, platform-intel, etc.).

### 03-custom-skills-2026-era-62-files — 62 files
Custom collection 'Bug Bounty Hunting All Custom Skills in 2026 Era' from Documents — portable bug-bounty-hunter skill + 61 reference .md files.

### 04-updated-custom-skills-62-files — 62 files
Custom collection 'Updated all Bug Bpunty Hunting Skills' from Documents — 62 numbered skill files (00-high-severity-hunter-orchestrator ... 61-x).

### 05-claude-bughunter-github-master-extracted/83-skills — 105 files
Original upstream GitHub repo (Claude-BugHunter-main.zip) skills — 83 skills as shipped before local additions/fixes.

### 06-source-master-prompts — 2 files
The two source prompts from Documents: MASTER_FINAL novelty-first engine and Jaksec architecture methodology (full content also inside plugin skills in folder 01).

Files in 03-custom-skills-2026-era-62-files: 00-high-severity-hunter-orchestrator.md, 01-masterjs-analyzer.md, 02-curl-http-operator.md, 03-business-logic-hunter.md, 04-unauthenticated-hunter.md, 05-authenticated-hunter.md, 06-validation-triage-novelty-reporting.md, 07-ssrf-all-types-hunter.md ...

Files in 04-updated-custom-skills-62-files: 00-high-severity-hunter-orchestrator.md, 01-masterjs-analyzer.md, 02-curl-http-operator.md, 03-business-logic-hunter.md, 04-unauthenticated-hunter.md, 05-authenticated-hunter.md, 06-validation-triage-novelty-reporting.md, 07-ssrf-all-types-hunter.md ...

## Notes
- Folders 01 and 02 are the LIVE plugin installs (freshest, all fixes included).
- Folder 05 is the untouched upstream GitHub source for comparison/restoration of stock state.
- Same-named skills appear in multiple folders ON PURPOSE (different versions/sources) — this is a backup, keep the version you need.
- Total files in package: 421