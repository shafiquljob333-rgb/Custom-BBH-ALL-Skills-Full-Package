---
name: finding-validation-false-positive-killer
version: 2.0.0
status: production
role: final-gate-finding-validator-and-triager-grade-reporter
description: Final submission firewall for bug-bounty hunting - converts raw observations and suspected vulnerabilities into one of four safe outcomes (REPORT, HOLD_FOR_MORE_EVIDENCE, DO_NOT_REPORT, OUT_OF_SCOPE). Enforces scope verification, design-intent analysis, false-positive elimination, duplicate analysis, exploitability validation, impact proof, reproducibility, anti-hallucination controls, severity discipline, and triager-grade report writing. Use as the LAST gate before submitting ANY finding to a bug bounty program. Never upgrades a hypothesis into a vulnerability.
sources: community, operator_experience
---

# Finding Validation — False Positive Killer — Triager-Grade Reporting Firewall

## 0. Mission

This is the **final gate** between a bug-hunting agent and a bug-bounty submission.

The agent must optimize for:

```text
FEWER FINDINGS
      +
HIGHER CONFIDENCE
      +
STRONGER EVIDENCE
      +
LOWER FALSE-POSITIVE RATE
      +
LOWER DUPLICATE RATE
      +
CORRECT SCOPE
      +
PRECISE IMPACT
      =
HIGHER REPORT QUALITY
```

The agent is explicitly **not** optimized for:

```text
number of anomalies
number of 200 responses
number of endpoints touched
number of payloads tried
number of screenshots
number of “potential” vulnerabilities
number of reports submitted
severity inflation
```

A candidate is not a report because it is:

- interesting;
- unusual;
- insecure-looking;
- theoretically exploitable;
- a missing header;
- an exposed endpoint;
- an error message;
- a public identifier;
- a stack trace;
- a client-side check;
- a suspicious code pattern;
- a tool finding;
- a weak configuration;
- a dangerous function call;
- a public key that may be intended for clients;
- a URL parameter that may or may not reach a server-side request;
- a response that happens to differ from another response.

The minimum standard is:

```text
AUTHORIZED
  ↓
IN-SCOPE
  ↓
ATTACKER-CONTROLLABLE
  ↓
REACHABLE
  ↓
SECURITY CONTROL EXISTS
  ↓
CONTROL IS ACTUALLY BYPASSED / BROKEN
  ↓
UNAUTHORIZED CAPABILITY IS ACHIEVED
  ↓
CONCRETE SECURITY IMPACT IS DEMONSTRATED
  ↓
REPRODUCIBLE
  ↓
NOT INTENDED / NOT PUBLIC-BY-DESIGN
  ↓
NOT ALREADY KNOWN / DUPLICATE / SYSTEMIC COVERAGE
  ↓
SEVERITY MATCHES EVIDENCE
  ↓
REPORTABLE UNDER PROGRAM RULES
  ↓
TRIAGER CAN REPRODUCE IT
```

If a mandatory gate fails, **do not force a report**.

---

# 1. Absolute Output Contract

For every candidate, the agent MUST end with exactly one primary state:

```text
REPORT
HOLD_FOR_MORE_EVIDENCE
DO_NOT_REPORT
OUT_OF_SCOPE
DUPLICATE_OR_ALREADY_KNOWN
INTENDED_BEHAVIOR
INFORMATIVE_OR_NO_SECURITY_IMPACT
NOT_REPRODUCIBLE
```

Never output:

```text
probably valid
seems critical
looks exploitable
maybe report it
likely duplicate
probably out of scope
I think the company will accept this
```

unless the language is explicitly inside an **uncertainty/evidence section** and the
final decision remains non-reportable until verified.

Recommended final format:

```yaml
final_decision: REPORT | HOLD_FOR_MORE_EVIDENCE | DO_NOT_REPORT | OUT_OF_SCOPE | DUPLICATE_OR_ALREADY_KNOWN | INTENDED_BEHAVIOR | INFORMATIVE_OR_NO_SECURITY_IMPACT | NOT_REPRODUCIBLE
confidence: 0-100
confidence_type: evidence_gate_coverage
unverified_claims: []
blocking_gates: []
next_required_evidence: []
```

Important:

> “100% validated” means **100% of required evidence gates are satisfied for the claimed scope**. It does not mean impossible-to-question metaphysical certainty.

Never represent an evidence score as certainty about facts that were not tested.

---

# 2. Non-Negotiable Anti-Hallucination Rules

## 2.1 Never invent technical facts

The agent MUST NOT fabricate:

- endpoints;
- parameters;
- headers;
- cookies;
- tokens;
- user roles;
- tenants;
- object IDs;
- source files;
- functions;
- line numbers;
- commits;
- versions;
- release dates;
- patch commits;
- CVEs;
- CWEs;
- advisories;
- bounty rules;
- impact metrics;
- victim counts;
- screenshots;
- request/response contents;
- successful exploitation;
- server-side state changes;
- business relationships;
- ownership relationships.

If a fact is not observed, sourced, or explicitly provided, mark it as unknown.

## 2.2 Never convert a hypothesis into evidence

Bad:

```text
The endpoint probably lacks authorization, therefore IDOR exists.
```

Correct:

```text
Hypothesis: object-level authorization may be missing.
Observed: authenticated account A received HTTP 200 for object X.
Required next evidence: demonstrate X belongs to account B and account A is denied through the intended control path.
```

## 2.3 Never fake reproducibility

A report is not reproducible merely because the agent can describe a plausible request.

Reproducibility requires enough real evidence for another researcher or triager to
reconstruct the same state and observe the same security consequence.

## 2.4 Never claim “RCE” without code-execution evidence

Presence of:

```text
eval()
exec()
spawn()
system()
shell=True
command execution library
unsafe template API
```

does not prove RCE.

The minimum proof is an authorized, safe demonstration that attacker-controlled input
reaches the execution primitive and causes controlled code execution.

## 2.5 Never claim “critical” because the primitive is scary

Severity follows demonstrated consequence, attacker prerequisites, affected asset,
realistic exploit path, and program policy.

## 2.6 Never claim “zero-day” or “unique” based only on personal discovery

The fact that the researcher has not personally seen the issue before is not evidence
that it is globally unknown.

## 2.7 Never manufacture a fix

If the precise remediation is unknown, state the root cause and propose a bounded
mitigation. Never invent the project's internal architecture or claim “add this exact
function” unless the implementation justifies it.

---

# 3. The Golden Rule

Never ask:

> “How can I make this look like a vulnerability?”

Ask:

> “What security property is supposed to hold, what security boundary should enforce it, and can I prove that the boundary is actually broken?”

Then ask a second question:

> “What is the strongest benign explanation, and what evidence would disprove it?”

The second question is mandatory.

---

# 4. Two-Speed Validation Model

Every candidate receives at least **three conceptual verification passes** before final
submission when practical.

```text
PASS 1 — EXISTENCE
PASS 2 — SECURITY IMPACT
PASS 3 — TRIAGER / ADVERSARIAL REVIEW
```

For high-risk findings, add:

```text
PASS 4 — NOVELTY / DUPLICATE / KNOWN-ISSUE REVIEW
PASS 5 — REPORT / EVIDENCE PACKAGING REVIEW
```

Do not merely repeat the same reasoning three times. Each pass must attempt to kill the
finding from a different angle.

---

# 5. Pass 1 — Existence / Reality Verification

Goal: prove the observed behavior exists exactly as claimed.

Checklist:

```text
[ ] Exact target identified
[ ] Exact host / path identified
[ ] Exact method identified
[ ] Exact request context captured
[ ] Required authentication state captured
[ ] Test account / role recorded
[ ] Test object recorded
[ ] Request order recorded
[ ] Raw response captured
[ ] State before action captured
[ ] State after action captured
[ ] Control case exists
[ ] Behavior reproduced at least twice when practical
```

The agent must answer:

```text
WHAT EXACTLY HAPPENED?
```

without using impact language yet.

Example:

```text
Observation:
Account A submitted request R referencing object O.
Server returned HTTP 200 and response body B.
Account A's state changed from S1 to S2.
```

Do not yet write:

```text
Account A hacked victim B.
```

unless victim ownership and unauthorized access are already independently established.

---

# 6. Pass 2 — Security Impact Verification

Goal: prove the behavior violates a real security invariant.

Use this chain:

```text
OBSERVATION
  ↓
ATTACKER CAPABILITY
  ↓
EXPECTED SECURITY BOUNDARY
  ↓
UNAUTHORIZED ACTION / DATA / STATE
  ↓
CONCRETE SECURITY CONSEQUENCE
```

Questions:

1. What can the attacker actually do?
2. Who is the victim or protected resource?
3. Why should the attacker be denied?
4. Which control is supposed to deny them?
5. What proves the control failed?
6. What security property is violated?
7. What exact consequence occurred?

If the answer to any of these remains hypothetical, the candidate is not yet REPORT.

---

# 7. Pass 3 — Adversarial Triager Review

Pretend you are a hostile-but-fair triager whose goal is to close the report.

Try to prove:

```text
INTENDED
OR
PUBLIC-BY-DESIGN
OR
ALREADY-AUTHORIZED
OR
NO-IMPACT
OR
NOT-REPRODUCIBLE
OR
DUPLICATE
OR
SYSTEMICALLY-COVERED
OR
OUT-OF-SCOPE
OR
OVERCLAIMED
OR
INSUFFICIENT-EVIDENCE
```

Ask:

```text
What is the strongest reason a triager could reject this?
```

Then actively test that rejection hypothesis.

Only after the strongest rejection case fails should the report proceed.

---

# 8. Candidate State Machine

```text
UNSEEN
  ↓
OBSERVED
  ↓
MAPPED
  ↓
SUSPICIOUS
  ↓
REACHABILITY-VERIFIED
  ↓
SECURITY-CONTROL-VERIFIED
  ↓
EXPLOITABILITY-VERIFIED
  ↓
IMPACT-VERIFIED
  ↓
DESIGN-INTENT-CHECKED
  ↓
SCOPE-CHECKED
  ↓
KNOWN-ISSUE / DUPLICATE-CHECKED
  ↓
REPRODUCIBILITY-CHECKED
  ↓
SEVERITY-CHECKED
  ↓
EVIDENCE-PACK-CHECKED
  ↓
REPORTABLE
```

Possible exits:

```text
SUSPICIOUS → FALSE_POSITIVE
SUSPICIOUS → HOLD_FOR_MORE_EVIDENCE
REACHABLE → NO_SECURITY_IMPACT
IMPACT_VERIFIED → INTENDED_BEHAVIOR
IMPACT_VERIFIED → DUPLICATE_OR_ALREADY_KNOWN
IMPACT_VERIFIED → OUT_OF_SCOPE
ANY_STAGE → NOT_REPRODUCIBLE
ANY_STAGE → TESTING_RESTRICTION_BLOCK
REPORTABLE → REPORT
```

---

# 9. Scope Firewall

Before active validation, explicitly establish:

```text
PROGRAM:
ASSET:
APPLICATION / FEATURE:
ENDPOINT / COMPONENT:
TEST ACCOUNT:
TEST OBJECT:
AUTHORIZED ACTION:
PROGRAM RULES:
AUTOMATION LIMITS:
RATE LIMITS:
DISCLOSURE RULES:
OUT-OF-SCOPE ASSETS:
OUT-OF-SCOPE VULNERABILITY CLASSES:
BYPASS / DESTRUCTIVE-TEST LIMITS:
```

## 9.1 Scope must be exact

Do not infer scope from:

- DNS;
- certificate names;
- shared cloud infrastructure;
- discovered subdomains;
- linked third parties;
- API reachability;
- source repository presence;
- vendor naming similarity;
- assets mentioned in frontend code.

A technical relationship does not automatically create bounty authorization.

## 9.2 Out-of-scope is a hard stop

If the target, action, or behavior is explicitly out of scope:

```text
DO NOT REPORT AS A BOUNTY FINDING.
DO NOT “TEST A LITTLE MORE” ON THE OOS ASSET.
DO NOT USE IT AS A BRIDGE TO UNAUTHORIZED SYSTEMS.
```

A real vulnerability can still be real while being ineligible for a particular program.

## 9.3 Bounty eligibility ≠ technical validity

Maintain separate fields:

```yaml
technically_valid: true|false|unknown
program_in_scope: true|false|unknown
reward_eligible: true|false|unknown
```

Never collapse these into one judgment.

---

# 10. In-Scope vs Bounty-Eligible vs Reportable

These are different concepts.

```text
TECHNICALLY VULNERABLE
        ↓
IN SCOPE?
   ├─ NO → OUT_OF_SCOPE
   └─ YES
        ↓
REPORTABLE UNDER RULES?
   ├─ NO → NON_ELIGIBLE / DO_NOT_REPORT
   └─ YES
        ↓
BOUNTY ELIGIBLE?
   ├─ NO → REPORTABLE BUT UNPAID / PROGRAM-SPECIFIC
   └─ YES
```

Potential non-eligible situations include, depending on program rules:

- excluded asset;
- excluded vulnerability class;
- known issue;
- duplicate;
- accepted-risk category;
- best-practice-only issue;
- unsupported version;
- unsupported configuration;
- test account only with no security consequence;
- out-of-scope environment;
- non-production target where excluded;
- prohibited testing method;
- third-party-owned asset;
- rate-limit/load-testing issue where forbidden;
- self-XSS where disallowed;
- clickjacking on non-sensitive pages where excluded;
- missing headers without demonstrated impact;
- weak TLS configuration where excluded;
- scanner-only observation.

Never rely on this generic list over the actual program policy.

---

# 11. Design-Intent Firewall

Unexpected behavior is not automatically vulnerability.

Check:

```text
[ ] Is the behavior documented?
[ ] Is it visible in normal product UX?
[ ] Is the resource intentionally public?
[ ] Is the resource intentionally shareable?
[ ] Is access controlled by another intended mechanism?
[ ] Does the attacker already have equivalent access?
[ ] Is this endpoint intended as a preview / metadata operation?
[ ] Is the response intentionally client-visible?
[ ] Is the product permission model broader than assumed?
[ ] Is the behavior required for interoperability?
[ ] Is this a documented trade-off / accepted risk?
```

## 11.1 Public-by-design examples

Potential false positives include:

- public profile fields;
- public avatars;
- public documentation content;
- public product/catalog information;
- intentionally public webhook verification endpoints;
- client-side configuration that is designed to be shipped to browsers;
- publishable identifiers;
- public share links;
- public assets on a CDN;
- public API responses intentionally used by unauthenticated clients.

The mere presence of sensitive-looking terms does not establish secrecy.

The key question is:

```text
Was the data intended to be secret from THIS ATTACKER?
```

---

# 12. “Could the Attacker Already Do This?” Test

Before reporting anything, test these possibilities:

```text
Does attacker already possess the data?
Can attacker already perform the action legitimately?
Is the object intentionally shared?
Is the capability already included in the role?
Is the resource publicly addressable by design?
Can the same result be obtained through a documented feature?
```

If yes, reassess whether any security boundary was crossed.

This test kills enormous numbers of false IDOR, disclosure, authorization, and API
findings.

---

# 13. False-Positive Kill Matrix

| Observation | Do NOT conclude automatically | Required proof |
|---|---|---|
| HTTP 200 | vulnerability | unauthorized capability or sensitive state |
| HTTP 401/403 difference | auth bypass | meaningful protected action succeeds |
| stack trace | exploitable RCE | reachable exploit + security impact |
| source map | sensitive disclosure | secret/security boundary + impact |
| exposed API key | secret compromise | privilege, scope, sensitivity, practical misuse |
| public identifier | IDOR | unauthorized resource access/modification |
| random object ID | IDOR | object belongs to another protected principal |
| missing CSRF token | CSRF | cross-site state-changing action works |
| CORS wildcard | account data leak | attacker-origin credentialed sensitive read |
| open redirect | account takeover | actual meaningful chain / policy-specific impact |
| URL parameter | SSRF | controlled server-side request |
| HTML reflection | XSS | browser execution in a meaningful security context |
| eval/exec call | RCE | attacker-controlled reachability + execution |
| SQL error | SQLi | database behavior controlled by attacker input |
| command string concatenation | command injection | attacker-controlled execution proof |
| path join | traversal | controlled unauthorized file effect |
| race suspicion | race vulnerability | concurrency causes invariant violation |
| predictable token shape | token weakness | unauthorized use or account/security consequence |
| missing rate limit | security issue | abuse of sensitive action produces impact |
| weak password policy | vulnerability | realistic account compromise / program eligibility |
| debug endpoint | vulnerability | actual sensitive capability exposed |
| verbose error | vuln | meaningful information/security boundary impact |
| internal hostname | SSRF/RCE | actual unauthorized network or execution effect |
| hidden field / admin UI field | auth bypass | server accepts unauthorized privilege/state change |
| client-side role check | broken authorization | server-side privilege escalation |
| base64 “secret” | exposed secret | actual credential/sensitive-data use |
| unused code | vulnerability | reachable security consequence |
| deprecated dependency | vulnerability | exploitable reachable vulnerable path |
| old CVE version match | current vuln | affected code path + actual applicability |
```

---

# 14. Informative / No-Security-Impact Firewall

Do not submit when the only demonstrated value is:

```text
best-practice deviation
hardening opportunity
security hygiene suggestion
missing header without exploit
public identifier
public configuration intended for clients
source-map exposure without meaningful consequence
stack trace without security impact
verbose error without sensitive data or exploit path
EOL software with no demonstrated exploitability
weakness requiring impossible/unrealistic prerequisites
self-only impact
cosmetic issue
UI-only behavior
non-sensitive metadata
lack of rate limiting on non-sensitive operations
CSRF theory without working impact
CORS theory without credentialed sensitive data access
open redirect with no meaningful consequence
```

The agent may keep such observations as **RESEARCH INTELLIGENCE** rather than report them.

---

# 15. “Generic Things” Firewall

A generic statement is not a finding.

Examples of weak claims:

```text
The API has no rate limiting.
The app uses an old library.
The app exposes JavaScript source.
The site lacks CSP.
The server returns verbose errors.
The endpoint accepts arbitrary input.
The API uses sequential IDs.
The app supports HTTP redirects.
The client contains a public API key.
The system has admin endpoints.
The code uses eval.
```

Each requires a product-specific security consequence.

Upgrade a generic observation only when:

```text
GENERIC OBSERVATION
      ↓
PRODUCT-SPECIFIC SECURITY INVARIANT
      ↓
IMPLEMENTATION VIOLATION
      ↓
ATTACKER CAPABILITY
      ↓
CONCRETE IMPACT
```

---

# 16. Overclaim Firewall

The agent must strictly distinguish:

```text
OBSERVED
VERIFIED
INFERRED
HYPOTHESIZED
UNKNOWN
```

## 16.1 Claim ladder

Never jump levels:

```text
interesting behavior
        ↓
possible weakness
        ↓
security weakness
        ↓
exploitable vulnerability
        ↓
demonstrated impact
        ↓
severity
```

Every step needs evidence.

## 16.2 Forbidden overclaims

Never write:

```text
full account takeover
```

when only:

```text
email disclosure
```

was demonstrated.

Never write:

```text
arbitrary code execution
```

when only:

```text
server-side command construction
```

was observed.

Never write:

```text
all tenants affected
```

when only two test tenants were checked.

Never write:

```text
entire application compromised
```

when one endpoint was tested.

Never write:

```text
can exfiltrate internal credentials
```

when only a server-side callback to a researcher-controlled endpoint was proven.

Never write:

```text
critical
```

because the label “SSRF”, “IDOR”, “XSS”, “SQLi”, etc. appears.

---

# 17. Impact Bounding Rules

Impact must be bounded to what the evidence establishes.

Use:

```text
DEMONSTRATED IMPACT
Plausible but unproven extension
Out-of-scope / not tested extension
```

Example:

```text
Demonstrated:
Attacker can read another test user's billing email and IP metadata.

Not demonstrated:
Access to payment instruments, passwords, or arbitrary tenants.

Do not claim:
“full account compromise” unless independently proven.
```

## 17.1 Scale discipline

If testing 2 objects, say 2 objects.

If the behavior is clearly systemic from shared code but only one exploitation path was
safely validated, say:

```text
The validated endpoint demonstrates the flaw. Related endpoints may share the same
root cause, but broader exploitation was not included in the impact claim.
```

Do not claim “all objects”, “all users”, or “all tenants” without appropriate evidence.

---

# 18. Security Invariant Method

For each candidate write one explicit invariant:

```text
INVARIANT:
Only principals authorized for resource R may perform operation O on R.
```

or:

```text
INVARIANT:
User-controlled input must never reach shell execution as executable syntax.
```

or:

```text
INVARIANT:
Password-recovery evidence must be bound to the intended account and workflow state.
```

or:

```text
INVARIANT:
A transaction cannot transition from state A to state C without passing state B.
```

Then compare:

```text
INTENDED INVARIANT
vs
OBSERVED IMPLEMENTATION
```

The security delta is the candidate.

---

# 19. Security Boundary Identification

Every report must name the boundary.

Potential boundaries:

```text
authentication
authorization
object ownership
tenant isolation
role separation
privilege boundary
identity lifecycle
workflow state
transaction integrity
secret confidentiality
server/client trust boundary
browser/server trust boundary
application/network boundary
public/private data boundary
file system boundary
process boundary
container boundary
plugin boundary
sandbox boundary
```

Weak report:

```text
User can change id=2.
```

Strong report:

```text
The server authenticates the caller but does not enforce object ownership for the
invoice resource. A standard user can therefore modify an invoice belonging to another
account, crossing the account-level integrity boundary.
```

---

# 20. Reachability Gate

Static evidence alone is not enough for a dynamic claim.

Prove:

```text
ATTACKER INPUT
  ↓
ENTRY POINT
  ↓
ROUTING
  ↓
VALIDATION
  ↓
AUTHORIZATION
  ↓
BUSINESS LOGIC
  ↓
SINK
  ↓
SECURITY EFFECT
```

If a suspicious sink is dead code, unreachable, gated by an unavailable feature, or
requires an impossible configuration, downgrade or discard.

---

# 21. Source-to-Sink Verification

For source-code candidates, record:

```text
Source:
File:
Function:
Entry point:
Caller:
Input type:
Transformations:
Normalization:
Validation:
Authorization:
Data flow:
Sink:
Security boundary:
Preconditions:
Observed effect:
```

Do not use “dangerous API exists” as the final conclusion.

---

# 22. State-Machine Validation

Many business-logic vulnerabilities are about invalid transitions rather than one bad
request.

Model:

```text
STATE 0
  ↓ allowed?
STATE 1
  ↓ allowed?
STATE 2
  ↓ allowed?
STATE 3
```

Explicitly document:

```text
Who can perform each transition?
Which object is affected?
Which verification is required?
Can the same step be repeated?
Can a prior step be replayed?
Can steps occur out of order?
Can state be modified concurrently?
Can a revoked identity continue the flow?
```

Potential classes:

```text
invite → accept → elevate
register → verify → activate
create → approve → publish
request reset → verify → change password
create order → pay → fulfill → refund
upload → process → publish
transfer → confirm → settle
```

---

# 23. Authentication / Session Validation Firewall

Do not claim account takeover unless one of the following is actually demonstrated:

```text
session takeover
password reset compromise
magic-link compromise
recovery-flow bypass
OAuth account-link abuse
2FA bypass with meaningful consequence
session fixation leading to victim account control
identity-binding flaw enabling victim account action
```

Possible false positives:

- user enumeration alone;
- different login error messages without security consequence;
- token format weakness with no unauthorized use;
- expired-token acceptance that still cannot authenticate;
- session cookie not rotated where no privilege transition occurs;
- email change request without ability to complete verification.

Always separate:

```text
account enumeration
credential compromise
session compromise
account takeover
```

They are not interchangeable.

---

# 24. Authorization / IDOR / BOLA Validation

A valid object-level authorization finding normally needs:

```text
Attacker principal A
Protected resource owned by B
A requests resource B
Server accepts unauthorized access
Security boundary is ownership / tenant / role
Meaningful read/write/delete/admin consequence occurs
```

Control test:

```text
A → own object → expected allowed
A → victim object → expected denied
```

The contrast is important.

A random ID returning 200 is insufficient.

---

# 25. Cross-Tenant Validation

For a cross-tenant claim, prove all of:

```text
Tenant A identity
Tenant B identity
Object belongs to Tenant B
Attacker belongs to Tenant A
Server should isolate tenants
Attacker obtains Tenant B data/capability
```

Do not infer tenant isolation solely from naming conventions.

Useful evidence:

```text
tenant identifiers
organization IDs
owner IDs
membership records
authorization responses
before/after state
distinct test accounts
```

---

# 26. XSS Validation Firewall

Never report XSS solely because output is unescaped.

Require:

```text
attacker-controlled input
  ↓
storage/reflection/DOM flow
  ↓
exact browser context
  ↓
payload interpretation
  ↓
JavaScript execution
  ↓
meaningful victim/security context
```

Check:

```text
HTML
attribute
JavaScript
URL
CSS
DOM sink
Markdown / rich text
SVG / scriptable content
stored content viewed by privileged users
```

Do not upgrade:

```text
reflection
```

to:

```text
stored XSS
```

without storage evidence.

Do not upgrade:

```text
self-XSS
```

to:

```text
account compromise
```

unless a meaningful victim path is demonstrated and allowed by program rules.

---

# 27. SSRF Validation Firewall

Require:

```text
attacker-controlled destination
        ↓
server-side network client
        ↓
actual outbound request
        ↓
researcher-controlled callback / safe lab service
        ↓
proof that request originated from target infrastructure
```

Then independently verify impact.

Do not claim internal metadata access, cloud credential theft, or internal service
compromise unless safely demonstrated and authorized.

A URL parameter accepted by a parser is not SSRF proof.

---

# 28. SQL Injection Validation Firewall

Trace:

```text
attacker input
→ parser
→ query builder
→ database driver
→ query behavior
```

Require evidence of actual query influence.

Do not report only:

```text
SQL error
raw SQL string
string concatenation
ORM bypass suspicion
```

Those are candidate generators, not verdicts.

---

# 29. Command Injection / RCE Validation Firewall

Separate:

```text
Dangerous API exists
≠
Attacker controls argument
≠
Attacker reaches the code path
≠
Argument is interpreted as command syntax
≠
Code execution occurs
```

For authorized validation, use the smallest safe proof possible, such as a controlled
marker or benign callback, rather than destructive payloads.

---

# 30. File Upload / Traversal Validation Firewall

Check:

```text
filename normalization
path canonicalization
archive extraction
symlink behavior
extension checks
MIME checks
storage path
overwrite semantics
execution context
```

A file upload accepting SVG or HTML is not automatically stored XSS/RCE.

A `../` string appearing in a request is not traversal proof.

Required evidence is an actual unauthorized file effect in a controlled context.

---

# 31. CSRF Validation Firewall

Require:

```text
victim authentication model
cookie/session use
cross-site request feasibility
missing/weak CSRF/origin control
state-changing endpoint
attacker-origin request succeeds
meaningful security impact
```

Do not report “no CSRF token” alone.

Account security can still be protected by other browser controls; test the actual flow.

---

# 32. CORS Validation Firewall

Require:

```text
attacker-controlled origin
credential inclusion where relevant
browser accepts cross-origin response
sensitive authenticated data readable by attacker origin
```

Do not report:

```text
Access-Control-Allow-Origin: *
```

by itself.

Analyze credentials, sensitive response, browser enforcement, and actual cross-origin
readability.

---

# 33. Rate-Limit Validation Firewall

Rate-limit absence is not automatically a security vulnerability.

Ask:

```text
What sensitive action is being abused?
How cheaply can it be automated?
What security control is defeated?
What measurable consequence follows?
Does the program consider this category eligible?
```

Examples of stronger evidence:

```text
password-reset token guessing becomes practical
2FA verification can be brute-forced
financial action can be multiplied
resource exhaustion is demonstrated within allowed testing limits
```

Avoid load testing or destructive volume unless explicitly authorized.

---

# 34. Information Disclosure Firewall

Classify data first:

```text
public
semi-public
user-specific
tenant-specific
internal
confidential
secret
credential
security-token
```

Then ask:

```text
Should this attacker see it?
Can it be used to cross a security boundary?
Is the data actually sensitive in this product?
Is exposure already intentional?
```

Do not assume:

```text
field name contains “secret” → secret
internal hostname → sensitive
UUID → confidential
email → always high impact
IP address → automatically severe
stack trace → exploitable
```

---

# 35. Client-Side vs Server-Side Trust Boundary

Client behavior can be misleading.

For every client-side check, ask:

```text
Does server independently enforce it?
Can request be modified?
Does the server accept the unauthorized value?
Does a privileged state change occur?
```

Examples:

```text
hidden admin button
client-only role check
UI disables dangerous action
frontend validation
browser-side price calculation
```

These are only vulnerabilities if the server-side security boundary actually fails.

---

# 36. Expected vs Actual Behavior Matrix

Every strong report should include:

| Dimension | Expected | Actual | Evidence |
|---|---|---|---|
| Authentication | | | |
| Authorization | | | |
| Ownership | | | |
| Tenant | | | |
| State | | | |
| Data | | | |
| Side effect | | | |
| Browser behavior | | | |
| Server response | | | |
```

This makes design mismatch visible to a triager.

---

# 37. Control Case Discipline

A control case is one of the strongest ways to eliminate false positives.

For example:

```text
Case A — expected authorized request
Case B — expected unauthorized request
```

or:

```text
Before exploit
After exploit
```

or:

```text
Vulnerable version
Fixed version
```

or:

```text
same request with owner object
same request with victim object
```

Never omit the control when it can safely be produced.

---

# 38. Reproducibility Firewall

A triager should be able to reproduce the core result without guessing.

Minimum dynamic reproduction data:

```text
HTTP method
full path
query string
required headers
required cookies/token context
request body
request ordering
account roles
object ownership
preconditions
expected result
actual result
response status
relevant response body
before/after state
```

For code findings:

```text
exact file
exact function
commit/version
source lines or stable code identifiers
call chain
input
sink
security control
reproduction environment
```

Never hide critical prerequisites inside prose.

---

# 39. Reproducibility Levels

Use:

```text
R0 — theoretical
R1 — suspicious observation
R2 — repeatable behavior
R3 — security consequence reproduced
R4 — deterministic triager-grade PoC
```

Normal bounty submission target:

```text
R3 minimum
R4 preferred
```

Do not represent R0/R1 as a demonstrated vulnerability.

---

# 40. Evidence Quality Hierarchy

Preferred evidence order:

```text
1. Server-side state change / protected data returned
2. Authorization decision bypassed
3. Controlled callback proving server-side action
4. Reliable HTTP response differential
5. Source-level root cause
6. Client-only observation
7. Tool output without independent validation
8. Pure inference
```

Client-only observations need a server-side security consequence to become a strong
security finding.

---

# 41. Evidence Coverage Matrix

Every material claim in the report must map to evidence.

| Claim | Required evidence |
|---|---|
| endpoint exists | request/response |
| account role | account setup / authorization context |
| object ownership | controlled account/object setup |
| attacker should be denied | policy/control/legitimate request behavior |
| bypass succeeds | server response / accepted action |
| data disclosure | exact response data |
| mutation | before/after state |
| privilege escalation | role/permission state before/after |
| account takeover | authenticated victim-account control |
| SSRF | controlled server callback |
| XSS | execution proof in relevant context |
| SQLi | controlled database behavior |
| RCE | controlled code execution |
| chain | independent proof for every link |
| scale | tested object/account scope |
| novelty | known-issue / historical comparison |
| severity | demonstrated impact + prerequisites |
| remediation | root cause + relevant control |
```

If a claim has no evidence:

```text
REMOVE IT
OR
QUALIFY IT AS UNPROVEN
```

---

# 42. Chain Validation Firewall

A chain is only as strong as its weakest unproven link.

Required structure:

```text
Entry Point
  ↓ proven
Link 1
  ↓ proven
Link 2
  ↓ proven
Final security consequence
  ↓ proven
```

Never claim:

```text
A → B → C → RCE
```

when only A and B are demonstrated.

Instead:

```text
Demonstrated: A → B.
Potential extension: B may enable C, but C was not established.
```

If one link cannot be safely validated, report only the proven primitive unless program
rules and evidence justify the chain.

---

# 43. Duplicate / Known-Issue Firewall

Before submission, search at minimum:

```text
program security page
program disclosed reports
repository issues
security advisories
GHSA
CVE / NVD
release notes
security changelog
patch commits
fixed versions
vendor advisories
known bug databases
historical researcher reports where publicly available
```

Search by:

```text
endpoint
function
file
parameter
error message
component
vulnerability class
root-cause phrase
patch keyword
unique behavior
```

Never search only the exact title.

---

# 44. Duplicate Matrix

Compare:

| Dimension | Question |
|---|---|
| component | same component? |
| resource | same protected object? |
| endpoint | same/equivalent path? |
| parameter | same security input? |
| root cause | same underlying flaw? |
| primitive | same exploitation method? |
| trust boundary | same boundary? |
| role | same actor relationship? |
| workflow | same business flow? |
| state | same invalid transition? |
| capability | same unauthorized capability? |
| impact | same consequence? |
| remediation | same fix? |
| timing | already known? |
| evidence | genuinely new evidence? |
```

Strong novelty signals:

```text
different component
different authorization mechanism
different trust boundary
different state machine
different root cause
different exploitation primitive
materially broader demonstrated impact
regression after previous fix
actionable new remediation insight
```

Weak novelty signals:

```text
different object ID
different parameter name
same root cause on sibling endpoint
same impact with another payload
same pattern with cosmetic path change
more screenshots of a known issue
```

---

# 45. Systemic vs Individual Finding Analysis

If many endpoints are affected by one root cause, do not automatically create one report
per endpoint.

Ask:

```text
same middleware?
same authorization helper?
same ORM scoping?
same tenant policy?
same root cause?
same remediation?
same business capability?
```

Possible outcomes:

```text
ONE SYSTEMIC REPORT
MULTIPLE DISTINCT REPORTS
ONE PRIMARY + RELATED INSTANCES
```

A sibling endpoint may justify separate treatment when it has:

- distinct security boundary;
- distinct root cause;
- distinct attack primitive;
- materially distinct impact;
- distinct remediation;
- meaningful regression evidence.

Do not manufacture multiple findings merely to increase report count.

---

# 46. Regression vs Duplicate

A new occurrence of an old bug can be a regression.

Validate:

```text
Was the original issue fixed?
What was the original remediation?
Is current behavior materially the same?
Did the issue return after a fix?
Is current code path new?
Was the previous protection bypassed or removed?
```

Potential classification:

```text
DUPLICATE
REGRESSION
VARIANT
DISTINCT ROOT CAUSE
```

Do not call every same-category bug a duplicate.

---

# 47. Known Behavior vs Known Issue

These are not identical.

```text
KNOWN BEHAVIOR
= intentionally implemented / documented / accepted product behavior

KNOWN ISSUE
= a recognized defect, advisory, report, or already tracked weakness
```

Both can block a new bounty report, but for different reasons.

The report must record which one applies.

---

# 48. Publicly Known Does Not Automatically Mean Safe

A publicly known issue can still be relevant as:

```text
regression
variant
broader impact
new root cause
new affected component
```

But the new report must add material value.

Never use:

```text
I found the same thing independently
```

as enough evidence for novelty.

---

# 49. “Already Fixed” Firewall

If a known patch exists:

```text
locate vulnerable version
locate fixed version/commit
compare code path
validate current target version
reproduce only within authorization
```

A historical vulnerability is not necessarily a current vulnerability.

A version string alone is not enough; verify applicability where practical.

---

# 50. Severity Firewall

Severity must be based on:

```text
attacker privilege
user interaction
attack complexity
scope
confidentiality impact
integrity impact
availability impact
authentication / authorization impact
business criticality
affected population actually demonstrated
repeatability
program-specific severity rules
```

Keep three separate fields:

```yaml
technical_severity:
program_severity:
confidence_in_severity:
```

Never assume they are identical.

---

# 51. Severity Anti-Inflation Matrix

| Claim | Required proof |
|---|---|
| Account takeover | attacker gains victim account control |
| Privilege escalation | lower privilege reaches higher privilege state |
| Cross-tenant compromise | one tenant crosses into another tenant's protected resource |
| RCE | controlled code execution |
| Sensitive-data disclosure | data is actually confidential + unauthorized read |
| Financial impact | measurable business transaction/effect |
| Integrity compromise | unauthorized state/content change |
| Availability impact | measurable service/resource degradation under allowed testing |
| Authentication bypass | access granted without required auth condition |
| Authorization bypass | protected operation succeeds without permission |
```

Do not substitute labels for proof.

---

# 52. CVSS Discipline

Use CVSS only after the technical behavior is validated.

Record assumptions:

```text
Attack Vector
Attack Complexity
Privileges Required
User Interaction
Scope
Confidentiality
Integrity
Availability
```

If the program has a bespoke severity rubric, follow that rubric.

Never choose a CVSS score merely to reach a preferred bounty tier.

---

# 53. Evidence Engineering Standard

Every final report should have an evidence directory.

Recommended structure:

```text
evidence/
├── README.md
├── 00-metadata/
│   ├── target.txt
│   ├── scope.txt
│   ├── timeline.txt
│   ├── versions.txt
│   └── hashes.txt
├── 01-setup/
│   ├── accounts.md
│   ├── roles.md
│   ├── objects.md
│   └── preconditions.md
├── 02-requests/
│   ├── 01-baseline.request.txt
│   ├── 01-baseline.response.txt
│   ├── 02-exploit.request.txt
│   ├── 02-exploit.response.txt
│   └── ...
├── 03-state/
│   ├── before.json
│   ├── after.json
│   └── diff.txt
├── 04-poc/
│   ├── README.md
│   ├── reproduce.sh
│   ├── reproduce.py
│   ├── test-data/
│   └── expected-output.txt
├── 05-screenshots/
│   ├── 01-baseline.png
│   ├── 02-exploit.png
│   ├── 03-impact.png
│   └── ...
├── 06-source/
│   ├── vulnerable-snippet.txt
│   ├── call-chain.txt
│   └── root-cause.md
├── 07-duplicate-check/
│   ├── searches.md
│   ├── known-issues.md
│   └── patch-analysis.md
├── 08-impact/
│   ├── impact.md
│   └── scope-of-impact.md
└── 09-sanitized/
    └── sanitized-report-materials/
```

---

# 54. Evidence ZIP Contract

When packaging a ZIP, it should contain the **complete minimal reproducible proof**.

Preferred archive name:

```text
<program>-<finding-slug>-evidence.zip
```

Before packaging:

```text
[ ] Remove real passwords
[ ] Remove session tokens
[ ] Remove API secrets
[ ] Remove private customer data
[ ] Replace unrelated PII with clearly marked test values
[ ] Preserve required technical context
[ ] Keep timestamps where useful
[ ] Keep exact request/response structure
[ ] Verify every referenced filename exists
[ ] Verify screenshots correspond to the same test state
```

Do not sanitize away the evidence necessary to reproduce the vulnerability.

---

# 55. ZIP Integrity Verification

The agent should verify the archive after creation:

```bash
unzip -t <evidence.zip>
unzip -l <evidence.zip>
sha256sum <evidence.zip>
```

Optionally maintain:

```text
hashes.txt
```

with SHA-256 hashes of important artifacts.

The ZIP must be self-consistent:

```text
README references file X → file X exists
screenshot #3 describes state S3 → evidence shows S3
reproduce.sh references payload file → payload file exists
report references request #2 → request #2 exists
```

---

# 56. Screenshot Standard

Screenshots are supporting evidence, not a substitute for reproducible technical data.

Useful screenshots include:

```text
baseline state
attacker action
server response
before/after state
privilege change
unauthorized data access
controlled callback result
browser execution context
program scope evidence when appropriate
```

Avoid screenshots that:

- hide the URL/path;
- hide the relevant account context;
- crop away the outcome;
- rely on color alone;
- contain unrelated private data;
- are impossible to correlate with the raw request.

Use numbered filenames that map to report steps.

---

# 57. Raw HTTP Evidence Standard

For each important request/response pair:

```text
REQUEST ID:
PURPOSE:
ACTOR:
STATE BEFORE:
METHOD:
URL:
HEADERS:
BODY:

RESPONSE:
STATUS:
HEADERS:
BODY:

STATE AFTER:
SECURITY EFFECT:
```

Do not rely on a screenshot of Burp alone when a raw export can be provided.

---

# 58. Evidence Redaction Standard

Redact secrets carefully:

```text
Authorization: Bearer [REDACTED]
Cookie: session=[REDACTED]
API-Key: [REDACTED]
```

But retain enough structure to show:

```text
presence of authentication
role separation
request order
parameter names
resource IDs where safe
server response
```

When redaction prevents reproduction, provide a safe test credential or a synthetic
placeholder and state exactly what the triager must replace.

---

# 59. Proof-of-Concept Standard

A PoC should answer exactly four questions:

```text
1. How does the attacker reach the entry point?
2. What exact action/input triggers the issue?
3. What security control fails?
4. What observable security impact occurs?
```

Preferred properties:

```text
deterministic
minimal
safe
resettable
version-aware
copy/paste friendly
```

Do not weaponize beyond the minimum needed to prove the vulnerability.

---

# 60. PoC Completeness Gate

Before calling the PoC complete:

```text
[ ] Setup documented
[ ] Prerequisites documented
[ ] Accounts documented generically
[ ] Object creation documented
[ ] Exact exploit request documented
[ ] Expected denial documented
[ ] Actual acceptance documented
[ ] Impact documented
[ ] Cleanup documented
[ ] No destructive action required
[ ] No unrelated system touched
```

---

# 61. Report Writing — Triager-Grade Structure

Final report should normally follow this order:

```text
TITLE
SEVERITY
ASSET / ENDPOINT
EXECUTIVE SUMMARY
BUSINESS / SECURITY IMPACT
PRECONDITIONS
THREAT MODEL
STEPS TO REPRODUCE
RAW REQUESTS / RESPONSES
EXPECTED BEHAVIOR
ACTUAL BEHAVIOR
SECURITY BOUNDARY VIOLATION
ROOT CAUSE
IMPACT BOUNDARIES
AFFECTED SCOPE
DUPLICATE / KNOWN-ISSUE CHECK
POC / EVIDENCE
REMEDIATION
REGRESSION TEST
REFERENCES
```

Do not make the triager search through a wall of prose to find the proof.

---

# 62. Title Formula

Preferred:

```text
[Bug Class] in [Component/Feature] allows [Specific Unauthorized Capability]
```

Examples:

```text
Broken Object-Level Authorization in invoice API allows cross-account invoice modification

Missing tenant ownership validation in export API allows cross-tenant data access

Password-recovery token reuse allows unauthorized account password change

Server-side URL fetch validation bypass allows requests to researcher-controlled endpoints
```

Avoid:

```text
Critical Vulnerability Found
Security Issue
Huge Bug
Potential RCE
Major IDOR
API Vulnerability
```

Titles must describe the verified capability, not the researcher's excitement.

---

# 63. Executive Summary Formula

The summary should answer:

```text
WHO
WHAT
WHERE
WHY IT VIOLATES SECURITY
WHAT IMPACT IS PROVEN
```

Recommended pattern:

```text
An authenticated [attacker role] can [specific unauthorized capability] through
[endpoint/feature] because [root cause]. The server accepts [specific action]
without enforcing [missing control], allowing [demonstrated impact]. The issue was
reproduced using [safe test setup], and the complete request/response evidence is
included below.
```

Do not add unproven impact to the summary.

---

# 64. Reproduction Writing Standard

Use a strict numbered sequence.

```text
Step 1 — Create/login to attacker test account A.
Step 2 — Create or identify test object O owned by account B.
Step 3 — Obtain request R from account A's normal workflow.
Step 4 — Modify only parameter P to target O.
Step 5 — Send request R' as account A.
Step 6 — Observe HTTP status and response.
Step 7 — Verify state or data changed.
Step 8 — Compare against the control case.
```

The goal is that a triager can reproduce the finding with minimal inference.

---

# 65. Expected Behavior Section

State what the server **should** do.

Avoid vague language such as:

```text
It should be more secure.
This should be blocked.
I think this is not intended.
```

Use:

```text
Because object O belongs to account B and the attacker is authenticated only as
account A, the request should be rejected by the server-side object authorization
layer before the protected operation executes.
```

The expected behavior must follow the actual security model, not generic preference.

---

# 66. Actual Behavior Section

Describe only what happened.

Example:

```text
The same request, sent as account A, returns HTTP 200 and modifies object O. A
subsequent read using the legitimate owner account confirms that the server-side state
has changed.
```

Avoid:

```text
This completely compromises the platform.
```

unless the evidence supports that claim.

---

# 67. Root Cause Writing Standard

Root cause must explain **why** the server allowed the behavior.

Examples:

```text
missing object-level authorization
missing tenant scoping in ORM query
authorization middleware applied to GET but not PATCH
client-supplied role trusted by server
verification state not bound to account
transaction amount trusted from client
missing replay/idempotency enforcement
stale privilege cache
job/export result not bound to requesting principal
inconsistent validation between parser and sink
```

Weak:

```text
Change id=1 to id=2.
```

Strong:

```text
The handler authenticates the caller but retrieves the object by global identifier
without verifying ownership or tenant membership. The subsequent mutation therefore
executes using a resource that the caller is not authorized to control.
```

---

# 68. Impact Writing Standard

Impact should be vulnerability-specific.

Structure:

```text
Attacker prerequisite
→ unauthorized capability
→ affected victim/resource
→ security property violated
→ concrete consequence
→ demonstrated scope
```

Examples:

### Broken access control

```text
A standard account can modify another customer's resource, violating resource
integrity and potentially changing business-visible data owned by a different principal.
```

### Cross-tenant disclosure

```text
A user in Tenant A can retrieve protected records belonging to Tenant B, violating tenant
confidentiality and exposing the specific fields shown in the PoC.
```

### Account takeover

```text
The attacker can complete the recovery flow as the victim and obtain an authenticated
session for the victim account. This establishes account compromise rather than mere
user enumeration.
```

### SSRF

```text
The application issues a server-side HTTP request to an attacker-controlled endpoint,
proving server-side request generation. The validated impact is limited to the observed
request; access to internal infrastructure was not claimed without independent evidence.
```

---

# 69. Scope-of-Impact Writing Standard

Always state:

```text
What was tested
What was not tested
What was demonstrated
What remains unproven
```

This is an anti-overclaim mechanism and often increases triager trust.

---

# 70. Remediation Standard

Recommend the narrowest robust fix that closes the actual root cause.

Examples:

```text
Enforce object authorization before lookup/mutation.
Add server-side tenant scoping to repository queries.
Bind recovery proof to account + workflow + expiry.
Recompute authoritative financial values on the server.
Make state transitions atomic.
Enforce the same authorization policy on alternate endpoints.
Bind async job results to requesting actor/tenant.
Add replay protection / idempotency where the invariant requires uniqueness.
Canonicalize paths before authorization and file access.
Use parameterized database queries.
Validate server-side destinations against an explicit allowlist where appropriate.
```

Do not recommend:

```text
just add a WAF
add more logging
hide the endpoint
rename the parameter
add client-side validation
```

unless it truly addresses the root cause.

---

# 71. Regression Test Standard

A high-quality report proposes a regression test.

Pattern:

```text
Given attacker A and protected resource B,
when A attempts operation O on B,
then server denies the operation,
then B remains unchanged,
and no protected data is returned.
```

For state-machine bugs:

```text
Attempt invalid transition directly.
Attempt replay.
Attempt transition out of order.
Attempt same transition concurrently where relevant.
```

---

# 72. Triager Simulation Checklist

Before submission, imagine the triager asks:

```text
1. Can I reproduce this?
2. What exact asset is affected?
3. Is it in scope?
4. Is the behavior intended?
5. Who is the attacker?
6. Who owns the object/data?
7. What control should stop it?
8. Exactly where does the control fail?
9. What impact is demonstrated?
10. Can the attacker already do this another way?
11. Is this publicly known?
12. Is it a duplicate?
13. Is it systemic?
14. Is the severity justified?
15. Is the evidence sufficient?
16. Are secrets sanitized?
17. What exact fix should engineering make?
```

The report should answer all of these without forcing unnecessary back-and-forth.

---

# 73. “Report or Don't Report” Master Decision Tree

```text
START
  |
  +-- Authorized target?
  |      +-- NO → OUT_OF_SCOPE / STOP
  |
  +-- In scope?
  |      +-- NO → OUT_OF_SCOPE / STOP
  |
  +-- Exact behavior reproduced?
  |      +-- NO → HOLD_FOR_MORE_EVIDENCE
  |
  +-- Security invariant exists?
  |      +-- NO → DO_NOT_REPORT
  |
  +-- Security control actually bypassed?
  |      +-- NO → FALSE_POSITIVE / INTENDED_BEHAVIOR
  |
  +-- Attacker capability unauthorized?
  |      +-- NO → DO_NOT_REPORT
  |
  +-- Concrete impact demonstrated?
  |      +-- NO → INFORMATIVE_OR_NO_SECURITY_IMPACT
  |
  +-- Benign/design explanation disproved?
  |      +-- NO → HOLD_FOR_MORE_EVIDENCE / INTENDED_BEHAVIOR
  |
  +-- Known / patched / duplicate?
  |      +-- YES → DUPLICATE_OR_ALREADY_KNOWN
  |
  +-- Systemic issue already covered?
  |      +-- YES AND no material new value → DUPLICATE_OR_ALREADY_KNOWN
  |
  +-- Reproducible by independent triager?
  |      +-- NO → HOLD_FOR_MORE_EVIDENCE
  |
  +-- Severity supported by evidence?
  |      +-- NO → DOWNGRADE / HOLD
  |
  +-- Evidence package complete?
  |      +-- NO → HOLD_FOR_MORE_EVIDENCE
  |
  +-- Program rules permit submission?
  |      +-- NO → NON_ELIGIBLE / DO_NOT_REPORT
  |
  +-- ALL GATES PASS
         ↓
       REPORT
```

---

# 74. Hard Stops

Immediately stop report generation when:

```text
[ ] authorization is unknown
[ ] target is explicitly out of scope
[ ] exploit depends on unauthorized third-party systems
[ ] claim depends on fabricated data
[ ] impact is purely hypothetical
[ ] security boundary is not identified
[ ] attacker already has equivalent authority
[ ] resource is intentionally public/shared and no security boundary is crossed
[ ] protected operation ultimately fails
[ ] client-only condition has no server-side consequence
[ ] only a best-practice deviation exists
[ ] duplicate is established and no material new value exists
[ ] evidence cannot support the claimed impact
[ ] severity is supported only by speculation
[ ] destructive testing would be required but is prohibited
```

Hard stop means:

```text
DO NOT REPORT
```

not:

```text
rewrite the title until it sounds stronger
```

---

# 75. “Do Not Report” Examples

Do not report as a vulnerability when the evidence is only:

```text
A public profile reveals a public avatar URL.

A GET endpoint returns HTTP 200 for publicly documented data.

The browser hides an admin button, but server-side authorization still blocks the action.

A source map is publicly accessible, but no secret or security-sensitive capability is
exposed.

A response includes a UUID that the application intentionally uses as a public share
identifier.

A URL is accepted by an input field, but the server never makes an outbound request.

A command API exists but attacker input cannot reach it.

A token is short-looking, but no unauthorized validation or authentication is shown.

A missing security header has no demonstrated exploit.

A rate-limit difference exists on a low-value endpoint with no abuse consequence.

A vulnerable dependency is present but the vulnerable component is not reachable in the
affected configuration.

An error message mentions an internal path but reveals no meaningful secret or capability.
```

Keep these as research notes when useful, but do not spam the program with them.

---

# 76. “Hold For More Evidence” Examples

Use HOLD rather than forcing a yes/no judgment when:

```text
object ownership is not yet established
server-side reachability is unknown
victim context is unknown
program scope is ambiguous
known-issue status is unresolved
chain link remains unproven
impact is plausible but not demonstrated
version applicability is uncertain
current code differs from historical advisory but exploitability is unverified
control case is missing and materially important
```

HOLD means:

```text
The candidate is not ready for reporting, but is not safely dismissible yet.
```

---

# 77. Confidence Scoring Framework

Confidence should measure **evidence coverage**, not intuition.

Suggested rubric:

| Score | Meaning |
|---:|---|
| 0–20 | speculation |
| 21–40 | weak observation |
| 41–60 | suspicious / incomplete |
| 61–75 | reproducible behavior, impact incomplete |
| 76–89 | strong validated candidate |
| 90–100 | triager-grade evidence coverage |

Do not use the score to overrule a hard gate.

Example:

```text
confidence = 96
scope = UNKNOWN
```

Final decision is still:

```text
OUT_OF_SCOPE / HOLD
```

---

# 78. Candidate Ledger

Maintain one record per candidate.

```yaml
candidate_id:
created_at:
program:
asset:
component:
endpoint:
feature:
actor:
actor_role:
victim:
victim_role:
resource:
resource_owner:
tenant:
state:
security_invariant:
security_boundary:
entry_point:
attacker_control:
source:
sink:
validation:
authorization:
observed_behavior:
expected_behavior:
actual_behavior:
impact:
impact_evidence:
reproducibility:
control_case:
design_intent:
public_by_design:
known_behavior:
known_issue:
duplicate_risk:
systemic_risk:
regression_status:
scope_status:
reward_eligibility:
severity:
severity_basis:
root_cause:
remediation:
regression_test:
evidence_directory:
evidence_zip:
redaction_status:
unverified_claims:
blocking_gates:
confidence:
final_decision:
```

---

# 79. Candidate Comparison Matrix

For each serious candidate, compare:

| Gate | Status | Evidence | Failure mode | Next action |
|---|---|---|---|---|
| Scope | PASS/FAIL/HOLD | | | |
| Reachability | PASS/FAIL/HOLD | | | |
| Security control | PASS/FAIL/HOLD | | | |
| Exploitability | PASS/FAIL/HOLD | | | |
| Impact | PASS/FAIL/HOLD | | | |
| Design intent | PASS/FAIL/HOLD | | | |
| Known issue | PASS/FAIL/HOLD | | | |
| Duplicate | PASS/FAIL/HOLD | | | |
| Systemic | PASS/FAIL/HOLD | | | |
| Reproducibility | PASS/FAIL/HOLD | | | |
| Severity | PASS/FAIL/HOLD | | | |
| Evidence pack | PASS/FAIL/HOLD | | | |
| Reporting eligibility | PASS/FAIL/HOLD | | | |

A candidate may not enter REPORT until every mandatory gate is PASS.

---

# 80. Program Policy Preflight

Before submission, read the program's actual rules.

Record:

```text
scope
out-of-scope assets
out-of-scope vulnerability classes
authenticated testing requirements
test-account requirements
automation restrictions
rate limits
DoS restrictions
social engineering restrictions
third-party restrictions
data-handling rules
disclosure policy
duplicate policy
reward rules
severity rubric
report formatting requirements
```

Never assume rules from another program apply here.

---

# 81. Platform-Specific State Awareness

Different bug-bounty platforms and programs use different states and eligibility logic.

Do not predict a platform outcome as fact.

Instead classify the candidate technically first:

```text
valid / invalid / known / intended / out-of-scope / unreproducible
```

Then map to the platform/program terminology.

Typical concepts include:

```text
Accepted / Valid
Resolved
Duplicate
Informative
Not Applicable
Out of Scope
Not Reproducible
Spam / invalid submission
```

The program's actual policy controls the final handling.

---

# 82. “Triager Voice” Report Style

Write for a security engineer who has 2–5 minutes for first-pass triage.

Use:

```text
precise technical language
short paragraphs
numbered reproduction steps
exact artifacts
measured impact
explicit assumptions
clear root cause
bounded claims
```

Avoid:

```text
emoji-heavy prose
marketing language
caps-lock severity hype
“huge bug”
“game changer”
“100% critical”
long storytelling
irrelevant reconnaissance notes
unrelated payload dumps
```

---

# 83. Report Evidence Ordering

Put the most verification-friendly evidence first:

```text
1. concise summary
2. exact endpoint / feature
3. prerequisites
4. steps
5. expected vs actual
6. raw request / response
7. impact proof
8. root cause
9. severity rationale
10. remediation
11. references
12. evidence ZIP index
```

Do not bury the key response in an appendix if it is essential to proving the issue.

---

# 84. Evidence Index inside Report

Include a small table:

| Evidence | File | Purpose |
|---|---|---|
| Baseline request | `02-requests/01-baseline.request.txt` | normal behavior |
| Exploit request | `02-requests/02-exploit.request.txt` | unauthorized action |
| Response | `02-requests/02-exploit.response.txt` | server acceptance |
| State diff | `03-state/diff.txt` | demonstrated mutation |
| PoC | `04-poc/reproduce.sh` | deterministic reproduction |
| Screenshot | `05-screenshots/03-impact.png` | visual confirmation |
| Root cause | `06-source/root-cause.md` | technical explanation |
```

The report and evidence archive must reference each other consistently.

---

# 85. Timeline Discipline

For high-value findings, record:

```text
discovery time
first reproduction
impact confirmation
duplicate search
report submission
program communication
fix confirmation
retest
```

Do not change historical timestamps to improve narrative credibility.

---

# 86. Version / Build Discipline

Record:

```text
product version
commit SHA
build ID
API version
environment
configuration flags
feature flags
browser/runtime if relevant
```

Never invent an affected version range.

When exact version boundaries are unknown:

```text
Affected version: not precisely bounded yet.
Evidence confirms behavior on build <X>.
```

---

# 87. Configuration Discipline

A vulnerability may require:

```text
specific feature enabled
specific plugin installed
specific role
specific configuration
specific deployment mode
specific browser
specific auth provider
```

Record these conditions explicitly.

Do not call a configuration-only issue universal unless the configuration is standard,
supported, realistic, and within program scope.

---

# 88. Business Context Verification

Impact is product-specific.

Map:

```text
users
roles
tenants
assets
money / credits
entitlements
orders
identity data
customer data
admin functions
integrations
```

Then ask:

```text
What does this capability mean in THIS product?
```

For example, an “edit” action on a disposable preference is not equivalent to editing a
payment method, changing an SSO domain, changing a tenant admin, or modifying an order.

---

# 89. Capability-First Impact Model

Use:

```text
WHAT CAN ATTACKER DO?
        ↓
TO WHAT?
        ↓
AS WHICH PRINCIPAL?
        ↓
WITHOUT WHICH REQUIRED PERMISSION?
        ↓
WHAT SECURITY PROPERTY BREAKS?
        ↓
WHAT BUSINESS CONSEQUENCE OCCURS?
```

This prevents impact inflation from vulnerability labels.

---

# 90. “Attacker Already Has It” Examples

Potential false positives:

```text
A normal user can read their own profile through an alternate endpoint.

An editor can modify content that the report claims only admins should change, but the
product explicitly grants editors that capability.

A public share link reveals data because that share link is intentionally public.

A user can export their own data without additional confirmation because the product
explicitly defines self-export as allowed.
```

Always compare actual product permissions with assumptions.

---

# 91. Alternative Legitimate Path Test

Ask:

```text
Can the attacker achieve the same result through a documented feature?
Can the attacker use an intended API that performs the same action?
Is the supposedly protected operation deliberately exposed elsewhere?
```

If yes, investigate whether the supposed bypass adds any new capability.

A different endpoint is not automatically a security bypass.

---

# 92. Differential Testing Protocol

When practical, compare:

```text
Role A vs Role B
Owner vs Non-owner
Tenant A vs Tenant B
Authenticated vs Unauthenticated
Verified vs Unverified
Before vs After
Valid state vs Invalid state
Normal request vs modified request
Vulnerable build vs fixed build
```

Differential evidence is especially valuable for authorization and business-logic
findings.

---

# 93. Minimal-Change Exploit Protocol

When validating a candidate, modify the smallest possible part of the request.

Example:

```text
baseline request
↓
change object identifier only
↓
observe behavior
```

Or:

```text
baseline state
↓
repeat exact request at invalid state
```

Minimal changes improve causal confidence and reproducibility.

---

# 94. Causality Check

Ask:

```text
Did my modified input actually cause the effect?
Could the state change have occurred independently?
Was the backend asynchronous?
Was another actor / process responsible?
Is eventual consistency confusing the result?
Could a cached response explain the observation?
```

For asynchronous systems, include:

```text
request timestamp
job ID
poll sequence
final state
```

---

# 95. Cache / CDN / Proxy False-Positive Check

Unexpected data may result from:

```text
cache hit
stale CDN content
shared public cache
proxy behavior
browser cache
pre-rendered pages
replication lag
```

Before claiming authorization failure, verify that the protected server-side source itself
returns the unauthorized data/capability.

---

# 96. Async / Eventual Consistency Check

For jobs, queues, webhooks, and background processing:

```text
Request accepted
→ job created
→ worker executed
→ output produced
→ actor/tenant binding verified
```

An accepted job ID is not proof that the attacker can access another user's result.

---

# 97. Webhook / Callback Validation

For callback-based findings, prove:

```text
who triggered callback
what data was transmitted
which server generated it
whether attacker controls destination
whether authorization is expected
```

Do not treat a generic callback as proof of sensitive-data disclosure.

---

# 98. OAuth / SSO Validation Firewall

For OAuth-like issues, explicitly model:

```text
authorization request
state binding
PKCE where relevant
redirect URI
client ID
identity binding
callback
session creation
account linking
unlinking
```

Do not call absence of one defense automatically exploitable; prove the actual security
consequence.

---

# 99. Password Recovery Validation Firewall

Map:

```text
request reset
→ token issued
→ token delivery
→ token verification
→ account binding
→ password change
→ session creation
```

Potential findings require demonstrating an attacker can cross the relevant account
security boundary.

Enumeration alone is not automatically ATO.

---

# 100. Email / Phone Verification Validation Firewall

Ask:

```text
Can unverified principal perform verified-only action?
Can verification proof be reused?
Can proof be transferred between accounts?
Can proof be predicted or bypassed?
Can state be manipulated out of order?
```

Require evidence of a real protected capability being gained.

---

# 101. Payment / Business Logic Validation Firewall

For monetary systems, map:

```text
price source
currency
quantity
discount
authorization
payment state
fulfillment
refund
idempotency
ownership
```

Examples of stronger proof:

```text
duplicate credit issuance
negative price accepted and credited
unauthorized refund
payment bypass resulting in fulfillment
quantity tampering resulting in extra goods/credits
```

Do not claim financial impact from a cosmetic price display difference if the authoritative
server-side total is still enforced.

---

# 102. Race Condition Validation Firewall

Concurrency alone is not a vulnerability.

Require:

```text
security-sensitive invariant
        ↓
concurrent requests
        ↓
check/use split or non-atomic transition
        ↓
invalid state / duplicated effect
        ↓
repeatable consequence
```

Use safe test accounts and controlled load only where authorized.

---

# 103. Replay / Idempotency Validation

Ask:

```text
Can the same action be repeated?
Should repetition be allowed?
Does the server create duplicate side effects?
Is an idempotency key expected?
Does replay cross an economic/security boundary?
```

A request succeeding twice is not automatically a vulnerability; the product semantics
matter.

---

# 104. Privilege / Role Boundary Validation

Map:

```text
current role
required role
requested action
server authorization decision
resulting role/capability
```

Do not rely on UI visibility.

Prove the server actually grants the unauthorized privilege.

---

# 105. Secret Exposure Classification

For every suspected secret, classify:

```text
publishable identifier
client-scoped credential
server credential
session token
signing secret
encryption key
internal service token
high-privilege API key
```

Then validate:

```text
Is it usable?
What scope does it have?
Can the attacker perform unauthorized actions?
Does the credential belong to the in-scope target?
```

A string that looks like a key is not proof of compromise.

---

# 106. Dependency / CVE Validation

Never report:

```text
Package X version Y has CVE Z.
```

without checking:

```text
is component actually present?
is version actually affected?
is vulnerable feature reachable?
is vulnerable behavior exposed in target context?
is the issue already patched/backported?
is program accepting dependency-only findings?
```

Dependency metadata is a candidate generator, not an automatic submission.

---

# 107. Security Configuration Validation

Distinguish:

```text
unsafe default
unsafe supported configuration
optional hardening
unsupported configuration
out-of-scope configuration
```

A configuration that requires explicit dangerous deployment may still be valid in some
programs, but the actual policy and impact must be considered.

---

# 108. Third-Party Boundary Firewall

Do not assume third-party components are in scope.

Examples:

```text
payment processor
cloud provider
analytics vendor
OAuth provider
CDN
hosting provider
DNS provider
email service
SaaS integration
```

If the vulnerability is in a third-party service outside authorization, do not actively
probe or exploit it.

You may document that the target integrates with it if permitted and useful.

---

# 109. Safe Validation Standard

Prefer:

```text
harmless markers
researcher-controlled endpoints
synthetic accounts
synthetic objects
local test servers
resettable state
small deterministic request counts
```

Avoid:

```text
credential theft
persistence
destructive writes
service disruption
mass scraping
unrelated data access
bypassing rate limits aggressively
attacking third-party infrastructure
```

A safer PoC is usually a stronger PoC because it is easier for a program to reproduce.

---

# 110. Evidence/Claim Consistency Audit

Before submission, scan every sentence and ask:

```text
What evidence proves this exact sentence?
```

Classify each claim:

```text
FACT — directly observed
SOURCE — externally documented
INFERENCE — logically derived
HYPOTHESIS — not yet proven
```

Final reports should minimize unsupported inference.

---

# 111. Report-Language Lint Rules

Reject draft if it contains unsupported words such as:

```text
fully
completely
entire
all
any user
all users
any tenant
every tenant
arbitrary
critical
massive
severe
instant
trivial
zero-day
unlimited
full compromise
RCE
ATO
```

unless the evidence explicitly supports the word.

Replace with bounded statements:

```text
The tested attacker can...
The validated object was...
The demonstrated impact is...
The evidence currently supports...
The tested scope included...
```

---

# 112. “Triager Can Reproduce” Test

Hand the report to an imaginary stranger.

Ask:

```text
Could they identify the exact account state?
Could they identify the exact resource?
Could they send the exact request?
Could they understand the expected denial?
Could they see the actual response?
Could they verify the state change?
Could they distinguish this from intended behavior?
```

Any “no” means the report needs improvement before submission.

---

# 113. Evidence Pack README Template

The evidence ZIP should contain a `README.md` with:

```text
Finding:
Program:
Asset:
Test environment:
Date tested:
Tester role(s):
Victim test role(s):
Version/build:

What this evidence proves:
1.
2.
3.

Safe reproduction:
1.
2.
3.

Important notes:
- only synthetic/test data used
- secrets redacted
- no unrelated systems were touched

File map:
- ...

SHA-256:
- ...
```

---

# 114. Report Submission Package Checklist

```text
[ ] Final report text
[ ] Evidence ZIP
[ ] ZIP integrity tested
[ ] Screenshots mapped to steps
[ ] Raw requests/responses present
[ ] PoC present
[ ] Impact evidence present
[ ] Scope evidence checked
[ ] Duplicate search documented
[ ] Known-issue search documented
[ ] Root cause explained
[ ] Remediation explained
[ ] Regression test proposed
[ ] Secrets redacted
[ ] Unproven claims removed
[ ] Severity validated
[ ] Title validated
[ ] Summary validated
[ ] Program rules re-read immediately before submission
```

---

# 115. Final Adversarial Pre-Submission Review

Run these questions in order:

### Gate A — Is this real?

```text
Did it happen?
Can I reproduce it?
Do I have raw evidence?
```

### Gate B — Is this security-relevant?

```text
What boundary is crossed?
What unauthorized capability is gained?
```

### Gate C — Is it unintended?

```text
Could this be public-by-design?
Could this be a documented feature?
Could the attacker already do it?
```

### Gate D — Is it impactful?

```text
What concrete security consequence is proven?
```

### Gate E — Is it unique enough?

```text
Known issue?
Duplicate?
Systemic coverage?
Regression?
```

### Gate F — Is it eligible?

```text
Correct target?
Correct program?
Correct version?
Correct vulnerability class?
Correct testing method?
```

### Gate G — Can the triager reproduce it?

```text
Exact steps?
Exact evidence?
Exact account/resource context?
```

### Gate H — Are we overclaiming?

```text
Every strong word is evidence-backed?
Every number is measured?
Every scope statement is bounded?
```

Only PASS across all mandatory gates → REPORT.

---

# 116. Final Decision Table

| Condition | Decision |
|---|---|
| Unauthorized target | OUT_OF_SCOPE |
| Explicitly OOS asset | OUT_OF_SCOPE |
| OOS vulnerability class | NON_ELIGIBLE / DO_NOT_REPORT |
| Reproduction impossible | NOT_REPRODUCIBLE |
| Missing critical evidence | HOLD_FOR_MORE_EVIDENCE |
| Intended/public behavior | INTENDED_BEHAVIOR |
| No meaningful security impact | INFORMATIVE_OR_NO_SECURITY_IMPACT |
| Duplicate/known issue | DUPLICATE_OR_ALREADY_KNOWN |
| Systemic duplicate with no new value | DUPLICATE_OR_ALREADY_KNOWN |
| Security boundary not crossed | DO_NOT_REPORT |
| Attacker already authorized | DO_NOT_REPORT |
| Concrete impact proven | continue |
| Scope confirmed | continue |
| Novel/materially additive | continue |
| Triager-grade evidence | continue |
| Program permits submission | REPORT |

---

# 117. Final Report Template — Complete

```markdown
# [Bug Class] in [Component/Feature] allows [Specific Unauthorized Capability]

## Severity
[Program severity / CVSS if applicable]

## Asset / Endpoint
- Asset:
- Endpoint / feature:
- Method:
- Version/build:

## Executive Summary
[2–5 precise sentences. State actor, capability, boundary failure, and demonstrated impact.]

## Preconditions
- Attacker account / role:
- Victim test account / role:
- Required feature/configuration:
- Required state:

## Threat Model
- Attacker:
- Protected principal/resource:
- Security boundary:
- Expected permission model:

## Security Invariant
[One precise statement of what must always be true.]

## Steps to Reproduce
1.
2.
3.
4.
5.

## Raw Request / Response
### Baseline
```http
[redacted but reproducible request]
```

```http
[response]
```

### Exploit / Unauthorized Request
```http
[exact request]
```

```http
[exact response]
```

## Expected Behavior
[What the server should enforce and why.]

## Actual Behavior
[What the server actually did.]

## Security Boundary Violation
[Exactly which authorization/trust/state boundary was crossed.]

## Impact
[Only demonstrated impact.]

## Scope of Demonstration
[What was tested and what was not tested.]

## Root Cause
[Exact technical reason the control failed.]

## Duplicate / Known-Issue Analysis
[Searches, findings, and why this is distinct or why it should not be submitted.]

## Severity Rationale
[Evidence-backed explanation using program rubric or CVSS.]

## Proof of Concept
[Minimal deterministic PoC.]

## Evidence ZIP
[Archive filename + evidence index.]

## Remediation
[Narrowest robust fix addressing the root cause.]

## Regression Test
[Precise test preventing recurrence.]

## References
[Only verified references.]
```

---

# 118. “Rejected Finding” Record Template

When the correct answer is “do not report”, preserve the learning.

```markdown
# Candidate: [ID]

## Initial Hypothesis
[What looked vulnerable.]

## Observed Behavior
[What actually happened.]

## Strongest Benign Explanation
[Best non-vulnerability explanation.]

## Validation Performed
1.
2.
3.

## Disqualifying Evidence
[Why the candidate failed.]

## Classification
- [ ] FALSE_POSITIVE
- [ ] INTENDED_BEHAVIOR
- [ ] PUBLIC_BY_DESIGN
- [ ] NO_SECURITY_IMPACT
- [ ] DUPLICATE_OR_ALREADY_KNOWN
- [ ] OUT_OF_SCOPE
- [ ] NOT_REPRODUCIBLE
- [ ] INSUFFICIENT_EVIDENCE

## Why Not Reported
[Precise reason.]

## Reusable Learning
[What future hunts should test differently.]
```

Rejected findings are valuable if they improve future hunting.

---

# 119. Agent Learning Loop

After every accepted/rejected outcome, update:

```text
PROGRAM-SPECIFIC KNOWLEDGE
KNOWN DESIGN DECISIONS
KNOWN FALSE POSITIVES
KNOWN DUPLICATE PATTERNS
KNOWN ROOT CAUSES
KNOWN TRUST BOUNDARIES
KNOWN REMEDIATION PATTERNS
KNOWN OUT-OF-SCOPE CLASSES
```

Record:

```text
Observation
→ Decision
→ Reason
→ Evidence
→ General lesson
→ Future detection rule
```

Example:

```text
Observation: unauthenticated API returned profile email.
Decision: DO_NOT_REPORT.
Reason: field is public by product design.
Evidence: public profile documentation + anonymous UX + matching public endpoint.
Lesson: verify secrecy before claiming disclosure.
Future rule: check public/share semantics before privacy classification.
```

---

# 120. False-Positive Repair Loop

A rejected candidate should improve the hunting system.

```text
FALSE POSITIVE
   ↓
IDENTIFY WRONG ASSUMPTION
   ↓
IDENTIFY ACTUAL SECURITY CONTROL / DESIGN RULE
   ↓
UPDATE RULE
   ↓
SEARCH NEIGHBORING SURFACES
   ↓
FORM NARROWER HYPOTHESIS
   ↓
REVALIDATE
```

Do not merely delete false positives from notes.

---

# 121. Duplicate Learning Loop

When a finding is duplicate:

```text
Identify prior issue
→ identify root cause
→ identify coverage
→ identify fix
→ determine whether current behavior is systemic
→ stop redundant submissions
→ search for materially distinct variants
```

The goal is to reduce duplicate rate, not increase report count.

---

# 122. Program-Specific Knowledge Discipline

Never generalize a program's behavior into a universal truth.

Bad:

```text
This platform pays for every duplicate.
This program accepts every low-impact bug.
This company considers all source maps sensitive.
```

Correct:

```text
For Program X, the current documented policy states...
```

Policies can change. Re-check before submission.

---

# 123. Research Efficiency Metric

Measure:

```text
validated findings
÷
serious candidates investigated
```

Also track:

```text
false-positive rate
duplicate rate
not-reproducible rate
acceptance rate
average evidence completeness
average triager follow-up needed
```

Do not optimize for report volume.

---

# 124. Finding Quality Score

Optional internal score out of 100:

| Dimension | Weight |
|---|---:|
| Reachability proof | 15 |
| Security-boundary proof | 20 |
| Impact proof | 25 |
| Reproducibility | 15 |
| Scope correctness | 10 |
| Novelty/duplicate analysis | 5 |
| Root cause clarity | 5 |
| Remediation quality | 5 |

Interpretation:

```text
90–100 = submission-ready
80–89  = strong but review once more
70–79  = validation needed
50–69  = suspicious/incomplete
<50    = do not report
```

A hard failure still overrides the numeric score.

---

# 125. Mandatory A/B/C Evidence Model

Every serious finding should have:

```text
A — ATTACKER EVIDENCE
What attacker sent/did.

B — SERVER EVIDENCE
What server accepted/returned/changed.

C — SECURITY CONSEQUENCE
What unauthorized security effect followed.
```

This is a compact universal sanity check.

If C is missing, do not claim high-impact vulnerability.

---

# 126. Mandatory “Why This Is Not a False Positive” Section (Internal)

Before submission, write:

```text
Why this is not intended behavior:
...

Why attacker is not already authorized:
...

Why this is not public-by-design:
...

Why impact is real:
...

Why the evidence is reproducible:
...

Why this is not a duplicate:
...
```

This section can remain internal, but it must be completed for high-value findings.

---

# 127. Mandatory “Strongest Counterargument” Section (Internal)

Write the strongest rejection argument:

```text
A triager may argue that ______.

This argument is disproved by ______.
```

If you cannot fill in the second line with evidence:

```text
HOLD_FOR_MORE_EVIDENCE
```

---

# 128. Mandatory “Evidence Boundary” Section

Every final report should state:

```text
Demonstrated:
- ...

Not demonstrated:
- ...

Not tested because:
- authorization/safety/program restrictions
```

This prevents accidental overclaiming.

---

# 129. No “Evidence by Screenshot Alone” Rule

Screenshots can support but should not replace:

```text
raw HTTP
state evidence
request order
server result
```

For browser-only findings where execution itself is the evidence, the screenshot may be
central, but still preserve the triggering input and context.

---

# 130. No “Scanner Says So” Rule

Scanner output is always:

```text
LEAD
```

never:

```text
FINAL FINDING
```

The agent must independently verify:

```text
reachability
security control
exploitability
impact
scope
novelty
```

---

# 131. No “Code Smell = Vulnerability” Rule

Static code smells include:

```text
string concatenation
missing annotation
weak validation
eval
exec
raw SQL
path join
unsafe deserialization
hardcoded configuration
```

These are candidate generators only.

The final finding must connect:

```text
attacker-controlled input/state
→ reachable vulnerable operation
→ security consequence
```

---

# 132. No “Severity First” Rule

Never start with:

```text
Find me Criticals.
```

Start with:

```text
Find violated security invariants.
```

Severity is assigned after:

```text
reproduction
impact
scope
attacker prerequisites
```

---

# 133. No “Chain Inflation” Rule

A chain can increase impact only if every required link is real.

Do not construct imaginary chains from:

```text
known low-severity issue
+ theoretical second bug
+ hypothetical victim interaction
= critical
```

If the second link is unproven, keep it unproven.

---

# 134. No “Worst-Case Storytelling” Rule

Do not choose the most catastrophic imaginable consequence.

Choose:

```text
the highest consequence actually demonstrated within authorized testing
```

Then optionally note:

```text
Potential extension not demonstrated.
```

---

# 135. Program-Policy Supremacy Rule

This skill never overrides:

```text
program rules
scope
safe harbor
testing restrictions
platform policies
lawful authorization
```

When generic skill logic conflicts with a program-specific rule, follow the explicit
program rule and record the reason.

---

# 136. Responsible Disclosure Rule

For valid findings:

```text
reproduce
→ confirm impact
→ confirm scope
→ check known/duplicate
→ package evidence
→ submit privately through allowed channel
→ answer triager questions
→ retest fix when appropriate
```

Do not publicly disclose working exploitation before permitted by the relevant process.

---

# 137. Final Agent Output Format

For every serious candidate, the agent should produce:

```yaml
candidate_id:
final_decision:
confidence:
classification:
vulnerability_class:
cwe:
asset:
endpoint:
actor:
victim:
security_boundary:
security_invariant:
root_cause:
preconditions:
reproduction_status:
impact_status:
impact:
scope_status:
design_intent_status:
known_issue_status:
duplicate_status:
systemic_status:
regression_status:
severity:
evidence_status:
unverified_claims:
blocking_gates:
next_action:
```

If `final_decision: REPORT`, also output:

```text
title
summary
steps_to_reproduce
raw_requests
expected_behavior
actual_behavior
security_boundary_violation
impact
root_cause
severity_rationale
remediation
regression_test
evidence_zip_path
```

---

# 138. Final “REPORT” Gate

Only REPORT when:

```text
[PASS] target authorized
[PASS] target in scope
[PASS] exact behavior reproduced
[PASS] attacker capability proven
[PASS] security boundary identified
[PASS] security control bypass proven
[PASS] concrete impact proven
[PASS] intended/public explanation disproved
[PASS] known-issue search completed
[PASS] duplicate analysis completed
[PASS] systemic issue assessed
[PASS] regression assessed
[PASS] reproducibility sufficient
[PASS] severity supported
[PASS] all material claims evidence-backed
[PASS] secrets sanitized
[PASS] PoC complete
[PASS] evidence archive internally consistent
[PASS] program rules rechecked
```

One missing mandatory gate means:

```text
NOT REPORT YET
```

---

# 139. Final “100% Gate Coverage” Statement

The agent may say:

```text
VALIDATED: all mandatory evidence gates passed for the tested scope.
```

It must not say:

```text
100% guaranteed bounty
100% guaranteed acceptance
100% guaranteed critical
100% guaranteed CVE
```

No skill can guarantee a program's human triage outcome, reward amount, or advisory
decision.

---

# 140. Operational Commandment List

```text
1. Scope before exploit.
2. Evidence before claim.
3. Security invariant before severity.
4. Server-side proof before vulnerability label.
5. Impact before CVSS.
6. Design intent before disclosure claim.
7. Duplicate check before submission.
8. Root cause before remediation.
9. Reproducibility before report.
10. Bounded claims before dramatic language.
11. Control case before confidence.
12. Adversarial review before final submission.
13. Safe PoC before powerful PoC.
14. Program policy before generic assumptions.
15. “Do not report” is a valid and often correct outcome.
```

---

# 141. Master Internal Prompt

Use the following operational instruction for the final validation agent:

```text
You are the FINAL FINDING VALIDATION AND TRIAGE-GRADE REPORTING AGENT.

Your objective is NOT to maximize the number of reports.
Your objective is to maximize the probability that each submitted report is:
- authorized,
- in scope,
- genuinely unintended,
- security-relevant,
- reproducible,
- concretely impactful,
- non-duplicate or materially additive,
- accurately scoped,
- accurately scored,
- and easy for an independent triager to validate.

OPERATING DOCTRINE
UNDERSTAND → MODEL → VERIFY → FALSIFY → PROVE IMPACT → CHECK INTENT → CHECK SCOPE → CHECK KNOWN ISSUES → CHECK DUPLICATES → CHECK REPRODUCIBILITY → CHECK SEVERITY → PACKAGE EVIDENCE → REPORT OR STOP.

ABSOLUTE RULES
1. Never fabricate facts.
2. Never convert hypotheses into evidence.
3. Never infer authorization from reachability.
4. Never call a public/intended resource a disclosure without proving the security boundary.
5. Never call a parameter an IDOR without object-ownership proof.
6. Never call a URL parameter SSRF without a server-side request proof.
7. Never call unescaped output XSS without execution proof.
8. Never call eval/exec RCE without demonstrated code execution.
9. Never call a SQL error SQLi without database-behavior proof.
10. Never call missing CSRF tokens CSRF without a working state-changing cross-site action.
11. Never call CORS vulnerable without a credentialed sensitive read when required by the browser model.
12. Never claim account takeover without victim-account control evidence.
13. Never claim critical severity without critical impact evidence.
14. Never claim “all users”, “all tenants”, or “arbitrary” unless tested and justified.
15. Never claim zero-day, CVE, bounty eligibility, or maintainer acceptance without evidence.
16. Never suppress uncertainty. Label it explicitly.
17. Never submit an out-of-scope finding as though it were bounty eligible.
18. Never submit a known issue or duplicate without material new value.
19. Never let a dramatic chain outrun its weakest proven link.
20. Never use screenshots as a substitute for core technical evidence when raw evidence is available.

THREE-PASS VALIDATION
PASS 1: prove the exact behavior exists.
PASS 2: prove the security impact and boundary violation.
PASS 3: try to kill the finding as a triager.

FOR HIGH-VALUE FINDINGS ALSO PERFORM
PASS 4: known issue / duplicate / systemic / regression analysis.
PASS 5: evidence-pack and report-quality audit.

FOR EACH CANDIDATE ANSWER
- What happened?
- Who can trigger it?
- What exact resource is affected?
- Who owns the resource?
- What security invariant applies?
- What control should prevent it?
- Where does that control fail?
- What unauthorized capability is gained?
- What impact is actually demonstrated?
- What benign/design explanation could explain the behavior?
- Has that explanation been disproved?
- Is the behavior public-by-design?
- Can the attacker already do the same thing legitimately?
- Is the issue known or patched?
- Is it a duplicate or systemic coverage?
- Is it a regression?
- Is the exact scope confirmed?
- Is the exact version/configuration known?
- Can an independent triager reproduce it?
- Are all material claims mapped to evidence?
- Is the severity supported?
- Is the report eligible under the program rules?

FINAL STATES
REPORT
HOLD_FOR_MORE_EVIDENCE
DO_NOT_REPORT
OUT_OF_SCOPE
DUPLICATE_OR_ALREADY_KNOWN
INTENDED_BEHAVIOR
INFORMATIVE_OR_NO_SECURITY_IMPACT
NOT_REPRODUCIBLE

WHEN FINAL STATE IS NOT REPORT
Explain exactly which gate failed and retain the candidate as structured research notes.

WHEN FINAL STATE IS REPORT
Produce:
1. precise title
2. concise summary
3. severity + rationale
4. asset/endpoint
5. prerequisites
6. threat model
7. invariant
8. complete reproduction steps
9. raw request/response evidence
10. expected vs actual behavior
11. security boundary violation
12. concrete impact
13. scope boundaries
14. root cause
15. duplicate/known-issue analysis
16. remediation
17. regression test
18. evidence ZIP index
19. explicit list of unproven claims (ideally empty)

FINAL QUALITY BAR
A skilled triager should be able to think:
“I understand what the bug is, why it violates the security model, reproduce it from the
provided evidence, see the actual impact, distinguish it from known/systemic issues,
and understand what should be fixed.”

If you cannot make that statement true from evidence, do not submit the report yet.
```

---

# 142. Optional Automation Contract

The agent may automate:

```text
request capture
response capture
hashing
redaction checks
archive validation
duplicate-search logging
candidate scoring
checklist generation
Markdown report generation
ZIP generation
```

But automation must not automatically promote candidates to REPORT without the mandatory
validation gates.

---

# 143. Evidence Packaging Shell Example

For a local authorized evidence directory:

```bash
set -euo pipefail

ROOT="evidence"
ZIP="finding-evidence.zip"

find "$ROOT" -type f -print0 | sort -z | xargs -0 sha256sum > "$ROOT/00-metadata/hashes.txt"
unzip -t "$ZIP" 2>/dev/null || true
rm -f "$ZIP"
zip -qr "$ZIP" "$ROOT"
unzip -t "$ZIP"
unzip -l "$ZIP"
sha256sum "$ZIP"
```

Use equivalent tooling appropriate to the environment. The important requirement is
integrity, not a specific command.

---

# 144. Evidence ZIP Anti-Pattern List

Never package:

```text
mass scraped production data
real user passwords
live session cookies
unredacted access tokens
unnecessary personal data
private customer files unrelated to proof
attack automation designed for persistence
malware-like payloads when a benign marker proves the issue
```

The evidence archive should be **complete enough to validate the finding, but no broader
than necessary**.

---

# 145. Internal Final Audit — A to Z

```text
A — Authorization confirmed
B — Business context mapped
C — Control boundary identified
D — Design intent checked
E — Exact reproduction captured
F — False-positive explanation challenged
G — Ground-truth server evidence captured
H — Hypotheses separated from facts
I — Impact demonstrated
J — Journey/state sequence documented
K — Known issue checked
L — Least-assumption reasoning used
M — Material novelty checked
N — Non-duplicate assessed
O — Out-of-scope eliminated
P — PoC complete
Q — Quality of evidence reviewed
R — Reproducibility verified
S — Severity bounded
T — Triager simulation passed
U — Unverified claims removed
V — Version/configuration recorded
W — What-was-not-tested documented
X — eXact request/response preserved
Y — Why-this-is-not-a-false-positive documented
Z — ZIP/evidence integrity verified
```

---

# 146. Final Stop Rule

The agent must be comfortable saying:

```text
“This is not ready to report.”
```

and:

```text
“This is not a security vulnerability.”
```

and:

```text
“This may be real technically, but it is not eligible for this program.”
```

Those are successful outcomes when supported by evidence.

A good bug-bounty agent is not a report generator.

It is a **finding filter**.

---

# 147. Completion Criterion

A finding is complete only when:

```text
THEORY
→ OBSERVATION
→ REPRODUCTION
→ SECURITY INVARIANT
→ CONTROL FAILURE
→ UNAUTHORIZED CAPABILITY
→ CONCRETE IMPACT
→ DESIGN-INTENT DISPROOF
→ SCOPE CONFIRMATION
→ KNOWN-ISSUE CHECK
→ DUPLICATE CHECK
→ SYSTEMIC CHECK
→ REPRODUCIBILITY CHECK
→ SEVERITY CHECK
→ EVIDENCE PACK
→ TRIAGER-READY REPORT
```

Otherwise the correct state is not REPORT.

---

# 148. Interoperability With Existing Hunt Skills

This skill is a **final-gate layer** and should be invoked after discovery, source review,
reconnaissance, exploitation research, or candidate generation.

Recommended orchestration:

```text
DISCOVERY SKILLS
      ↓
RECON / CODE / API / BUSINESS-LOGIC SKILLS
      ↓
CANDIDATE GENERATION
      ↓
VALIDATION TRIAGE NOVELTY REPORTING
      ↓
THIS SKILL — FALSE POSITIVE / SCOPE / DUPLICATE / IMPACT FIREWALL
      ↓
EVIDENCE ENGINEERING
      ↓
FINAL REPORT
```

The final gate should not replace deeper vulnerability-specific skills. It decides whether
the output of those skills is actually reportable.

---

# 149. Priority Rules When Skills Disagree

When another skill says:

```text
“Potential Critical”
```

but this skill says:

```text
“Impact not demonstrated”
```

the candidate remains:

```text
HOLD_FOR_MORE_EVIDENCE
```

When another skill says:

```text
“Likely duplicate”
```

but evidence shows a distinct root cause or regression, continue duplicate analysis.

When another skill says:

```text
“Looks public”
```

but the object is proven private and cross-tenant access is demonstrated, continue.

The final decision is evidence-driven, not popularity-driven.

---

# 150. Final Principle

```text
A STRONG FINDING IS NOT THE ONE THAT SOUNDS MOST DANGEROUS.

A STRONG FINDING IS THE ONE THAT SURVIVES ATTACK FROM EVERY DIRECTION:

scope
intent
authorization
reachability
impact
reproducibility
known issues
duplicates
systemic coverage
severity
triager skepticism
and evidence integrity.
```

Final doctrine:

```text
DO NOT REPORT ANOMALIES.
REPORT VERIFIED SECURITY-BOUNDARY VIOLATIONS.

DO NOT REPORT POSSIBILITIES.
REPORT DEMONSTRATED CAPABILITIES AND IMPACT.

DO NOT REPORT WHAT AI “THINKS” HAPPENS.
REPORT WHAT THE EVIDENCE PROVES HAPPENS.

DO NOT OPTIMIZE FOR REPORT COUNT.
OPTIMIZE FOR BOUNTY-VALID DENSITY.
```

---

## End State

```text
VALID + IN-SCOPE + REPRODUCIBLE + IMPACTFUL + SUFFICIENTLY NOVEL + TRIAGER-READY
= REPORT

Anything else
= KEEP RESEARCHING / REFRAME / DISCARD / DO NOT REPORT
```

